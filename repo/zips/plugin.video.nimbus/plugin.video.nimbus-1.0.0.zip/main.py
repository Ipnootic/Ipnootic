import xbmcplugin, xbmcgui, xbmcaddon, sys

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'videos')

def main_menu():
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=sys.argv[0] + '?action=movies', listitem=xbmcgui.ListItem('Filmes'), isFolder=True)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=sys.argv[0] + '?action=series', listitem=xbmcgui.ListItem('Séries'), isFolder=True)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=sys.argv[0] + '?action=search', listitem=xbmcgui.ListItem('Pesquisar'), isFolder=True)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=sys.argv[0] + '?action=trakt', listitem=xbmcgui.ListItem('Trakt'), isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

main_menu()
