# Nimbus Kodi Addon

Este é um addon modular para Kodi, permitindo pesquisar e organizar filmes e séries através de integrações com TMDB, Trakt, OpenSubtitles e suporte a scrapers externos.

## Funcionalidades

- Menus para filmes, séries, pesquisa, Trakt
- Suporte a TMDB e Trakt (opcional)
- Integração com Real-Debrid e OpenSubtitles
- Suporte a scrapers próprios (A4K, CocoScrapers, etc)

## Instalação

1. Instala via "Instalar de um ficheiro zip" no Kodi.
2. Configura os scrapers na secção de definições.

