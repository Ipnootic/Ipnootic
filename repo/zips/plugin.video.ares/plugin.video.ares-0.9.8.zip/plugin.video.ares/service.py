import xbmc
from resources.lib.utils.settings import get_bool
from resources.lib.subs import opensubs
from resources.lib.trakt import scrobble as tscrob
from resources.lib.utils import store

class Player(xbmc.Player):
    def onPlayBackStarted(self):
        # scrobble start
        try:
            title = xbmc.getInfoLabel('VideoPlayer.Title')
            year = xbmc.getInfoLabel('VideoPlayer.Year')
            show = xbmc.getInfoLabel('VideoPlayer.TVshowtitle')
            season = xbmc.getInfoLabel('VideoPlayer.Season')
            episode = xbmc.getInfoLabel('VideoPlayer.Episode')
            if show:
                tscrob.scrobble_start_episode(show, season, episode)
            elif title:
                tscrob.scrobble_start_movie(title, year)
        except: pass

    def onAVStarted(self):
        try:
            if not get_bool('auto_subs'): return
            title = xbmc.getInfoLabel('VideoPlayer.Title') or xbmc.getInfoLabel('VideoPlayer.OriginalTitle')
            year = xbmc.getInfoLabel('VideoPlayer.Year')
            if title:
                path = opensubs.auto_subtitle_for({'title': title, 'year': year})
                if path: xbmc.Player().setSubtitles(path)
                # marcar nextup local
                try:
                    show = xbmc.getInfoLabel('VideoPlayer.TVshowtitle')
                    season = xbmc.getInfoLabel('VideoPlayer.Season')
                    episode = xbmc.getInfoLabel('VideoPlayer.Episode')
                    if show and season and episode:
                        store.add_episode_play(show, int(season), int(episode))
                except: pass
        except: pass

    def onPlayBackEnded(self):
        # scrobble stop
        try:
            title = xbmc.getInfoLabel('VideoPlayer.Title')
            year = xbmc.getInfoLabel('VideoPlayer.Year')
            show = xbmc.getInfoLabel('VideoPlayer.TVshowtitle')
            season = xbmc.getInfoLabel('VideoPlayer.Season')
            episode = xbmc.getInfoLabel('VideoPlayer.Episode')
            if show:
                tscrob.scrobble_stop_episode(show, season, episode)
            elif title:
                tscrob.scrobble_stop_movie(title, year)
        except: pass

class Service(xbmc.Monitor):
    def __init__(self): super().__init__(); self.player = Player()
    def run(self):
        while not self.abortRequested():
            if self.waitForAbort(1): break

if __name__ == "__main__":
    Service().run()
