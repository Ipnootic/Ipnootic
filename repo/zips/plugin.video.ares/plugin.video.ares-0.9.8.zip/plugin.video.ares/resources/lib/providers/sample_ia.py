# -*- coding: utf-8 -*-
from .base import ProviderBase

# Provider de exemplo (liga a conteúdos de domínio público / demonstração)
class SampleIA(ProviderBase):
    name = "sample-ia"

    def search_movie(self, title, year, tmdb_id=None):
        # Exemplo: Big Buck Bunny (domínio público) – link direto http(s)
        return [{
            "url": "https://archive.org/download/BigBuckBunny_328/BigBuckBunny_512kb.mp4",
            "quality": "SD",
            "size": 270,  # MB (estimado)
            "provider": self.name
        }]
