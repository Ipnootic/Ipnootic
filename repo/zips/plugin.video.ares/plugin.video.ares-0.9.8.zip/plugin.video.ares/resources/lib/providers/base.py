# -*- coding: utf-8 -*-
from typing import List, Dict, Any, Optional

class ProviderBase:
    name: str = "base"

    def search_movie(
        self, title: str, year: int, tmdb_id: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        return []

    def search_episode(
        self, title: str, season: int, episode: int,
        year: Optional[int] = None, tmdb_id: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        return []
