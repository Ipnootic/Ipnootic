# -*- coding: utf-8 -*-
from typing import List, Dict, Any, Optional
from . import registry
from .. import rd
import xbmc


def collect_sources_movie(title: str, year: int, tmdb_id: int = None, provider: Optional[str] = None) -> List[Dict[str, Any]]:
    """
    Recolhe fontes para FILME a partir do(s) provider(s) registados.
    Se 'provider' vier definido (ex.: 'coco'), filtra apenas esse.
    """
    items = registry.search_movie(title, year, tmdb_id, provider=provider)
    xbmc.log(f"[Ares][pipeline] {len(items)} fontes (pré-resolve) movie provider={provider}", xbmc.LOGINFO)
    return items


def collect_sources_episode(title: str, season: int, episode: int, year: int = None, tmdb_id: int = None,
                            provider: Optional[str] = None) -> List[Dict[str, Any]]:
    """
    Recolhe fontes para EPISÓDIO (S/E). Se 'provider' vier definido (ex.: 'coco'), filtra apenas esse.
    """
    items = registry.search_episode(title, season, episode, year, tmdb_id, provider=provider)
    xbmc.log(f"[Ares][pipeline] {len(items)} fontes (pré-resolve) episode provider={provider}", xbmc.LOGINFO)
    return items


def resolve_source(item: Dict[str, Any]) -> str:
    """
    Resolve a fonte (magnet/hoster) através do Real-Debrid (ou outro resolver no futuro).
    """
    url = item.get("url")
    return rd.resolve(url)
