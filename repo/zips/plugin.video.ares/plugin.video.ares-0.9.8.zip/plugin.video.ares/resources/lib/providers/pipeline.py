# -*- coding: utf-8 -*-
from typing import List, Dict, Any, Optional
from . import registry
from .. import rd
import xbmc


def collect_sources_movie(title: str, year: int, tmdb_id: int = None, provider: Optional[str] = None) -> List[Dict[str, Any]]:
    """
    Recolhe fontes para FILME a partir do(s) provider(s) registados.
    Se 'provider' vier definido (ex.: 'coco'), filtra apenas esse.
    """
    items = registry.search_movie(title, year, tmdb_id, provider=provider)
    xbmc.log(f"[Ares][pipeline] {len(items)} fontes (pré-resolve) movie provider={provider or 'all'}", xbmc.LOGINFO)
    return items


def collect_sources_episode(title: str, season: int, episode: int, year: int = None, tmdb_id: int = None,
                            provider: Optional[str] = None) -> List[Dict[str, Any]]:
    """
    Recolhe fontes para EPISÓDIO (S/E). Se 'provider' vier definido (ex.: 'coco'), filtra apenas esse.
    """
    items = registry.search_episode(title, season, episode, year, tmdb_id, provider=provider)
    xbmc.log(
        f"[Ares][pipeline] {len(items)} fontes (pré-resolve) episode S{season:02d}E{episode:02d} provider={provider or 'all'}",
        xbmc.LOGINFO
    )
    return items


def resolve_source(item: Dict[str, Any]) -> str:
    """
    Resolve a fonte (magnet/hoster) através do Real-Debrid (ou outro resolver no futuro).
    Lança ValueError se o item não tiver URL.
    """
    url = item.get("url") or ""
    if not url:
        xbmc.log("[Ares][pipeline] item sem 'url' ao tentar resolver fonte", xbmc.LOGERROR)
        raise ValueError("Fonte inválida (sem URL)")
    return rd.resolve(url)
