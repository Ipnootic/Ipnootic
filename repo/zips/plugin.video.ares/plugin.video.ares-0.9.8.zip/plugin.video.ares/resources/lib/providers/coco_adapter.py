# -*- coding: utf-8 -*-
import importlib
import inspect
import pkgutil
from typing import List, Dict, Any, Callable, Optional, Tuple
from .base import ProviderBase
import xbmc

# tentamos importar TMDb helpers para obter imdb_id/ano/tvdb a partir de tmdb_id (opcional)
try:
    from ..scrapers import tmdb as tmdb_api
except Exception:
    tmdb_api = None


class CocoAdapter(ProviderBase):
    """
    Adapter para CocoScrapers:
      - Detecta classe Sources (caminho mais estável entre versões/forks)
      - Aceita múltiplas assinaturas de função
      - Suporta filmes e episódios
      - Enriquecimento opcional de imdb_id e year via TMDb
      - Fallback LEGACY: cocoscrapers.sources -> providers -> module().sources(info)
      - Patches NÃO invasivos para evitar "0 fontes" por settings OFF
    """
    name = "coco"

    def __init__(self):
        self._movie_callers: List[Callable] = []
        self._episode_callers: List[Callable] = []
        self._sources_obj = None
        self._legacy_sources_fn: Optional[Callable] = None

        # 0) Addon instalado?
        try:
            if not xbmc.getCondVisibility("System.HasAddon(script.module.cocoscrapers)"):
                xbmc.log("[Ares][prov][coco] script.module.cocoscrapers não instalado.", xbmc.LOGINFO)
                return
        except Exception:
            pass

        # 0a) PATCH: força ON em toggles comuns do Coco (runtime; não grava ficheiros)
        self._force_enable_coco_settings()

        # 1) Tenta detetar classe Sources
        for modname in ("cocoscrapers.modules.sources", "cocoscrapers.sources", "cocoscrapers.sources_cocoscrapers"):
            try:
                m = importlib.import_module(modname)
                Sources = getattr(m, "Sources", None)
                if Sources:
                    try:
                        self._sources_obj = Sources()
                    except TypeError:
                        self._sources_obj = Sources(silent=True)
                    break
            except Exception:
                continue

        # 1b) Scan do pacote para achar Sources em forks
        if not self._sources_obj:
            try:
                import cocoscrapers
                for mod in pkgutil.walk_packages(cocoscrapers.__path__, cocoscrapers.__name__ + "."):
                    name_l = mod.name.lower()
                    if "source" in name_l and "resolver" not in name_l:
                        try:
                            m = importlib.import_module(mod.name)
                            Sources = getattr(m, "Sources", None)
                            if Sources:
                                try:
                                    self._sources_obj = Sources()
                                except TypeError:
                                    self._sources_obj = Sources(silent=True)
                                xbmc.log(f"[Ares][prov][coco] Sources encontrado em {mod.name}", xbmc.LOGINFO)
                                break
                        except Exception:
                            continue
            except Exception as e:
                xbmc.log(f"[Ares][prov][coco] scan Sources falhou: {e}", xbmc.LOGDEBUG)

        # 2) Regista potenciais métodos (ordem por prioridade)
        if self._sources_obj:
            for n in ("get_movie_sources", "movie", "get_sources", "sources", "results"):
                f = getattr(self._sources_obj, n, None)
                if callable(f):
                    self._movie_callers.append(f)
            for n in ("get_episode_sources", "episode", "get_sources", "sources", "results"):
                f = getattr(self._sources_obj, n, None)
                if callable(f):
                    self._episode_callers.append(f)

        # 3) Fallback top-level
        if not self._movie_callers:
            for modname, fname in [
                ("cocoscrapers", "scrape_movie"),
                ("cocoscrapers.api", "scrape_movie"),
                ("cocoscrapers.api", "results"),
                ("cocoscrapers", "get_movie_sources"),
            ]:
                try:
                    m = importlib.import_module(modname)
                    f = getattr(m, fname, None)
                    if callable(f):
                        self._movie_callers.append(f)
                except Exception:
                    continue

        if not self._episode_callers:
            for modname, fname in [
                ("cocoscrapers", "scrape_episode"),
                ("cocoscrapers.api", "scrape_episode"),
                ("cocoscrapers.api", "results"),
                ("cocoscrapers", "get_episode_sources"),
            ]:
                try:
                    m = importlib.import_module(modname)
                    f = getattr(m, fname, None)
                    if callable(f):
                        self._episode_callers.append(f)
                except Exception:
                    continue

        # 4) LEGACY: sources() -> [(name, class/module), ...]
        try:
            m = importlib.import_module("cocoscrapers")
            fn = getattr(m, "sources", None)
            if not callable(fn):
                m2 = importlib.import_module("cocoscrapers.sources")
                fn = getattr(m2, "sources", None)
            if callable(fn):
                self._legacy_sources_fn = fn
                xbmc.log("[Ares][prov][coco] legacy 'sources()' disponível.", xbmc.LOGINFO)
        except Exception:
            self._legacy_sources_fn = None

        if not (self._movie_callers or self._episode_callers or self._legacy_sources_fn):
            xbmc.log("[Ares][prov][coco] Não encontrei API pública do CocoScrapers (Sources/métodos/legacy).", xbmc.LOGWARNING)
        else:
            xbmc.log(
                f"[Ares][prov][coco] ligados movie={len(self._movie_callers)} "
                f"episode={len(self._episode_callers)} legacy={'sim' if self._legacy_sources_fn else 'não'}",
                xbmc.LOGINFO
            )
            # Log detalhado dos métodos encontrados
            if self._movie_callers:
                method_names = [getattr(f, '__name__', str(f)) for f in self._movie_callers]
                xbmc.log(f"[Ares][prov][coco] métodos movie: {method_names}", xbmc.LOGDEBUG)
            if self._episode_callers:
                method_names = [getattr(f, '__name__', str(f)) for f in self._episode_callers]
                xbmc.log(f"[Ares][prov][coco] métodos episode: {method_names}", xbmc.LOGDEBUG)

    # ---------- PATCH helper ----------
    def _force_enable_coco_settings(self):
        """
        Monkey-patch tolo mas seguro:
        - Se 'cocoscrapers.modules.control' existir, alteramos control.setting()
          p/ devolver 'true' em toggles óbvios (debrid/torrents/hosters/providers).
        - Tentamos também definir no addon do Coco as chaves mais comuns.
        Não toca em ficheiros, só runtime.
        """
        # 1) Monkey-patch control.setting
        cc = None
        for modname in ("cocoscrapers.modules.control", "cocoscrapers.control"):
            try:
                cc = importlib.import_module(modname)
                break
            except Exception:
                continue
        if cc and not getattr(cc, "_ares_patched", False):
            orig_setting = getattr(cc, "setting", None)

            def patched_setting(key, *a, **k):
                try:
                    kstr = str(key).lower()
                    if any(s in kstr for s in ("enable_external", "external_providers")):
                        return "true"
                    if ("provider" in kstr or "torrent" in kstr or "hoster" in kstr or "debrid" in kstr) and \
                       ("enable" in kstr or "enabled" in kstr):
                        return "true"
                except Exception:
                    pass
                if callable(orig_setting):
                    return orig_setting(key, *a, **k)
                return ""
            try:
                if callable(orig_setting):
                    cc.setting = patched_setting
                cc._ares_patched = True
                xbmc.log("[Ares][prov][coco] patched control.setting() -> toggles ON", xbmc.LOGINFO)
            except Exception as e:
                xbmc.log(f"[Ares][prov][coco] falha a patchar control.setting(): {e}", xbmc.LOGDEBUG)

        # 2) Tentativa "best-effort" de setar toggles via xbmcaddon
        try:
            import xbmcaddon
            ad = xbmcaddon.Addon("script.module.cocoscrapers")
            settings_applied = []
            settings_failed = []
            
            for key in (
                "debrid_enabled", "torrent_enabled", "hoster_enabled",
                "providers_enabled", "external_providers", "enable_external_providers",
                "enable_debrid", "enable_torrents", "enable_hosters", "enable_providers",
                "torrent.enabled", "hoster.enabled", "debrid.enabled"
            ):
                try:
                    ad.setSetting(key, "true")
                    settings_applied.append(key)
                except Exception as e:
                    settings_failed.append(f"{key}({e})")
            
            if settings_applied:
                xbmc.log(f"[Ares][prov][coco] configurações aplicadas: {settings_applied}", xbmc.LOGINFO)
            if settings_failed:
                xbmc.log(f"[Ares][prov][coco] configurações falharam: {settings_failed}", xbmc.LOGDEBUG)
                
        except Exception as e:
            xbmc.log(f"[Ares][prov][coco] erro ao aplicar configurações: {e}", xbmc.LOGDEBUG)

    # ---------------- helpers ----------------

    def _info_movie(self, title: str, year: Optional[int], tmdb_id: Optional[int], imdb_id: Optional[str]) -> Dict[str, Any]:
        y = int(year) if isinstance(year, (int, float, str)) and str(year).isdigit() else 0
        
        # Formato compatível com CocoScrapers
        info = {
            "title": title or "",
            "aliases": [title] if title else [],
            "year": y,
            "year_str": str(y) if y else "",
            "tmdb": tmdb_id or "",
            "tmdb_id": tmdb_id or "",
            "imdb": imdb_id or "",
            "imdb_id": imdb_id or "",
            "ids": {"tmdb": tmdb_id or "", "imdb": imdb_id or ""},
            "media": "movie",
            "media_type": "movie",
            # Campos adicionais que alguns scrapers podem esperar
            "originaltitle": title or "",
            "plot": "",
            "genre": [],
            "rating": 0,
            "votes": 0,
            "premiered": "",
            "studio": [],
            "cast": [],
            "director": [],
            "writer": [],
            "duration": 0
        }
        
        xbmc.log(f"[Ares][prov][coco] _info_movie resultado: {info}", xbmc.LOGDEBUG)
        return info

    def _info_episode(self, tvshow: str, season: int, episode: int, year: Optional[int], tmdb_id: Optional[int]) -> Dict[str, Any]:
        y = int(year) if isinstance(year, (int, float, str)) and str(year).isdigit() else 0
        
        # Formato compatível com CocoScrapers
        info = {
            "tvshowtitle": tvshow or "",
            "title": tvshow or "",  # alguns scrapers esperam 'title' para séries
            "aliases": [tvshow] if tvshow else [],
            "year": y,
            "year_str": str(y) if y else "",
            "season": str(season) if season is not None else "1",
            "episode": str(episode) if episode is not None else "1",
            "tmdb": tmdb_id or "",
            "tmdb_id": tmdb_id or "",
            "tvdb": "",
            "tvdb_id": "",
            "imdb": "",
            "imdb_id": "",
            "ids": {"tmdb": tmdb_id or "", "imdb": "", "tvdb": ""},
            "media": "episode",
            "media_type": "episode",
            # Campos adicionais para episódios
            "plot": "",
            "rating": 0,
            "votes": 0,
            "premiered": "",
            "genre": [],
            "studio": [],
            "cast": [],
            "director": [],
            "writer": [],
            "duration": 0,
            "episodeguide": ""
        }
        
        xbmc.log(f"[Ares][prov][coco] _info_episode resultado: {info}", xbmc.LOGDEBUG)
        return info

    def _enrich_movie_imdb(self, info: Dict[str, Any]) -> Dict[str, Any]:
        if not info.get("imdb_id") and info.get("tmdb_id") and tmdb_api and hasattr(tmdb_api, "get_movie_external_ids"):
            try:
                ex = tmdb_api.get_movie_external_ids(int(info["tmdb_id"])) or {}
                imdb = ex.get("imdb_id") or ex.get("imdb")
                if imdb:
                    info["imdb"] = info["imdb_id"] = imdb
                    info.setdefault("ids", {}).update({"imdb": imdb})
            except Exception as e:
                xbmc.log(f"[Ares][prov][coco] enrich imdb(movie) falhou: {e}", xbmc.LOGDEBUG)
        return info

    def _enrich_tv_imdb(self, info: Dict[str, Any]) -> Dict[str, Any]:
        if not info.get("imdb_id") and info.get("tmdb_id") and tmdb_api and hasattr(tmdb_api, "get_tv_external_ids"):
            try:
                ex = tmdb_api.get_tv_external_ids(int(info["tmdb_id"])) or {}
                imdb = ex.get("imdb_id") or ex.get("imdb")
                tvdb = ex.get("tvdb_id") or ex.get("tvdb")
                if imdb:
                    info["imdb"] = info["imdb_id"] = imdb
                    info.setdefault("ids", {}).update({"imdb": imdb})
                if tvdb:
                    try:
                        tvdb_val = int(tvdb)
                    except Exception:
                        tvdb_val = tvdb
                    info["tvdb"] = info["tvdb_id"] = tvdb_val
                    info.setdefault("ids", {}).update({"tvdb": tvdb_val})
            except Exception as e:
                xbmc.log(f"[Ares][prov][coco] enrich imdb/tvdb(tv) falhou: {e}", xbmc.LOGDEBUG)
        return info

    def _enrich_movie_year(self, info: Dict[str, Any]) -> Dict[str, Any]:
        if (info.get("year") or 0) > 0 or not (tmdb_api and info.get("tmdb_id")):
            return info
        try:
            data = None
            for fn_name in ("get_movie_details", "get_movie", "movie_details", "details_movie"):
                fn = getattr(tmdb_api, fn_name, None)
                if callable(fn):
                    data = fn(int(info["tmdb_id"])) or {}
                    break
            if isinstance(data, dict):
                d = (data.get("release_date") or data.get("first_air_date") or "")[:4]
                if d.isdigit():
                    info["year"] = int(d); info["year_str"] = d
        except Exception as e:
            xbmc.log(f"[Ares][prov][coco] enrich year(movie) falhou: {e}", xbmc.LOGDEBUG)
        return info

    def _enrich_tv_year(self, info: Dict[str, Any]) -> Dict[str, Any]:
        if (info.get("year") or 0) > 0 or not (tmdb_api and info.get("tmdb_id")):
            return info
        try:
            data = None
            for fn_name in ("get_tv_details", "get_tv", "tv_details", "details_tv"):
                fn = getattr(tmdb_api, fn_name, None)
                if callable(fn):
                    data = fn(int(info["tmdb_id"])) or {}
                    break
            if isinstance(data, dict):
                d = (data.get("first_air_date") or data.get("release_date") or "")[:4]
                if d.isdigit():
                    info["year"] = int(d); info["year_str"] = d
        except Exception as e:
            xbmc.log(f"[Ares][prov][coco] enrich year(tv) falhou: {e}", xbmc.LOGDEBUG)
        return info

    def _call_prep_then_results(self, media_token: str, info: Dict[str, Any]) -> Any:
        """
        Alguns forks expõem .results() apenas depois de correr .get_sources(...)
        """
        if not self._sources_obj:
            return []
        prep_funcs = [
            getattr(self._sources_obj, "get_sources", None),
            getattr(self._sources_obj, "get_movie_sources", None) if media_token == "movie" else getattr(self._sources_obj, "get_episode_sources", None),
            getattr(self._sources_obj, "sources", None),
            getattr(self._sources_obj, "movie", None) if media_token == "movie" else getattr(self._sources_obj, "episode", None),
        ]
        for pf in prep_funcs:
            if not callable(pf):
                continue
            # tentar várias assinaturas comuns
            for a, k in [
                ((), {"info": info}),
                ((media_token, info), {}),
                ((info, media_token), {}),
                ((info,), {}),
            ]:
                try:
                    r = pf(*a, **k)
                    # não nos interessa o retorno aqui; só "preparar" o estado
                    break
                except TypeError:
                    continue
                except Exception as e:
                    xbmc.log(f"[Ares][prov][coco] prep {getattr(pf,'__name__','?')} falhou: {e}", xbmc.LOGDEBUG)
        # agora sim, tentar results()
        try:
            rf = getattr(self._sources_obj, "results", None)
            if callable(rf):
                for a, k in [((info,), {}), ((), {"info": info}), ((), {})]:
                    try:
                        res = rf(*a, **k)
                        if res:
                            return res
                    except TypeError:
                        continue
                    except Exception as e:
                        xbmc.log(f"[Ares][prov][coco] results() erro: {e}", xbmc.LOGDEBUG)
        except Exception:
            pass
        return []

    def _try_call(self, f: Callable, media_token: str, *args, **kwargs):
        """
        Tenta várias assinaturas; aceita retorno não-vazio.
        Se f for 'results', primeiro corre uma preparação.
        """
        info = kwargs.pop("info", None)
        # results? preparar
        if getattr(f, "__name__", "") == "results" and info is not None:
            res = self._call_prep_then_results(media_token, info)
            if res:
                return res

        attempts: List[Tuple[Tuple, Dict[str, Any]]] = []
        if info is not None:
            attempts += [
                ((), {"info": info}),
                ((media_token, info), {}),
                ((info, media_token), {}),
                ((info,), {}),
                ((), {"media": media_token, "info": info}),
                ((), {"media_type": media_token, "info": info}),
            ]
        if kwargs:
            attempts.append(((), kwargs))
        if args:
            attempts.append((args, {}))

        for i, (a, k) in enumerate(attempts):
            try:
                xbmc.log(f"[Ares][prov][coco] tentativa {i+1}/{len(attempts)} para {getattr(f,'__name__',f)}: args={a}, kwargs={list(k.keys())}", xbmc.LOGDEBUG)
                res = f(*a, **k)
                if res:
                    xbmc.log(f"[Ares][prov][coco] sucesso na tentativa {i+1}: {len(res) if isinstance(res, list) else 'não é lista'} resultados", xbmc.LOGDEBUG)
                    return res
                else:
                    xbmc.log(f"[Ares][prov][coco] tentativa {i+1} retornou vazio", xbmc.LOGDEBUG)
                continue
            except TypeError as e:
                xbmc.log(f"[Ares][prov][coco] tentativa {i+1} falhou (TypeError): {e}", xbmc.LOGDEBUG)
                continue
            except Exception as e:
                xbmc.log(f"[Ares][prov][coco] erro a invocar {getattr(f,'__name__',f)} tentativa {i+1}: {e}", xbmc.LOGERROR)
                continue
        xbmc.log(f"[Ares][prov][coco] todas as {len(attempts)} tentativas falharam para {getattr(f,'__name__',f)}", xbmc.LOGWARNING)
        return []

    def _as_int(self, v, default=0) -> int:
        try:
            if v is None:
                return default
            if isinstance(v, (int, float)):
                return int(v)
            s = str(v).lower().strip()
            mult = 1
            if "gb" in s:
                mult = 1024
            s = s.replace("gb", "").replace("mb", "").strip()
            return int(float(s) * mult)
        except Exception:
            return default

    def _extract_list(self, data) -> list:
        if not data:
            return []
        try:
            if not isinstance(data, (list, dict, tuple, set)) and hasattr(data, "__iter__"):
                data = list(data)
        except Exception:
            pass
        if isinstance(data, (set, tuple)):
            data = list(data)
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            for k in ("results", "sources", "items", "all_results", "sorted_sources", "streams"):
                v = data.get(k)
                if isinstance(v, list):
                    return v
            combined = []
            for k in ("torrents", "hosters", "hoster", "torrent"):
                v = data.get(k)
                if isinstance(v, list):
                    combined.extend(v)
            if combined:
                return combined
        return []

    def _normalize(self, items) -> List[Dict[str, Any]]:
        out: List[Dict[str, Any]] = []
        lst = self._extract_list(items)
        for i in lst:
            try:
                if isinstance(i, dict):
                    url = i.get("url") or i.get("link") or i.get("magnet") or i.get("stream")
                    quality = i.get("quality") or i.get("res") or i.get("info") or ""
                    size = i.get("size") or i.get("filesize") or i.get("size_mb") or 0
                    scraper = i.get("provider") or i.get("scraper") or ""   # origem real
                    seeders = self._as_int(i.get("seeders"), 0)
                    release = i.get("release_title") or i.get("release") or ""
                    lang = (i.get("audio_lang") or i.get("lang") or "").lower()
                    source = i.get("source") or ""
                else:
                    url = getattr(i, "url", None) or getattr(i, "link", None) or getattr(i, "magnet", None) or getattr(i, "stream", None)
                    quality = getattr(i, "quality", "") or getattr(i, "res", "") or getattr(i, "info", "") or ""
                    size = getattr(i, "size", 0) or getattr(i, "filesize", 0) or 0
                    scraper = getattr(i, "provider", None) or getattr(i, "scraper", None) or ""
                    seeders = self._as_int(getattr(i, "seeders", 0), 0)
                    release = getattr(i, "release_title", "") or getattr(i, "release", "") or ""
                    lang = (getattr(i, "audio_lang", "") or getattr(i, "lang", "") or "").lower()
                    source = getattr(i, "source", "") or ""
                if not url:
                    continue
                out.append({
                    "url": url,
                    "quality": str(quality),
                    "size": self._as_int(size, 0),
                    "provider": self.name,        # chave para pipelines que filtram por "coco"
                    "scraper": scraper,           # origem real (ex.: 1337x, bitsearch, etc.)
                    "seeders": seeders,
                    "release": release,
                    "audio_lang": lang,
                    "source": source,
                })
            except Exception:
                continue
        return out

    # -------- LEGACY providers() fallback --------

    def _legacy_list_providers(self, media_token: str, info: Dict[str, Any]) -> List[Tuple[str, Any]]:
        if not self._legacy_sources_fn:
            return []
        tries = [
            ((), {}),
            ((info,), {}),
            ((media_token, info), {}),
            ((info, media_token), {}),
            ((), {"info": info}),
            ((), {"media": media_token, "info": info})
        ]
        for a, k in tries:
            try:
                res = self._legacy_sources_fn(*a, **k)
                if isinstance(res, list) and (not res or (isinstance(res[0], (tuple, list)) and len(res[0]) == 2)):
                    return res
            except TypeError:
                continue
            except Exception as e:
                xbmc.log(f"[Ares][prov][coco] legacy sources() falhou: {e}", xbmc.LOGERROR)
                return []
        return []

    def _legacy_collect(self, media_token: str, providers: List[Tuple[str, Any]], info: Dict[str, Any]) -> List[Dict[str, Any]]:
        all_items: List[Dict[str, Any]] = []
        for name, module in (providers or []):
            try:
                cls = module if inspect.isclass(module) else getattr(module, "source", None) or getattr(module, "Source", None)
                if not cls:
                    continue
                try:
                    inst = cls()
                except TypeError:
                    try:
                        inst = cls(silent=True)
                    except Exception:
                        inst = cls
                src_fn = getattr(inst, "sources", None)
                if not callable(src_fn):
                    continue
                res = None
                for a, k in [((info,), {}), ((media_token, info), {}), ((), {"info": info})]:
                    try:
                        res = src_fn(*a, **k)
                        break
                    except TypeError:
                        continue
                norm = self._normalize(res)
                if norm:
                    for it in norm:
                        it.setdefault("scraper", name or it.get("scraper", ""))
                    all_items.extend(norm)
            except Exception as e:
                xbmc.log(f"[Ares][prov][coco] legacy provider '{name}' erro: {e}", xbmc.LOGERROR)
        xbmc.log(f"[Ares][prov][coco] legacy agregou {len(all_items)} fontes de {len(providers)} providers", xbmc.LOGINFO)
        return all_items

    # ---------------- API Ares ----------------

    def search_movie(self, title: str, year: int, tmdb_id: int = None) -> List[Dict[str, Any]]:
        xbmc.log(f"[Ares][prov][coco] search_movie iniciado: '{title}' ({year}) tmdb_id={tmdb_id}", xbmc.LOGINFO)
        
        callers = list(self._movie_callers)
        xbmc.log(f"[Ares][prov][coco] {len(callers)} movie callers disponíveis", xbmc.LOGDEBUG)
        
        info = self._info_movie(title, year, tmdb_id, imdb_id=None)
        info = self._enrich_movie_imdb(info)
        info = self._enrich_movie_year(info)
        xbmc.log(f"[Ares][prov][coco] info enriquecida: {info}", xbmc.LOGDEBUG)

        aggregated: List[Dict[str, Any]] = []
        imdb_kw = info.get("imdb") or info.get("imdb_id")

        for i, f in enumerate(callers):
            xbmc.log(f"[Ares][prov][coco] tentando caller {i+1}/{len(callers)}: {getattr(f, '__name__', f)}", xbmc.LOGDEBUG)
            res = self._try_call(
                f, "movie",
                info=info,
                title=title,
                year=info.get("year", 0),
                tmdb_id=tmdb_id,
                imdb=imdb_kw,
                imdb_id=imdb_kw
            )
            normalized = self._normalize(res)
            xbmc.log(f"[Ares][prov][coco] caller {i+1} retornou {len(normalized)} fontes", xbmc.LOGDEBUG)
            aggregated.extend(normalized)

        legacy_provs = self._legacy_list_providers("movie", info)
        xbmc.log(f"[Ares][prov][coco] {len(legacy_provs)} legacy providers encontrados", xbmc.LOGDEBUG)
        if legacy_provs:
            legacy_results = self._legacy_collect("movie", legacy_provs, info)
            xbmc.log(f"[Ares][prov][coco] legacy providers retornaram {len(legacy_results)} fontes", xbmc.LOGDEBUG)
            aggregated.extend(legacy_results)

        xbmc.log(f"[Ares][prov][coco] total fontes(movie) agregadas={len(aggregated)}", xbmc.LOGINFO)
        
        # Log de amostra das fontes encontradas (primeiras 3)
        if aggregated:
            sample = aggregated[:3]
            for i, source in enumerate(sample):
                quality = source.get('quality', 'unknown')
                scraper = source.get('scraper', 'unknown')
                url_preview = source.get('url', '')[:50] + '...' if len(source.get('url', '')) > 50 else source.get('url', '')
                xbmc.log(f"[Ares][prov][coco] fonte {i+1}: {quality} de {scraper} ({url_preview})", xbmc.LOGDEBUG)
        
        return aggregated

    def search_episode(self, title: str, season: int, episode: int, year: int = None, tmdb_id: int = None) -> List[Dict[str, Any]]:
        xbmc.log(f"[Ares][prov][coco] search_episode iniciado: '{title}' S{season:02d}E{episode:02d} ({year}) tmdb_id={tmdb_id}", xbmc.LOGINFO)
        
        callers = list(self._episode_callers) or list(self._movie_callers)
        xbmc.log(f"[Ares][prov][coco] {len(callers)} episode callers disponíveis", xbmc.LOGDEBUG)
        
        info = self._info_episode(title, season, episode, year, tmdb_id)
        info = self._enrich_tv_imdb(info)
        info = self._enrich_tv_year(info)
        xbmc.log(f"[Ares][prov][coco] info enriquecida: {info}", xbmc.LOGDEBUG)

        aggregated: List[Dict[str, Any]] = []
        imdb_kw = info.get("imdb") or info.get("imdb_id")
        tvdb_kw = info.get("tvdb") or info.get("tvdb_id")

        for i, f in enumerate(callers):
            xbmc.log(f"[Ares][prov][coco] tentando caller {i+1}/{len(callers)}: {getattr(f, '__name__', f)}", xbmc.LOGDEBUG)
            res = self._try_call(
                f, "episode",
                info=info,
                title=title,
                year=info.get("year", 0),
                season=season,
                episode=episode,
                tmdb_id=tmdb_id,
                imdb=imdb_kw,
                imdb_id=imdb_kw,
                tvdb=tvdb_kw,
                tvdb_id=tvdb_kw
            )
            normalized = self._normalize(res)
            xbmc.log(f"[Ares][prov][coco] caller {i+1} retornou {len(normalized)} fontes", xbmc.LOGDEBUG)
            aggregated.extend(normalized)

        legacy_provs = self._legacy_list_providers("episode", info)
        xbmc.log(f"[Ares][prov][coco] {len(legacy_provs)} legacy providers encontrados", xbmc.LOGDEBUG)
        if legacy_provs:
            legacy_results = self._legacy_collect("episode", legacy_provs, info)
            xbmc.log(f"[Ares][prov][coco] legacy providers retornaram {len(legacy_results)} fontes", xbmc.LOGDEBUG)
            aggregated.extend(legacy_results)

        xbmc.log(f"[Ares][prov][coco] total fontes(episode) agregadas={len(aggregated)}", xbmc.LOGINFO)
        
        # Log de amostra das fontes encontradas (primeiras 3)
        if aggregated:
            sample = aggregated[:3]
            for i, source in enumerate(sample):
                quality = source.get('quality', 'unknown')
                scraper = source.get('scraper', 'unknown')
                url_preview = source.get('url', '')[:50] + '...' if len(source.get('url', '')) > 50 else source.get('url', '')
                xbmc.log(f"[Ares][prov][coco] fonte {i+1}: {quality} de {scraper} ({url_preview})", xbmc.LOGDEBUG)
        
        return aggregated
