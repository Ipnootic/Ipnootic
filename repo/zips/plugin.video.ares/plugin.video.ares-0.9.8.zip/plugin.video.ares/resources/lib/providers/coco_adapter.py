# -*- coding: utf-8 -*-
import importlib
import inspect
from typing import List, Dict, Any, Callable, Optional, Tuple
from .base import ProviderBase
import xbmc

# tentamos importar TMDb helpers para obter imdb_id a partir de tmdb_id (opcional)
try:
    from ..scrapers import tmdb as tmdb_api
except Exception:
    tmdb_api = None


class CocoAdapter(ProviderBase):
    """
    Adapter para CocoScrapers:
      - Detecta classe Sources (caminho mais estável entre versões/forks)
      - Aceita múltiplas assinaturas de função
      - Suporta filmes e episódios
      - Enriquecimento opcional de imdb_id via TMDb (melhora match em alguns providers)
      - Fallback LEGACY: cocoscrapers.sources -> providers -> module().sources(info)
    """
    name = "coco"

    def __init__(self):
        self._movie_callers: List[Callable] = []
        self._episode_callers: List[Callable] = []
        self._sources_obj = None
        self._legacy_sources_fn: Optional[Callable] = None  # cocoscrapers.sources

        # 0) Addon instalado?
        try:
            if not xbmc.getCondVisibility("System.HasAddon(script.module.cocoscrapers)"):
                xbmc.log("[Ares][prov][coco] script.module.cocoscrapers não instalado.", xbmc.LOGINFO)
                return
        except Exception:
            pass

        # 1) Tenta detetar classe Sources (mais comum e estável)
        for modname in ("cocoscrapers.modules.sources", "cocoscrapers.sources"):
            try:
                m = importlib.import_module(modname)
                Sources = getattr(m, "Sources", None)
                if Sources:
                    try:
                        self._sources_obj = Sources()
                    except TypeError:
                        # algumas versões aceitam silent=True
                        self._sources_obj = Sources(silent=True)
                    break
            except Exception:
                continue

        # 2) Se existir objeto Sources, agrega possíveis métodos públicos
        if self._sources_obj:
            for n in ("get_movie_sources", "movie", "get_sources", "sources"):
                f = getattr(self._sources_obj, n, None)
                if callable(f):
                    self._movie_callers.append(f)
            for n in ("get_episode_sources", "episode", "get_sources", "sources"):
                f = getattr(self._sources_obj, n, None)
                if callable(f):
                    self._episode_callers.append(f)

        # 3) Como fallback residual, tenta funções top-level
        if not self._movie_callers:
            for modname, fname in [
                ("cocoscrapers", "scrape_movie"),
                ("cocoscrapers.api", "scrape_movie"),
                ("cocoscrapers", "get_movie_sources"),
            ]:
                try:
                    m = importlib.import_module(modname)
                    f = getattr(m, fname, None)
                    if callable(f):
                        self._movie_callers.append(f)
                except Exception:
                    continue

        if not self._episode_callers:
            for modname, fname in [
                ("cocoscrapers", "scrape_episode"),
                ("cocoscrapers.api", "scrape_episode"),
                ("cocoscrapers", "get_episode_sources"),
            ]:
                try:
                    m = importlib.import_module(modname)
                    f = getattr(m, fname, None)
                    if callable(f):
                        self._episode_callers.append(f)
                except Exception:
                    continue

        # 4) LEGACY: cocoscrapers.sources.sources -> lista de providers [(name, class), ...]
        try:
            m = importlib.import_module("cocoscrapers")
            fn = getattr(m, "sources", None)
            if not callable(fn):
                m2 = importlib.import_module("cocoscrapers.sources")
                fn = getattr(m2, "sources", None)
            if callable(fn):
                self._legacy_sources_fn = fn
                xbmc.log("[Ares][prov][coco] legacy 'sources()' disponível.", xbmc.LOGINFO)
        except Exception:
            self._legacy_sources_fn = None

        if not (self._movie_callers or self._episode_callers or self._legacy_sources_fn):
            xbmc.log("[Ares][prov][coco] Não encontrei API pública do CocoScrapers (Sources/métodos/legacy).", xbmc.LOGWARNING)
        else:
            xbmc.log(
                f"[Ares][prov][coco] ligados movie={len(self._movie_callers)} "
                f"episode={len(self._episode_callers)} legacy={'sim' if self._legacy_sources_fn else 'não'}",
                xbmc.LOGINFO
            )

    # ---------------- helpers ----------------

    def _info_movie(self, title: str, year: Optional[int], tmdb_id: Optional[int], imdb_id: Optional[str]) -> Dict[str, Any]:
        return {
            "title": title,
            "aliases": [title] if title else [],
            "year": year,
            "tmdb": tmdb_id,
            "tmdb_id": tmdb_id,
            "imdb": imdb_id,
            "imdb_id": imdb_id,
            "media": "movie",
            "media_type": "movie",
        }

    def _info_episode(self, tvshow: str, season: int, episode: int, year: Optional[int], tmdb_id: Optional[int]) -> Dict[str, Any]:
        return {
            "tvshowtitle": tvshow,
            "title": tvshow,  # sem nome do episódio aqui
            "aliases": [tvshow] if tvshow else [],
            "year": year,
            "season": str(season) if season is not None else None,
            "episode": str(episode) if episode is not None else None,
            "tmdb": tmdb_id,
            "tmdb_id": tmdb_id,
            "media": "episode",
            "media_type": "episode",
        }

    def _enrich_movie_imdb(self, info: Dict[str, Any]) -> Dict[str, Any]:
        """Se tivermos tmdb_id mas não imdb_id, tenta obter via TMDb (se o helper existir)."""
        if not info.get("imdb_id") and info.get("tmdb_id") and tmdb_api and hasattr(tmdb_api, "get_movie_external_ids"):
            try:
                ex = tmdb_api.get_movie_external_ids(int(info["tmdb_id"])) or {}
                imdb = ex.get("imdb_id") or ex.get("imdb")
                if imdb:
                    info["imdb"] = info["imdb_id"] = imdb
            except Exception as e:
                xbmc.log(f"[Ares][prov][coco] enrich imdb(movie) falhou: {e}", xbmc.LOGDEBUG)
        return info

    def _enrich_tv_imdb(self, info: Dict[str, Any]) -> Dict[str, Any]:
        """Episódios: imdb_id da série ajuda alguns scrapers."""
        if not info.get("imdb_id") and info.get("tmdb_id") and tmdb_api and hasattr(tmdb_api, "get_tv_external_ids"):
            try:
                ex = tmdb_api.get_tv_external_ids(int(info["tmdb_id"])) or {}
                imdb = ex.get("imdb_id") or ex.get("imdb")
                if imdb:
                    info["imdb"] = info["imdb_id"] = imdb
            except Exception as e:
                xbmc.log(f"[Ares][prov][coco] enrich imdb(tv) falhou: {e}", xbmc.LOGDEBUG)
        return info

    def _try_call(self, f: Callable, media_token: str, *args, **kwargs):
        """
        Tenta um leque de assinaturas típicas usadas em forks do Coco.
        media_token: "movie" ou "episode" (algumas versões exigem).
        """
        info = kwargs.pop("info", None)
        tries = []

        if info is not None:
            tries += [
                ((), {"info": info}),                  # Sources(...).get_sources(info=...)
                ((media_token, info), {}),             # Sources(...).get_sources("movie", info)
                ((info, media_token), {}),             # Sources(...).get_sources(info, "movie")
                ((info,), {}),                         # Sources(...).movie(info)
            ]

        # kwargs explícitos
        if kwargs:
            tries.append(((), kwargs))

        # tuplos "clássicos"
        if args:
            tries.append((args, {}))

        for a, k in tries:
            try:
                return f(*a, **k)
            except TypeError:
                continue
            except Exception as e:
                xbmc.log(f"[Ares][prov][coco] erro a invocar {getattr(f,'__name__',f)}: {e}", xbmc.LOGERROR)
                return []
        return []

    def _as_int(self, v, default=0) -> int:
        try:
            if v is None:
                return default
            if isinstance(v, (int, float)):
                return int(v)
            s = str(v).lower().strip()
            # lida com "1.5 gb", "1500 mb", etc. (aproxima para MB)
            mult = 1
            if "gb" in s:
                mult = 1024
            s = s.replace("gb", "").replace("mb", "").strip()
            return int(float(s) * mult)
        except Exception:
            return default

    def _extract_list(self, data) -> list:
        """
        Normaliza estruturas: lista direta, ou dicts com 'results' / 'sources' / 'items'.
        """
        if not data:
            return []
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            for k in ("results", "sources", "items"):
                v = data.get(k)
                if isinstance(v, list):
                    return v
        return []

    def _normalize(self, items) -> List[Dict[str, Any]]:
        out: List[Dict[str, Any]] = []
        lst = self._extract_list(items)
        for i in lst:
            try:
                if isinstance(i, dict):
                    url = i.get("url") or i.get("link") or i.get("magnet")
                    quality = i.get("quality") or i.get("res") or i.get("info") or ""
                    size = i.get("size") or i.get("filesize") or i.get("size_mb") or 0
                    provider = i.get("provider") or self.name
                    seeders = self._as_int(i.get("seeders"), 0)
                    release = i.get("release_title") or i.get("release") or ""
                    lang = (i.get("audio_lang") or i.get("lang") or "").lower()
                    source = i.get("source") or ""
                else:
                    # objetos simples com atributos
                    url = getattr(i, "url", None) or getattr(i, "link", None) or getattr(i, "magnet", None)
                    quality = getattr(i, "quality", "") or getattr(i, "res", "") or getattr(i, "info", "") or ""
                    size = getattr(i, "size", 0) or getattr(i, "filesize", 0) or 0
                    provider = getattr(i, "provider", None) or self.name
                    seeders = self._as_int(getattr(i, "seeders", 0), 0)
                    release = getattr(i, "release_title", "") or getattr(i, "release", "") or ""
                    lang = (getattr(i, "audio_lang", "") or getattr(i, "lang", "") or "").lower()
                    source = getattr(i, "source", "") or ""
                if not url:
                    continue
                out.append({
                    "url": url,
                    "quality": str(quality),
                    "size": self._as_int(size, 0),
                    "provider": provider,
                    "seeders": seeders,
                    "release": release,
                    "audio_lang": lang,
                    "source": source,
                })
            except Exception:
                continue
        return out

    # -------- LEGACY providers() fallback --------

    def _legacy_list_providers(self, media_token: str, info: Dict[str, Any]) -> List[Tuple[str, Any]]:
        """
        Chama cocoscrapers.sources(...) e devolve lista [(name, class/module), ...]
        Suporta várias assinaturas usadas nos forks.
        """
        if not self._legacy_sources_fn:
            return []
        tries = [
            ((), {}),                                 # sources()
            ((info,), {}),                            # sources(info)
            ((media_token, info), {}),                # sources("movie", info)
            ((info, media_token), {}),                # sources(info, "movie")
            ((), {"info": info}),                     # sources(info=...)
            ((), {"media": media_token, "info": info})# sources(media="movie", info=...)
        ]
        for a, k in tries:
            try:
                res = self._legacy_sources_fn(*a, **k)
                if isinstance(res, list) and (not res or (isinstance(res[0], (tuple, list)) and len(res[0]) == 2)):
                    return res
            except TypeError:
                continue
            except Exception as e:
                xbmc.log(f"[Ares][prov][coco] legacy sources() falhou: {e}", xbmc.LOGERROR)
                return []
        return []

    def _legacy_collect(self, media_token: str, providers: List[Tuple[str, Any]], info: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Para cada (name, module/class), instanciar e chamar .sources(info)
        """
        all_items: List[Dict[str, Any]] = []
        for name, module in (providers or []):
            try:
                cls = module if inspect.isclass(module) else getattr(module, "source", None) or getattr(module, "Source", None)
                if not cls:
                    continue
                try:
                    inst = cls()
                except TypeError:
                    try:
                        inst = cls(silent=True)
                    except Exception:
                        inst = cls  # último recurso se for callable
                src_fn = getattr(inst, "sources", None)
                if not callable(src_fn):
                    continue
                res = None
                for a, k in [((info,), {}), ((media_token, info), {}), ((), {"info": info})]:
                    try:
                        res = src_fn(*a, **k)
                        break
                    except TypeError:
                        continue
                norm = self._normalize(res)
                if norm:
                    for it in norm:
                        it.setdefault("provider", name or "coco")
                    all_items.extend(norm)
            except Exception as e:
                xbmc.log(f"[Ares][prov][coco] legacy provider '{name}' erro: {e}", xbmc.LOGERROR)
        xbmc.log(f"[Ares][prov][coco] legacy agregou {len(all_items)} fontes de {len(providers)} providers", xbmc.LOGINFO)
        return all_items

    # ---------------- API Ares ----------------

    def search_movie(self, title: str, year: int, tmdb_id: int = None) -> List[Dict[str, Any]]:
        callers = list(self._movie_callers)
        info = self._info_movie(title, year, tmdb_id, imdb_id=None)
        info = self._enrich_movie_imdb(info)

        aggregated: List[Dict[str, Any]] = []

        # dinâmica
        for f in callers:
            res = self._try_call(f, "movie", info=info, title=title, year=year, tmdb_id=tmdb_id)
            aggregated.extend(self._normalize(res))

        # legacy
        legacy_provs = self._legacy_list_providers("movie", info)
        if legacy_provs:
            aggregated.extend(self._legacy_collect("movie", legacy_provs, info))

        xbmc.log(f"[Ares][prov][coco] total fontes(movie) agregadas={len(aggregated)}", xbmc.LOGINFO)
        return aggregated

    def search_episode(self, title: str, season: int, episode: int, year: int = None, tmdb_id: int = None) -> List[Dict[str, Any]]:
        callers = list(self._episode_callers) or list(self._movie_callers)  # fallback: alguns forks usam mesmo entry
        info = self._info_episode(title, season, episode, year, tmdb_id)
        info = self._enrich_tv_imdb(info)

        aggregated: List[Dict[str, Any]] = []

        # dinâmica
        for f in callers:
            res = self._try_call(f, "episode", info=info, title=title, year=year, season=season, episode=episode, tmdb_id=tmdb_id)
            aggregated.extend(self._normalize(res))

        # legacy
        legacy_provs = self._legacy_list_providers("episode", info)
        if legacy_provs:
            aggregated.extend(self._legacy_collect("episode", legacy_provs, info))

        xbmc.log(f"[Ares][prov][coco] total fontes(episode) agregadas={len(aggregated)}", xbmc.LOGINFO)
        return aggregated
