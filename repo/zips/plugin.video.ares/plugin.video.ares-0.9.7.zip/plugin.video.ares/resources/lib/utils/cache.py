import os, json, time, xbmcvfs
from xbmcaddon import Addon
ADDON = Addon()
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
os.makedirs(PROFILE, exist_ok=True)
CACHE_FILE = os.path.join(PROFILE, "cache.json")

def _load():
    if os.path.exists(CACHE_FILE):
        try: return json.load(open(CACHE_FILE,'r',encoding='utf-8'))
        except: return {}
    return {}
def _save(d); _prune_max():
    json.dump(d, open(CACHE_FILE,'w',encoding='utf-8'))

def get(key, ttl=None):
from xbmcaddon import Addon
ADDON = Addon()
if ttl is None:
    try:
        ttl = int(ADDON.getSettingString('cache_ttl') or 1800)
    except:
        ttl = 1800
d = _load()
    item = d.get(key)
    if not item: return None
    if time.time() - item.get('ts',0) > ttl:
        d.pop(key, None); _save(d); _prune_max(); return None
    return item.get('value')

def set(key, value):
from xbmcaddon import Addon
ADDON = Addon()
if ttl is None:
    try:
        ttl = int(ADDON.getSettingString('cache_ttl') or 1800)
    except:
        ttl = 1800
d = _load()
    d[key] = {'ts': time.time(), 'value': value}
    _save(d); _prune_max()

def _prune_max():
    from xbmcaddon import Addon
    ADDON = Addon()
    try: limit = int(ADDON.getSettingString('cache_max_entries') or 200)
    except: limit = 200
    d = _load()
    if len(d) <= limit: return
    # remove mais antigos
    items = sorted(d.items(), key=lambda kv: kv[1].get('ts',0))
    for k,_ in items[:max(0, len(d)-limit)]:
        d.pop(k, None)
    _save(d); _prune_max()

def key_for_query(kind, title, season=None, episode=None, filters_key=""):
    base = f"{kind}|{title}|{season or ''}|{episode or ''}|{filters_key}"
    import hashlib
    return hashlib.md5(base.encode('utf-8')).hexdigest()
