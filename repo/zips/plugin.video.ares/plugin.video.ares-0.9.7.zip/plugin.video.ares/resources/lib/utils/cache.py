# plugin.video.ares/resources/lib/utils/cache.py
import os, json, time
from xbmcaddon import Addon
import xbmcvfs

ADDON = Addon()
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
os.makedirs(PROFILE, exist_ok=True)

CACHE_FILE = os.path.join(PROFILE, "cache.json")

def _load():
    try:
        with open(CACHE_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}

def _save(d):
    with open(CACHE_FILE, 'w', encoding='utf-8') as f:
        json.dump(d, f)

def _prune_max(d=None):
    if d is None:
        d = _load()
    try:
        limit = int(ADDON.getSettingString('cache_max_entries') or 200)
    except Exception:
        limit = 200
    if len(d) <= limit:
        return d
    items = sorted(d.items(), key=lambda kv: kv[1].get('ts', 0))
    for k, _ in items[:max(0, len(d) - limit)]:
        d.pop(k, None)
    return d

def get(key, ttl=None):
    if ttl is None:
        try:
            ttl = int(ADDON.getSettingString('cache_ttl') or 1800)
        except Exception:
            ttl = 1800
    d = _load()
    item = d.get(key)
    if not item:
        return None
    if time.time() - item.get('ts', 0) > ttl:
        d.pop(key, None)
        _save(d)
        return None
    return item.get('value')

def set(key, value):
    d = _load()
    d[key] = {'ts': time.time(), 'value': value}
    d = _prune_max(d)
    _save(d)

def key_for_query(kind, title, season=None, episode=None, filters_key=""):
    import hashlib
    base = f"{kind}|{title}|{season or ''}|{episode or ''}|{filters_key}"
    return hashlib.md5(base.encode('utf-8')).hexdigest()
