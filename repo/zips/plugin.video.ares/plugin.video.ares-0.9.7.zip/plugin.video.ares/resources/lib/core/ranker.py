from xbmcaddon import Addon
ADDON = Addon()

def _num(x, d=0.0):
    try: return float(x)
    except: return d

def filter_and_score(sources):
    min_seed = _num(ADDON.getSettingString('filters_min_seeders') or 0, 0)
    min_gb = _num(ADDON.getSettingString('filters_min_size_gb') or 0.0, 0.0)
    max_gb = _num(ADDON.getSettingString('filters_max_size_gb') or 0.0, 0.0)
    exclude_cam = ADDON.getSettingBool('exclude_cam_ts') if hasattr(ADDON,'getSettingBool') else False
    prefer_codecs = [c.strip().lower() for c in (ADDON.getSettingString('prefer_codecs') or '').split(',') if c.strip()] if hasattr(ADDON,'getSettingString') else []

    def bad(s):
        name = (s.get('title','') + ' ' + s.get('release','')).lower()
        if exclude_cam and (' cam ' in ' '+name+' ' or ' ts ' in name): return True
        if int(s.get('seeders',0)) < min_seed: return True
        gb = _num(s.get('size_gb',0), 0)
        if gb and gb < min_gb: return True
        if max_gb and gb and gb > max_gb: return True
        return False

    def score(s):
        sc = 0
        q = (s.get('quality') or '').lower()
        order = ['480p','720p','1080p','2160p']
        if q in order: sc += order.index(q)*10
        try: sc += int(_num(s.get('seeders',0),0))*0.1
        except: pass
        gb = _num(s.get('size_gb',0),0)
        sc += min(gb, 30)
        tag = (s.get('title','') + ' ' + s.get('release','')).lower()
        if any(c in tag for c in prefer_codecs): sc += 3
        if 'remux' in tag: sc += 4
        if 'cam' in tag or ' ts ' in tag: sc -= 50
        return sc

    valids = [s for s in sources if not bad(s)]
    return sorted(valids, key=score, reverse=True)

def _audio_tag(s):
    name = (s.get('title','') + ' ' + s.get('release','')).lower()
    # normalizar
    n = name.replace('.', ' ').replace('_', ' ').replace('-', ' ')
    # se provido explicitamente
    if s.get('audio_lang'): return s.get('audio_lang').lower()
    # Heurísticas comuns
    if 'pt-br' in n or 'pt br' in n or 'ptbr' in n or 'brasil' in n or 'dublado' in n:
        return 'pt-br'
    if 'pt-pt' in n or 'pt pt' in n or 'ptpt' in n or 'portugal' in n or 'pt por' in n:
        return 'pt-pt'
    if 'dub' in n and 'pt' in n and 'br' in n:
        return 'pt-br'
    if 'dual' in n and 'pt' in n and 'br' not in n:
        # muitos releases "dual pt-en" — marcar como pt-pt genérico
        return 'pt-pt'
    return ''

def filter_by_audio(sources, target):
    # target: 'pt-pt' ou 'pt-br'
    tgt = target.lower()
    out = []
    for s in sources:
        tag = _audio_tag(s)
        if tgt == 'pt-pt' and tag == 'pt-pt':
            out.append(s)
        elif tgt == 'pt-br' and tag == 'pt-br':
            out.append(s)
    return out
