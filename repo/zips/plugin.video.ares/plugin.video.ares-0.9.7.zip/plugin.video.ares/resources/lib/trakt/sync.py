import json, urllib.request, urllib.parse
from xbmcaddon import Addon
ADDON = Addon()
BASE = "https://api.trakt.tv"

def _headers():
    return {
        "Content-Type":"application/json",
        "trakt-api-version":"2",
        "trakt-api-key": ADDON.getSettingString('trakt_client_id'),
        "Authorization": "Bearer " + ADDON.getSettingString('trakt_access_token')
    }

def _get(path, params=None):
    url = BASE + path
    if params: url += "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers=_headers())
    with urllib.request.urlopen(req, timeout=20) as r:
        raw = r.read().decode('utf-8')
        try: return json.loads(raw)
        except: return {}

def _post(path, data):
    req = urllib.request.Request(BASE + path, data=json.dumps(data).encode('utf-8'), headers=_headers(), method="POST")
    with urllib.request.urlopen(req, timeout=20) as r:
        return json.loads(r.read().decode('utf-8'))

def _search_one(kind, title, year=None):
    q = {"query": title, "limit": 1}
    if year: q["years"] = str(year)
    res = _get("/search/" + kind, params=q)
    if isinstance(res, list) and res:
        item = res[0]
        ids = (item.get(kind) or {}).get("ids") or {}
        return ids
    return {}

def add_movie_watched(title, year=None):
    ids = _search_one("movie", title, year)
    if not ids.get("trakt"): return None
    return _post("/sync/history", {"movies":[{"ids": ids}]})

def remove_movie_watched(title, year=None):
    ids = _search_one("movie", title, year)
    if not ids.get("trakt"): return None
    return _post("/sync/history/remove", {"movies":[{"ids": ids}]})

def add_episode_watched(show_title, season, episode):
    ids = _search_one("show", show_title)
    if not ids.get("trakt"): return None
    payload = {"shows":[{"ids":{"trakt": ids["trakt"]}, "seasons":[{"number": int(season), "episodes":[{"number": int(episode)}]}]}]}
    return _post("/sync/history", payload)

def remove_episode_watched(show_title, season, episode):
    ids = _search_one("show", show_title)
    if not ids.get("trakt"): return None
    payload = {"shows":[{"ids":{"trakt": ids["trakt"]}, "seasons":[{"number": int(season), "episodes":[{"number": int(episode)}]}]}]}
    return _post("/sync/history/remove", payload)
