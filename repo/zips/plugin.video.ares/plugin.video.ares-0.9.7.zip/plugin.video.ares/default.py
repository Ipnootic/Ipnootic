import sys, urllib.parse
import xbmc, xbmcaddon, xbmcgui, xbmcplugin
ADDON = xbmcaddon.Addon()
from resources.lib.trakt import client as trakt
from resources.lib.utils import cache
from resources.lib.trakt import sync as trakt_sync
from resources.lib.trakt import progress as trakt_prog
from resources.lib.resolvers import rd_device as rdd
from resources.lib.subs import opensubs

HANDLE = int(sys.argv[1]); BASE_URL = sys.argv[0]
def build_url(q): return BASE_URL + "?" + urllib.parse.urlencode(q)

def router(params):
    action = params.get('action')
    if not action:
        preset = ADDON.getSettingString("menu_preset") or "0"
        xbmcplugin.addDirectoryItem(HANDLE, build_url({"action":"settings"}), xbmcgui.ListItem("⚙️ Settings"), False)
        xbmcplugin.addDirectoryItem(HANDLE, build_url({"action":"trakt_auth"}), xbmcgui.ListItem("Trakt: Autorizar"), False)
        if preset == "1":
        xbmcplugin.addDirectoryItem(HANDLE, build_url({"action":"rd_device"}), xbmcgui.ListItem("RD: Autorizar (Device)"), False)
        xbmcplugin.addDirectoryItem(HANDLE, build_url({"action":"rd_test"}), xbmcgui.ListItem("Testar RD"), False)
        xbmcplugin.addDirectoryItem(HANDLE, build_url({"action":"os_test"}), xbmcgui.ListItem("Testar OpenSubtitles"), False)

        xbmcplugin.addDirectoryItem(HANDLE, build_url({"action":"nextup"}), xbmcgui.ListItem("▶ Next Up"), True)
        xbmcplugin.addDirectoryItem(HANDLE, build_url({"action":"favs"}), xbmcgui.ListItem("★ Favoritos"), True)

                    xbmcplugin.addDirectoryItem(HANDLE, build_url({"action":"search_movie_ptpt"}), xbmcgui.ListItem("Filmes (Áudio PT-PT)"), False)
                    xbmcplugin.addDirectoryItem(HANDLE, build_url({"action":"search_tv_ptpt"}), xbmcgui.ListItem("Séries (Áudio PT-PT)"), False)
                    xbmcplugin.addDirectoryItem(HANDLE, build_url({"action":"search_movie_ptbr"}), xbmcgui.ListItem("Filmes (Áudio PT-BR)"), False)
                    xbmcplugin.addDirectoryItem(HANDLE, build_url({"action":"search_tv_ptbr"}), xbmcgui.ListItem("Séries (Áudio PT-BR)"), False)
        xbmcplugin.endOfDirectory(HANDLE); return

    if action == "settings":
        xbmcaddon.Addon().openSettings()

    elif action == "trakt_auth":
        try:
            dc = trakt.device_code()
            xbmcgui.Dialog().ok("Trakt", f"Código: [B]{dc.get('user_code')}[/B]\nVai a {dc.get('verification_url')} e introduz o código.")
            trakt.poll_for_token(dc.get('device_code'), interval=dc.get('interval',5), expires_in=dc.get('expires_in',600))
            xbmcgui.Dialog().notification("Trakt", "Autorizado com sucesso", xbmcgui.NOTIFICATION_INFO, 3000)
        except Exception as e:
            xbmcgui.Dialog().ok("Trakt", f"Falha: {e}")

    elif action == "rd_device":
        try:
            dc = rdd.device_code()
            xbmcgui.Dialog().ok("Real-Debrid", f"Código: [B]{dc.get('user_code')}[/B]\nAcede a real-debrid.com/device e introduz o código.")
            rdd.poll_for_token(dc.get('device_code'), interval=dc.get('interval',5))
            u = rdd.user()
            xbmcgui.Dialog().notification("Real-Debrid", f"Autorizado: {u.get('username')}", xbmcgui.NOTIFICATION_INFO, 3000)
        except Exception as e:
            xbmcgui.Dialog().ok("Real-Debrid", f"Falha: {e}")

    elif action == "search_movie":
        title = params.get("title")
        if not title:
            kb = xbmc.Keyboard("", "Título do filme"); kb.doModal()
            if not kb.isConfirmed(): xbmcplugin.endOfDirectory(HANDLE); return
            title = kb.getText()
        _rank_and_list("movie", title)
    elif action == "search_episode":
        t = params.get("title")
        if not t:
            kb = xbmc.Keyboard("", "Título da série"); kb.doModal();
            if not kb.isConfirmed(): xbmcplugin.endOfDirectory(HANDLE); return
            t = kb.getText()
        s = params.get("season") or "1"
        e = params.get("episode") or "1"
        _rank_and_list("episode", t, s, e)
    elif action == "rd_test":
        try:
            u = rdd.user()
            xbmcgui.Dialog().ok("Real-Debrid", f"Ligação OK\nUser: [B]{u.get('username')}[/B]")
        except Exception as e:
            xbmcgui.Dialog().ok("Real-Debrid", f"Falha: {e}")

    elif action == "playbest":
        import urllib.parse, xbmcgui, xbmc, xbmcplugin
        from resources.lib.core import aggregator, ranker
        from resources.lib.resolvers import rd_resolver
        kind = params.get('kind'); title = params.get('title')
        season = params.get('season'); episode = params.get('episode')
        idx = int(params.get('index','0'))
        key = cache.key_for_query(kind, title, season, episode, _filters_key()+ '|' + (audio or ''))
        cached = cache.get(key)
        if cached is not None:
            ranked = cached
        else:
            import json
        from resources.lib.core import aggregator, ranker
        import xbmcaddon
        if kind == 'movie':
            res = aggregator.search_movie(title)
        else:
            res = aggregator.search_episode(title, int(season), int(episode))
        if audio:
            res = ranker.filter_by_audio(res, audio)
        ranked = ranker.filter_and_score(res)
        cache.set(key, ranked)
        if not ranked: 
            xbmcgui.Dialog().ok("Ares", "Sem fontes encontradas (verifica scrapers instalados).")
        else:
            src = ranked[idx]
            try:
                stream = rd_resolver.resolve(src)
                li = xbmcgui.ListItem(path=stream)
                xbmcplugin.setResolvedUrl(HANDLE, True, li)
            except Exception as e:
                xbmcgui.Dialog().ok("Ares", f"Falha resolver: {e}")
    elif action == "os_test":
        p = opensubs.auto_subtitle_for({"title":"Inception","year":"2010"})
        xbmcgui.Dialog().ok("OpenSubtitles", f"{'OK → ' + p if p else 'Falha: API Key/ligação'}")

    xbmcplugin.endOfDirectory(HANDLE)

if __name__ == "__main__":
    qs = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 and sys.argv[2] else {}
    router(qs)
elif action == "search_movie_ptpt":
    kb = xbmc.Keyboard("", "Título do filme (PT-PT)")
    kb.doModal()
    if not kb.isConfirmed(): xbmcplugin.endOfDirectory(HANDLE); return
    title = kb.getText()
    from resources.lib.core import aggregator, ranker
    res = aggregator.search_movie(title)
    res = ranker.filter_by_audio(res, 'pt-pt')
    ranked = ranker.filter_and_score(res)
    for s in ranked[:50]:
        li = xbmcgui.ListItem(f"[Play] {s.get('title') or title} • {s.get('quality','?')}")
        xbmcplugin.addDirectoryItem(HANDLE, build_url({"action":"os_test"}), li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE)
elif action == "search_movie_ptbr":
    kb = xbmc.Keyboard("", "Título do filme (PT-BR)")
    kb.doModal()
    if not kb.isConfirmed(): xbmcplugin.endOfDirectory(HANDLE); return
    title = kb.getText()
    from resources.lib.core import aggregator, ranker
    res = aggregator.search_movie(title)
    res = ranker.filter_by_audio(res, 'pt-br')
    ranked = ranker.filter_and_score(res)
    for s in ranked[:50]:
        li = xbmcgui.ListItem(f"[Play] {s.get('title') or title} • {s.get('quality','?')}")
        xbmcplugin.addDirectoryItem(HANDLE, build_url({"action":"os_test"}), li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE)
elif action == "search_tv_ptpt":
    kb = xbmc.Keyboard("", "Título da série (PT-PT)")
    kb.doModal()
    if not kb.isConfirmed(): xbmcplugin.endOfDirectory(HANDLE); return
    t = kb.getText()
    kb2 = xbmc.Keyboard("", "Temporada (número)"); kb2.doModal(); s = kb2.getText() if kb2.isConfirmed() else "1"
    kb3 = xbmc.Keyboard("", "Episódio (número)"); kb3.doModal(); e = kb3.getText() if kb3.isConfirmed() else "1"
    from resources.lib.core import aggregator, ranker
    res = aggregator.search_episode(t, int(s), int(e))
    res = ranker.filter_by_audio(res, 'pt-pt')
    ranked = ranker.filter_and_score(res)
    for src in ranked[:50]:
        li = xbmcgui.ListItem(f"[Play] {t} S{s}E{e} • {src.get('quality','?')}")
        xbmcplugin.addDirectoryItem(HANDLE, build_url({"action":"os_test"}), li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE)
elif action == "search_tv_ptbr":
    kb = xbmc.Keyboard("", "Título da série (PT-BR)")
    kb.doModal()
    if not kb.isConfirmed(): xbmcplugin.endOfDirectory(HANDLE); return
    t = kb.getText()
    kb2 = xbmc.Keyboard("", "Temporada (número)"); kb2.doModal(); s = kb2.getText() if kb2.isConfirmed() else "1"
    kb3 = xbmc.Keyboard("", "Episódio (número)"); kb3.doModal(); e = kb3.getText() if kb3.isConfirmed() else "1"
    from resources.lib.core import aggregator, ranker
    res = aggregator.search_episode(t, int(s), int(e))
    res = ranker.filter_by_audio(res, 'pt-br')
    ranked = ranker.filter_and_score(res)
    for src in ranked[:50]:
        li = xbmcgui.ListItem(f"[Play] {t} S{s}E{e} • {src.get('quality','?')}")
        xbmcplugin.addDirectoryItem(HANDLE, build_url({"action":"os_test"}), li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE)

elif action == "nextup":
    from resources.lib.utils import store
        from resources.lib.trakt import nextup as trakt_next
    items = []
        try:
            items = trakt_prog.next_up()
        except Exception:
            try:
                from resources.lib.trakt import nextup as trakt_next
                items = trakt_next.recent_next_up()
            except Exception:
                items = store.nextup_list()
    for it in items:
        t = it.get('title'); s = it.get('season'); e = it.get('episode')
        li = xbmcgui.ListItem(f"{t} • S{s:02d}E{e:02d}"); li = _add_ctx(li, 'episode', t, s, e)
        xbmcplugin.addDirectoryItem(HANDLE, build_url({"action":"search_episode","title":t,"season":s,"episode":e}), li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE)

elif action == "favs":
    from resources.lib.utils import store
        from resources.lib.trakt import nextup as trakt_next
    for t in store.fav_list('movie'):
        xbmcplugin.addDirectoryItem(HANDLE, build_url({"action":"search_movie","title":t}), xbmcgui.ListItem(f"Filme: {t}"), isFolder=False)
    for t in store.fav_list('show'):
        xbmcplugin.addDirectoryItem(HANDLE, build_url({"action":"search_episode","title":t,"season":1,"episode":1}), xbmcgui.ListItem(f"Série: {t}"), isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE)

def _add_ctx(li, kind, title, season=None, episode=None):
    import urllib.parse
    cm = []
    cm.append(("★ Adicionar aos Favoritos", "RunPlugin(%s)" % (BASE_URL + "?" + urllib.parse.urlencode({"action":"fav_add","kind":kind,"title":title}))))
    if kind == "episode":
        cm.append(("✓ Marcar episódio como visto", "RunPlugin(%s)" % (BASE_URL + "?" + urllib.parse.urlencode({"action":"mark_watched","title":title,"season":season or 1,"episode":episode or 1}))))
    cm.append(("✗ Remover dos Favoritos", "RunPlugin(%s)" % (BASE_URL + "?" + urllib.parse.urlencode({"action":"fav_remove","kind":kind,"title":title}))))
    if kind == "episode":
        cm.append(("↺ Marcar como NÃO visto", "RunPlugin(%s)" % (BASE_URL + "?" + urllib.parse.urlencode({"action":"mark_unwatched","title":title,"season":season or 1,"episode":episode or 1}))))
    try:
        import xbmcaddon
        if xbmcaddon.Addon().getSettingString('trakt_access_token'):
            import urllib.parse
            cm.append(("Trakt: Marcar visto", "RunPlugin(%s)" % (BASE_URL + "?" + urllib.parse.urlencode({"action":"trakt_mark_watched","kind":kind,"title":title,"season":season or 1,"episode":episode or 1}))))
            cm.append(("Trakt: Marcar NÃO visto", "RunPlugin(%s)" % (BASE_URL + "?" + urllib.parse.urlencode({"action":"trakt_mark_unwatched","kind":kind,"title":title,"season":season or 1,"episode":episode or 1}))))
    except Exception:
        pass
    li.addContextMenuItems(cm)
    return li

elif action == "fav_add":
    from resources.lib.utils import store
    kind = params.get('kind') or 'movie'
    title = params.get('title') or ''
    if title:
        store.fav_add(kind, title)
        xbmcgui.Dialog().notification("Favoritos", f"Adicionado: {title}", xbmcgui.NOTIFICATION_INFO, 2000)
    xbmcplugin.endOfDirectory(HANDLE)

elif action == "mark_watched":
    from resources.lib.utils import store
    title = params.get('title'); season = int(params.get('season') or 1); episode = int(params.get('episode') or 1)
    if title:
        store.add_episode_play(title, season, episode)
        xbmcgui.Dialog().notification("Vistos", f"{title} S{season:02d}E{episode:02d} marcado", xbmcgui.NOTIFICATION_INFO, 2000)
    xbmcplugin.endOfDirectory(HANDLE)

elif action == "fav_remove":
    from resources.lib.utils import store
    kind = params.get('kind') or 'movie'
    title = params.get('title') or ''
    if title:
        store.fav_remove(kind, title)
        xbmcgui.Dialog().notification("Favoritos", f"Removido: {title}", xbmcgui.NOTIFICATION_INFO, 2000)
    xbmcplugin.endOfDirectory(HANDLE)

elif action == "mark_unwatched":
    from resources.lib.utils import store
    title = params.get('title'); season = int(params.get('season') or 1); episode = int(params.get('episode') or 1)
    if title:
        store.mark_unwatched(title, season, episode)
        xbmcgui.Dialog().notification("Vistos", f"{title} S{season:02d}E{episode:02d} desmarcado", xbmcgui.NOTIFICATION_INFO, 2000)
    xbmcplugin.endOfDirectory(HANDLE)

elif action == "trakt_mark_watched":
    from resources.lib.trakt import scrobble as tscrob
    title = params.get('title'); season = int(params.get('season') or 0); episode = int(params.get('episode') or 0)
    try:
        if season and episode:
            tscrob.mark_watched(show=title, season=season, number=episode)
        else:
            tscrob.mark_watched(title=title, year=0)
        xbmcgui.Dialog().notification("Trakt", f"{title} marcado visto", xbmcgui.NOTIFICATION_INFO, 2000)
    except: pass
    xbmcplugin.endOfDirectory(HANDLE)

elif action == "trakt_mark_unwatched":
    from resources.lib.trakt import scrobble as tscrob
    title = params.get('title'); season = int(params.get('season') or 0); episode = int(params.get('episode') or 0)
    try:
        if season and episode:
            tscrob.mark_unwatched(show=title, season=season, number=episode)
        else:
            tscrob.mark_unwatched(title=title, year=0)
        xbmcgui.Dialog().notification("Trakt", f"{title} marcado NÃO visto", xbmcgui.NOTIFICATION_INFO, 2000)
    except: pass
    xbmcplugin.endOfDirectory(HANDLE)

def _filters_key():
    try:
        ms = (ADDON.getSettingString('prefer_codecs') or '') + '|' + str(ADDON.getSettingBool('exclude_cam_ts'))
        ms += '|' + (ADDON.getSettingString('filters_min_seeders') or '') + '|' + (ADDON.getSettingString('filters_min_size_gb') or '') + '|' + (ADDON.getSettingString('filters_max_size_gb') or '')
        return ms
    except Exception:
        return ""
