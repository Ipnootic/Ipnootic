import sys, urllib.parse, xbmc, xbmcaddon, xbmcgui, xbmcplugin

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

def build_url(query):
    return BASE_URL + "?" + urllib.parse.urlencode(query)

def _params():
    if len(sys.argv) > 2 and sys.argv[2]:
        return dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    return {}

# ---------- MENUS PRINCIPAIS ----------

def main_menu():
    add_dir("🔎 Pesquisar", "pesquisar", True)
    add_dir("🎬 Descobrir Filmes", "descobrir_filmes", True)
    add_dir("📺 Descobrir Séries", "descobrir_series", True)
    add_dir("⭐ Meus Filmes", "meus_filmes", True)
    add_dir("📌 Minhas Séries", "minhas_series", True)
    add_dir("⚙️ Definições", "definicoes", True)
    xbmcplugin.endOfDirectory(HANDLE)

# ---------- SUBMENUS ----------

def submenu_pesquisar():
    add_dir("Pesquisar Filmes", "search_movie", False)
    add_dir("Pesquisar Séries", "search_episode", False)
    add_dir("Pesquisa Global", "search_global", False)
    xbmcplugin.endOfDirectory(HANDLE)

def submenu_descobrir_filmes():
    add_dir("Populares", "discover_movies_popular", True)
    add_dir("Por Género", "discover_movies_genre", True)
    add_dir("Por Ano", "discover_movies_year", True)
    add_dir("Trending (IMDb/Trakt)", "discover_movies_trending", True)
    xbmcplugin.endOfDirectory(HANDLE)

def submenu_descobrir_series():
    add_dir("Populares", "discover_tv_popular", True)
    add_dir("Por Género", "discover_tv_genre", True)
    add_dir("Por Ano", "discover_tv_year", True)
    add_dir("Trending (IMDb/Trakt)", "discover_tv_trending", True)
    xbmcplugin.endOfDirectory(HANDLE)

def submenu_meus_filmes():
    add_dir("Watchlist", "trakt_movies_watchlist", True)
    add_dir("Favoritos", "trakt_movies_favs", True)
    add_dir("Em Progresso", "trakt_movies_progress", True)
    xbmcplugin.endOfDirectory(HANDLE)

def submenu_minhas_series():
    add_dir("Watchlist", "trakt_shows_watchlist", True)
    add_dir("Favoritos", "trakt_shows_favs", True)
    add_dir("Em Progresso", "trakt_shows_progress", True)
    add_dir("Next Up", "trakt_shows_nextup", True)
    xbmcplugin.endOfDirectory(HANDLE)

def submenu_definicoes():
    add_dir("Autorização Trakt", "trakt_auth", False)
    add_dir("Autorização Real-Debrid", "rd_auth", False)
    add_dir("Testar OpenSubtitles", "os_test", False)
    add_dir("Configurar Scrapers/Providers", "scrapers", False)
    add_dir("Abrir Definições", "settings", False)
    xbmcplugin.endOfDirectory(HANDLE)

# ---------- FUNÇÕES AUX ----------

def add_dir(name, action, folder=True):
    url = build_url({"action": action})
    li = xbmcgui.ListItem(label=name)
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=folder)

def _open_settings():
    ADDON.openSettings()
    xbmcplugin.endOfDirectory(HANDLE)

def _trakt_auth():
    xbmcgui.Dialog().ok("Trakt", "Aqui fazes a autorização do Trakt (placeholder).")
    xbmcplugin.endOfDirectory(HANDLE)

def _rd_auth():
    xbmcgui.Dialog().ok("Real-Debrid", "Aqui fazes a autorização do Real-Debrid (placeholder).")
    xbmcplugin.endOfDirectory(HANDLE)

def _os_test():
    xbmcgui.Dialog().ok("OpenSubtitles", "Teste de legendas (placeholder).")
    xbmcplugin.endOfDirectory(HANDLE)

def _scrapers():
    xbmcgui.Dialog().ok("Scrapers/Providers", "Aqui podes gerir os scrapers e providers (placeholder).")
    xbmcplugin.endOfDirectory(HANDLE)

# ---------- ROUTER ----------

def router(params):
    action = params.get("action")
    if not action:
        main_menu()
    elif action == "pesquisar":
        submenu_pesquisar()
    elif action == "descobrir_filmes":
        submenu_descobrir_filmes()
    elif action == "descobrir_series":
        submenu_descobrir_series()
    elif action == "meus_filmes":
        submenu_meus_filmes()
    elif action == "minhas_series":
        submenu_minhas_series()
    elif action == "definicoes":
        submenu_definicoes()
    elif action == "settings":
        _open_settings()
    elif action == "trakt_auth":
        _trakt_auth()
    elif action == "rd_auth":
        _rd_auth()
    elif action == "os_test":
        _os_test()
    elif action == "scrapers":
        _scrapers()
    else:
        xbmcplugin.endOfDirectory(HANDLE)

if __name__ == "__main__":
    router(_params())
