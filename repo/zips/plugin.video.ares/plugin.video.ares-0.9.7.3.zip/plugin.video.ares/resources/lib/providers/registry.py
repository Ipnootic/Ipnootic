# -*- coding: utf-8 -*-
from typing import List, Dict, Any
import xbmc

from .sample_ia import SampleIA  # mantém provider de demonstração

_PROVIDERS = [SampleIA()]

# tenta adicionar A4K e Coco se existirem
try:
    from .a4k_adapter import A4KAdapter
    _PROVIDERS.append(A4KAdapter())
except Exception as e:
    xbmc.log(f"[Ares][prov] A4K indisponível: {e}", xbmc.LOGINFO)

try:
    from .coco_adapter import CocoAdapter
    _PROVIDERS.append(CocoAdapter())
except Exception as e:
    xbmc.log(f"[Ares][prov] Coco indisponível: {e}", xbmc.LOGINFO)

def search_movie(title: str, year: int, tmdb_id: int = None) -> List[Dict[str, Any]]:
    results: List[Dict[str, Any]] = []
    for p in _PROVIDERS:
        try:
            r = p.search_movie(title, year, tmdb_id)
            if r:
                results.extend(r)
        except Exception as e:
            xbmc.log(f"[Ares][prov] {getattr(p, 'name', p)} erro: {e}", xbmc.LOGERROR)
    # ordenar por qualidade/size
    def _score(x):
        q = (x.get("quality") or "").lower()
        qv = 2160 if "2160" in q or "4k" in q else 1080 if "1080" in q else 720 if "720" in q else 480
        size = x.get("size") or 0
        try:
            size = int(size)
        except Exception:
            size = 0
        return (qv, size)
    results = sorted({(x["url"], x.get("quality",""), x.get("provider","")): x for x in results}.values(),
                     key=_score, reverse=True)
    xbmc.log(f"[Ares][prov] total fontes: {len(results)}", xbmc.LOGINFO)
    return results
