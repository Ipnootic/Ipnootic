# -*- coding: utf-8 -*-
from typing import List, Dict, Any

class ProviderBase:
    name = "base"

    def search_movie(self, title: str, year: int, tmdb_id: int = None) -> List[Dict[str, Any]]:
        """Devolve lista de dicts: {"url": str, "quality": "1080p", "size": 1500, "provider": self.name}"""
        return []

    def search_episode(self, title: str, season: int, episode: int, year: int = None, tmdb_id: int = None) -> List[Dict[str, Any]]:
        return []
