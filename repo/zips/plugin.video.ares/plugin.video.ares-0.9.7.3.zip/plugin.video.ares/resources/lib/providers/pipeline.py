# -*- coding: utf-8 -*-
from typing import List, Dict, Any
from . import registry
from .. import rd
import xbmc

def collect_sources_movie(title: str, year: int, tmdb_id: int = None) -> List[Dict[str,Any]]:
    items = registry.search_movie(title, year, tmdb_id)
    xbmc.log(f"[Ares][pipeline] {len(items)} fontes (pré-resolve)", xbmc.LOGINFO)
    return items

def resolve_source(item: Dict[str,Any]) -> str:
    url = item.get("url")
    return rd.resolve(url)
