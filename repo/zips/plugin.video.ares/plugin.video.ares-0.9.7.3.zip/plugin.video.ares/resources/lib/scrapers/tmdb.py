# -*- coding: utf-8 -*-
import json
import urllib.request
import urllib.parse
import xbmc

# --- Legacy fallback (v3) ---
API_KEY = "fd8c3db445635a0faa55e8b7db037141"

# --- Token de Leitura (v4, Bearer) ---
BEARER_TOKEN = (
    "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJmZDhjM2RiNDQ1NjM1YTBmYWE1NWU4YjdkYjAzNzE0MSIsIm5iZiI6MTc1NzUyOTU4Mi42OTQwMDAyLCJzdWIiOiI2OGMxYzVlZTQ5MzVlNWQxZTMxYmRhYzUiLCJzY29wZXMiOlsiYXBpX3JlYWQiXSwidmVyc2lvbiI6MX0.H15c0dEI7JKCtUIQpwr2HWa5Cicwp0cS1AiahgVPBiE"
)

BASE_URL = "https://api.themoviedb.org/3"
IMG_BASE = "https://image.tmdb.org/t/p"

def _lang():
    try:
        import xbmcaddon
        ADDON = xbmcaddon.Addon()
        return ADDON.getSettingString("ui_lang") or ADDON.getSettingString("language") or "pt-PT"
    except Exception:
        return "pt-PT"

def _region():
    try:
        import xbmcaddon
        ADDON = xbmcaddon.Addon()
        return ADDON.getSettingString("region") or "PT"
    except Exception:
        return "PT"

def _headers():
    h = {"accept": "application/json"}
    if BEARER_TOKEN:
        h["Authorization"] = f"Bearer {BEARER_TOKEN}"
    return h

def _q(params=None):
    params = dict(params or {})
    params.setdefault("language", _lang())
    if not BEARER_TOKEN and API_KEY:
        params["api_key"] = API_KEY
    return urllib.parse.urlencode(params)

def _req(path, params=None):
    url = f"{BASE_URL}{path}"
    url += f"?{_q(params or {})}"
    try:
        req = urllib.request.Request(url, headers=_headers())
        with urllib.request.urlopen(req, timeout=15) as r:
            data = r.read().decode("utf-8")
            return json.loads(data)
    except Exception as e:
        xbmc.log(f"[TMDb] Erro em {path}: {e}", xbmc.LOGERROR)
        return {"results": [], "page": 1, "total_pages": 1}

# --- COMPAT: alias _call (código legado pode chamar _call) ---
def _call(endpoint, params=None):
    return _req(endpoint, params)

# --------- Fallback inteligente para evitar listas vazias ---------
def _fetch_results(path, params=None, ctx=""):
    """Tenta PT; se vier vazio, tenta en-US. Loga contagens para debug."""
    p = dict(params or {})
    data = _req(path, p)
    res = data.get("results", [])
    if res:
        xbmc.log(f"[TMDb] {ctx or path} pt-PT -> {len(res)} itens", xbmc.LOGINFO)
        return data
    # fallback en-US
    p["language"] = "en-US"
    data2 = _req(path, p)
    res2 = data2.get("results", [])
    xbmc.log(f"[TMDb] {ctx or path} en-US -> {len(res2)} itens (fallback)", xbmc.LOGINFO)
    return data2

# --------- Fallback de SINOPSE (traduções), com cache ---------
_OV_CACHE = {}

def _prefer_langs():
    # ordem de preferência: tua língua -> variantes PT -> EN
    pref = [_lang(), 'pt-PT', 'pt-BR', 'pt', 'en-US', 'en']
    out = []
    for x in pref:
        if x and x not in out:
            out.append(x)
    return out

def _fallback_overview_single(media, item):
    """Se overview vier vazio, tenta via /{media}/{id}?append_to_response=translations."""
    if item.get('overview'):
        return item
    tid = item.get('id')
    if not tid:
        return item

    key = f"{media}:{tid}"
    if key in _OV_CACHE:
        if not item.get('overview') and _OV_CACHE[key]:
            item['overview'] = _OV_CACHE[key]
        return item

    detail = _req(f"/{'movie' if media=='movie' else 'tv'}/{tid}",
                  {"append_to_response": "translations"})
    trans = ((detail.get('translations') or {}).get('translations')) or []
    prefer = _prefer_langs()

    ov = ""

    # 1) tentar match completo lang-COUNTRY (pt-PT, pt-BR, en-US)
    for code in prefer:
        parts = code.split('-')
        if len(parts) == 2:
            for t in trans:
                if t.get('iso_639_1') == parts[0] and t.get('iso_3166_1') == parts[1]:
                    ov = (t.get('data') or {}).get('overview') or ""
                    if ov.strip():
                        break
            if ov.strip():
                break

    # 2) só pelo idioma (pt, en)
    if not ov:
        for code in prefer:
            lang = code.split('-')[0]
            for t in trans:
                if t.get('iso_639_1') == lang:
                    ov = (t.get('data') or {}).get('overview') or ""
                    if ov.strip():
                        break
            if ov.strip():
                break

    # 3) fallback: overview do próprio detalhe (pode vir no idioma original)
    if not ov:
        ov = detail.get('overview') or ""

    _OV_CACHE[key] = ov or ""
    if ov and not item.get('overview'):
        item['overview'] = ov
    if ov:
        xbmc.log(f"[TMDb] overview fallback applied ({media}:{tid})", xbmc.LOGINFO)
    return item

def _fallback_overview_for_items(media, items, max_lookups=15):
    """Aplica fallback a no máx. 'max_lookups' itens por lista para não pesar."""
    count = 0
    for it in items:
        if it.get('overview'):
            continue
        if count >= max_lookups:
            break
        _fallback_overview_single(media, it)
        count += 1
    return items

def _map_item(media, x):
    title = x.get("title") if media == "movie" else x.get("name")
    year_raw = (x.get("release_date") or x.get("first_air_date") or "")[:4]
    year = int(year_raw) if year_raw.isdigit() else 0
    poster_path = x.get("poster_path") or ""
    backdrop_path = x.get("backdrop_path") or ""
    poster = f"{IMG_BASE}/w500{poster_path}" if poster_path else ""
    fanart = f"{IMG_BASE}/w1280{backdrop_path}" if backdrop_path else ""
    return {
        "id": x.get("id"),
        "title": title or "",
        "original_title": x.get("original_title") or x.get("original_name") or "",
        "year": year,
        "overview": x.get("overview") or "",
        "poster": poster,
        "fanart": fanart,
        "poster_path": poster_path,
        "backdrop_path": backdrop_path,
    }

# ---------- Interface unificada ----------
def get_list(media: str, list_name: str, page: int = 1):
    media = media if media in ("movie", "tv") else "movie"
    page = max(int(page or 1), 1)

    if media == "movie":
        endpoints = {
            "popular":       "/movie/popular",
            "now_playing":   "/movie/now_playing",
            "upcoming":      "/movie/upcoming",
            "top_rated":     "/movie/top_rated",
            "trending_day":  "/trending/movie/day",
            "trending_week": "/trending/movie/week",
        }
    else:
        endpoints = {
            "popular":       "/tv/popular",
            "on_the_air":    "/tv/on_the_air",
            "airing_today":  "/tv/airing_today",
            "top_rated":     "/tv/top_rated",
            "trending_day":  "/trending/tv/day",
            "trending_week": "/trending/tv/week",
        }

    path = endpoints.get(list_name, list(endpoints.values())[0])
    params = {"page": page}
    data = _fetch_results(path, params=params, ctx=f"{media}:{list_name}")
    results = [_map_item(media, r) for r in data.get("results", [])]
    # >>> NOVO: fallback de sinopse por item
    results = _fallback_overview_for_items(media, results, max_lookups=15)
    total_pages = int(data.get("total_pages") or 1)
    return results, max(1, total_pages)

# ---------- Wrappers compatíveis ----------
def get_popular_movies(page=1):      return get_list("movie", "popular", page)[0]
def get_now_playing_movies(page=1):  return get_list("movie", "now_playing", page)[0]
def get_upcoming_movies(page=1):     return get_list("movie", "upcoming", page)[0]
def get_top_rated_movies(page=1):    return get_list("movie", "top_rated", page)[0]
def get_trending_movies(time_window="week", page=1):
    key = "trending_day" if str(time_window).lower().startswith("d") else "trending_week"
    return get_list("movie", key, page)[0]

def get_popular_tv(page=1):          return get_list("tv", "popular", page)[0]
def get_top_rated_tv(page=1):        return get_list("tv", "top_rated", page)[0]
def get_on_the_air_tv(page=1):       return get_list("tv", "on_the_air", page)[0]
def get_airing_today_tv(page=1):     return get_list("tv", "airing_today", page)[0]
def get_trending_tv(time_window="week", page=1):
    key = "trending_day" if str(time_window).lower().startswith("d") else "trending_week"
    return get_list("tv", key, page)[0]

# ---------- Filtros por Género/Ano ----------
def get_movies_by_genre(genre_id, page=1):
    p = {"with_genres": int(genre_id), "page": int(page), "include_adult": "false", "sort_by": "popularity.desc"}
    data = _fetch_results("/discover/movie", p, ctx=f"discover:movie:genre:{genre_id}")
    items = [_map_item("movie", r) for r in data.get("results", [])]
    return _fallback_overview_for_items("movie", items, max_lookups=15)

def get_tv_by_genre(genre_id, page=1):
    p = {"with_genres": int(genre_id), "page": int(page), "sort_by": "popularity.desc", "include_null_first_air_dates": "false"}
    data = _fetch_results("/discover/tv", p, ctx=f"discover:tv:genre:{genre_id}")
    items = [_map_item("tv", r) for r in data.get("results", [])]
    return _fallback_overview_for_items("tv", items, max_lookups=15)

def get_movies_by_year(year, page=1):
    p = {"primary_release_year": int(year), "page": int(page), "include_adult": "false", "sort_by": "popularity.desc"}
    data = _fetch_results("/discover/movie", p, ctx=f"discover:movie:year:{year}")
    items = [_map_item("movie", r) for r in data.get("results", [])]
    return _fallback_overview_for_items("movie", items, max_lookups=15)

def get_tv_by_year(year, page=1):
    p = {"first_air_date_year": int(year), "page": int(page), "sort_by": "popularity.desc", "include_null_first_air_dates": "false"}
    data = _fetch_results("/discover/tv", p, ctx=f"discover:tv:year:{year}")
    items = [_map_item("tv", r) for r in data.get("results", [])]
    return _fallback_overview_for_items("tv", items, max_lookups=15)

# ---------- Géneros (com fallback de idioma) ----------
def get_movie_genres():
    data = _call("/genre/movie/list").get("genres", [])
    if not data:
        data = _call("/genre/movie/list", {"language": "en-US"}).get("genres", [])
    xbmc.log(f"[TMDb] genres:movie -> {len(data)} itens", xbmc.LOGINFO)
    return data

def get_tv_genres():
    data = _call("/genre/tv/list").get("genres", [])
    if not data:
        data = _call("/genre/tv/list", {"language": "en-US"}).get("genres", [])
    xbmc.log(f"[TMDb] genres:tv -> {len(data)} itens", xbmc.LOGINFO)
    return data
