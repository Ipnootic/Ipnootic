import requests
import xbmcaddon

ADDON = xbmcaddon.Addon()

def _get_api_key():
    """Vai buscar a API key do OMDb das definições do addon"""
    return ADDON.getSettingString("omdb_api")

def search(title, year=None, type_="movie"):
    """
    Pesquisa no OMDb (IMDb) por título.
    Retorna lista de resultados básicos.
    """
    api = _get_api_key()
    if not api:
        return []

    params = {
        "apikey": api,
        "s": title,
        "type": type_
    }
    if year:
        params["y"] = str(year)

    try:
        r = requests.get("http://www.omdbapi.com/", params=params, timeout=10)
        data = r.json()
        return data.get("Search", [])
    except Exception as e:
        xbmcaddon.Addon().log(f"[IMDB] Erro na pesquisa: {e}")
        return []

def get_by_id(imdb_id):
    """
    Busca detalhes completos por IMDb ID (ex.: tt1375666).
    """
    api = _get_api_key()
    if not api or not imdb_id:
        return {}

    params = {
        "apikey": api,
        "i": imdb_id,
        "plot": "full"
    }

    try:
        r = requests.get("http://www.omdbapi.com/", params=params, timeout=10)
        return r.json()
    except Exception as e:
        xbmcaddon.Addon().log(f"[IMDB] Erro no get_by_id: {e}")
        return {}

def get_rating(imdb_id):
    """
    Retorna apenas o rating IMDb para um título.
    """
    info = get_by_id(imdb_id)
    return info.get("imdbRating")
