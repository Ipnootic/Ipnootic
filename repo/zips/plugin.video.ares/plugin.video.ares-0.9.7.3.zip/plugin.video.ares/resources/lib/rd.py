# -*- coding: utf-8 -*-
import json, time, urllib.request, urllib.parse
import xbmc, xbmcgui, xbmcaddon

API_OAUTH = "https://api.real-debrid.com/oauth/v2"
API_REST  = "https://api.real-debrid.com/rest/1.0"

ADDON = xbmcaddon.Addon()

# ---- Helpers settings (compat: aceita ids antigos e os teus)
def _get(k, default=""):
    try:
        return ADDON.getSettingString(k) or default
    except Exception:
        return default

def _set(k, v):
    try:
        ADDON.setSettingString(k, str(v or ""))
    except Exception:
        pass

def _now():
    return int(time.time())

# ---- Mapeamento de chaves segundo o teu settings.xml
# App Client ID (para iniciar device flow)
def _app_client_id():
    return "X245A4XAIBGVM"

# Credenciais de utilizador (geradas pelo device flow)
def _user_client_id():     return _get("rd_client_id_user") or _get("rd_client_id_bound") or _get("rd_client_id_u")
def _user_client_secret(): return _get("rd_client_secret")

# Tokens
def _access_token():
    # preferir rd_access_token; aceitar rd_token (manual) como fallback sem expiração
    return _get("rd_access_token") or _get("rd_token")
def _refresh_token():      return _get("rd_refresh_token")
def _token_expiry():       return int(_get("rd_token_expires", "0") or "0")

def _save_credentials(cid, csec):
    # guardamos em chaves separadas para não confundir com o App Client ID
    _set("rd_client_id_user", cid)
    _set("rd_client_secret", csec)

def _save_tokens(at, rt, expires_in):
    _set("rd_access_token", at)
    _set("rd_refresh_token", rt or "")
    # expira 2 min mais cedo
    _set("rd_token_expires", str(_now() + int(expires_in or 0) - 120))
    # compat: atualiza também rd_token para quem usa esse campo
    _set("rd_token", at)

# ---- HTTP básicos
def _http_get(url, qs=None, headers=None, timeout=20):
    if qs: url += "?" + urllib.parse.urlencode(qs)
    req = urllib.request.Request(url, headers=headers or {}, method="GET")
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = r.read().decode("utf-8")
    try:
        return json.loads(data)
    except Exception:
        return {"raw": data}

def _http_post(url, form=None, headers=None, timeout=20):
    data = urllib.parse.urlencode(form or {}).encode("utf-8")
    req = urllib.request.Request(url, headers=headers or {}, data=data, method="POST")
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = r.read().decode("utf-8")
    try:
        return json.loads(data)
    except Exception:
        return {"raw": data}

# ---- Device Flow (abre código em real-debrid.com/device)
def device_code_start():
    app_cid = _app_client_id()
    if not app_cid:
        raise RuntimeError("Define o RD Client ID (App) nas definições.")
    return _http_get(f"{API_OAUTH}/device/code", {
        "client_id": app_cid,
        "new_credentials": "yes"  # open-source flow
    })

def device_poll_credentials(device_code):
    app_cid = _app_client_id()
    if not app_cid:
        raise RuntimeError("RD Client ID (App) em falta.")
    return _http_get(f"{API_OAUTH}/device/credentials", {
        "client_id": app_cid,
        "code": device_code
    })

def device_exchange_token(user_cid, user_csec, device_code):
    return _http_post(f"{API_OAUTH}/token", {
        "client_id": user_cid,
        "client_secret": user_csec,
        "code": device_code,
        "grant_type": "http://oauth.net/grant_type/device/1.0"
    })

def refresh_access_token():
    cid  = _user_client_id()
    csec = _user_client_secret()
    rft  = _refresh_token()
    if not (cid and csec and rft):
        raise RuntimeError("Sem refresh_token/credenciais para refresh")
    res = _http_post(f"{API_OAUTH}/token", {
        "client_id": cid,
        "client_secret": csec,
        "code": rft,
        "grant_type": "http://oauth.net/grant_type/device/1.0"
    })
    at  = res.get("access_token")
    rt  = res.get("refresh_token") or rft
    exp = int(res.get("expires_in") or 0)
    if not at:
        raise RuntimeError(f"Refresh RD falhou: {res}")
    _save_tokens(at, rt, exp)
    xbmc.log("[RD] Access token renovado", xbmc.LOGINFO)
    return at

def ensure_access_token():
    # 1) se houver rd_access_token válido e não expirado, usa
    at = _get("rd_access_token")
    if at and _now() < _token_expiry():
        return at
    # 2) se houver refresh, renova
    if _refresh_token() and _user_client_id() and _user_client_secret():
        return refresh_access_token()
    # 3) fallback: rd_token manual (sem expiração conhecida)
    manual = _get("rd_token")
    if manual:
        xbmc.log("[RD] A usar rd_token manual (sem refresh)", xbmc.LOGINFO)
        return manual
    # 4) nada
    raise RuntimeError("Real-Debrid não autorizado. Usa 'Autorizar RD (Device)' nas definições.")

# ---- UI para o device flow
def device_authorize_ui():
    
    try:
        data = device_code_start()
    except Exception as e:
        xbmcgui.Dialog().notification("Real-Debrid", f"Erro a iniciar: {e}", xbmcgui.NOTIFICATION_ERROR, 4000)
        return

    dev_code  = data.get("device_code")
    user_code = data.get("user_code")
    verify_url = data.get("verification_url") or "https://real-debrid.com/device"
    interval   = int(data.get("interval") or 5)
    expires_in = int(data.get("expires_in") or 1800)
    if not (dev_code and user_code):
        xbmcgui.Dialog().notification("Real-Debrid", "Resposta inválida (device_code)", xbmcgui.NOTIFICATION_ERROR, 4000)
        return

    xbmc.log(f"[RD] device_code start: user_code={user_code} verify={verify_url}", xbmc.LOGINFO)
    msg = f"Vai a:\n{verify_url}\n\nCódigo:\n[COLOR gold]{user_code}[/COLOR]\n\nAutoriza e volta aqui."
    dlg = xbmcgui.DialogProgress()
    dlg.create("Real-Debrid", msg)

    t0 = _now()
    ok = False
    try:
        while not dlg.iscanceled():
            elapsed = _now() - t0
            if elapsed >= expires_in:
                dlg.update(100, "Expirou. Tenta novamente.")
                break

            pct = max(1, min(99, int(100.0 * elapsed / float(expires_in))))
            dlg.update(pct)

            try:
                cred = device_poll_credentials(dev_code)
                if cred and cred.get("client_id") and cred.get("client_secret"):
                    _save_credentials(cred["client_id"], cred["client_secret"])
                    tok = device_exchange_token(cred["client_id"], cred["client_secret"], dev_code)
                    at  = tok.get("access_token")
                    rt  = tok.get("refresh_token")
                    exp = int(tok.get("expires_in") or 0)
                    if at:
                        _save_tokens(at, rt, exp)
                        ok = True
                        break
            except Exception as pe:
                xbmc.log(f"[RD] polling cred: {pe}", xbmc.LOGDEBUG)

            for _ in range(interval):
                if dlg.iscanceled():
                    break
                time.sleep(1)
    finally:
        try: dlg.close()
        except Exception: pass

    if ok:
        xbmcgui.Dialog().notification("Real-Debrid", "Autorizado com sucesso", xbmcgui.NOTIFICATION_INFO, 3000)
    else:
        xbmcgui.Dialog().notification("Real-Debrid", "Autorização cancelada/expirada", xbmcgui.NOTIFICATION_ERROR, 3500)

# ---- REST: unrestrict/resolve
def _auth_headers():
    at = ensure_access_token()
    return {"Authorization": f"Bearer {at}"}

def unrestrict(link: str) -> str:
    res = _http_post(f"{API_REST}/unrestrict/link", {"link": link}, headers=_auth_headers())
    d = res.get("download") or ""
    if not d:
        raise RuntimeError(f"RD não gerou link: {res}")
    return d

def resolve(url: str) -> str:
    if url.startswith("http"):
        return unrestrict(url)
    raise RuntimeError("Magnet/torrent ainda não suportado neste fluxo")
