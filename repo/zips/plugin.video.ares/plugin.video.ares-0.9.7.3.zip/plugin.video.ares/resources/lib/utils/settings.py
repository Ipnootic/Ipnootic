from xbmcaddon import Addon
ADDON = Addon()
def get_str(k, default=""): 
    try: return ADDON.getSettingString(k)
    except: return default
def get_bool(k, default=False):
    try: return ADDON.getSettingBool(k)
    except: return default
