import json
import urllib.request
import urllib.parse
import xbmc

# --- API KEY fixa (legacy, só para fallback) ---
API_KEY = "fd8c3db445635a0faa55e8b7db037141"
# --- Token de Acesso de Leitura (Bearer) ---
BEARER_TOKEN = (
    "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJmZDhjM2RiNDQ1NjM1YTBmYWE1NWU4YjdkYjAzNzE0MSIsIm5iZiI6MTc1NzUyOTU4Mi42OTQwMDAyLCJzdWIiOiI2OGMxYzVlZTQ5MzVlNWQxZTMxYmRhYzUiLCJzY29wZXMiOlsiYXBpX3JlYWQiXSwidmVyc2lvbiI6MX0.H15c0dEI7JKCtUIQpwr2HWa5Cicwp0cS1AiahgVPBiE"
)

BASE_URL = "https://api.themoviedb.org/3"

def _lang():
    """Define a língua (padrão pt-PT)."""
    try:
        import xbmcaddon
        ADDON = xbmcaddon.Addon()
        return ADDON.getSettingString("ui_lang") or "pt-PT"
    except Exception:
        return "pt-PT"

def _call(endpoint, params=None):
    """Chama a API TMDb com Bearer Token e retorna JSON."""
    if params is None:
        params = {}
    params["language"] = _lang()

    url = f"{BASE_URL}{endpoint}?{urllib.parse.urlencode(params)}"
    headers = {
        "Authorization": f"Bearer {BEARER_TOKEN}",
        "accept": "application/json"
    }

    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=10) as r:
            data = r.read().decode("utf-8")
            xbmc.log(f"[TMDb] {endpoint} -> OK", xbmc.LOGINFO)
            return json.loads(data)
    except Exception as e:
        xbmc.log(f"[TMDb] Erro em {endpoint}: {e}", xbmc.LOGERROR)
        return {}

# ---------- FILMES ----------
def get_popular_movies(page=1):
    return _call("/movie/popular", {"page": page}).get("results", [])

def get_now_playing_movies(page=1):
    return _call("/movie/now_playing", {"page": page}).get("results", [])

def get_upcoming_movies(page=1):
    return _call("/movie/upcoming", {"page": page}).get("results", [])

def get_top_rated_movies(page=1):
    return _call("/movie/top_rated", {"page": page}).get("results", [])

def get_movies_by_genre(genre_id, page=1):
    return _call("/discover/movie", {"with_genres": int(genre_id), "page": page}).get("results", [])

def get_movies_by_year(year, page=1):
    return _call("/discover/movie", {"primary_release_year": int(year), "page": page}).get("results", [])

def get_trending_movies(time_window="week"):
    return _call(f"/trending/movie/{time_window}").get("results", [])

# ---------- SÉRIES ----------
def get_popular_tv(page=1):
    return _call("/tv/popular", {"page": page}).get("results", [])

def get_top_rated_tv(page=1):
    return _call("/tv/top_rated", {"page": page}).get("results", [])

def get_on_the_air_tv(page=1):
    return _call("/tv/on_the_air", {"page": page}).get("results", [])

def get_airing_today_tv(page=1):
    return _call("/tv/airing_today", {"page": page}).get("results", [])

def get_tv_by_genre(genre_id, page=1):
    return _call("/discover/tv", {"with_genres": int(genre_id), "page": page}).get("results", [])

def get_tv_by_year(year, page=1):
    return _call("/discover/tv", {"first_air_date_year": int(year), "page": page}).get("results", [])

def get_trending_tv(time_window="week"):
    return _call(f"/trending/tv/{time_window}").get("results", [])

# ---------- GENRES ----------
def get_movie_genres():
    return _call("/genre/movie/list").get("genres", [])

def get_tv_genres():
    return _call("/genre/tv/list").get("genres", [])
