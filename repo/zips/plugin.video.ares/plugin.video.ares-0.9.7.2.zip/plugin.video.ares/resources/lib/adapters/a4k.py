# Adapter for a4kscrapers if present
def _safe_list(x):
    return x if isinstance(x, list) else []

def normalize(items):
    out = []
    for i in _safe_list(items):
        s = {
            "title": i.get("title") or i.get("name"),
            "release": i.get("release_title") or "",
            "quality": i.get("quality") or i.get("info"),
            "seeders": i.get("seeders") or 0,
            "size_gb": i.get("size_gb") or i.get("size") or 0,
            "url": i.get("url"),
            "magnet": i.get("magnet") or i.get("magnet_url"),
            "audio_lang": (i.get("audio_lang") or "").lower(),
            "provider": "a4k"
        }
        out.append(s)
    return out

def search_movie(title, year=None):
    try:
        import a4kscrapers as a4k
    except Exception:
        return []
    try:
        res = a4k.search_movie(title, year)
    except Exception:
        res = []
    return normalize(res)

def search_episode(title, season, episode):
    try:
        import a4kscrapers as a4k
    except Exception:
        return []
    try:
        res = a4k.search_episode(title, season, episode)
    except Exception:
        res = []
    return normalize(res)
