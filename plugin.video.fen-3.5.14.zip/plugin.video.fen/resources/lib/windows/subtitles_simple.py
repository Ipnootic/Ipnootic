# -*- coding: utf-8 -*-
from windows.base_window import BaseDialog
from modules.kodi_utils import make_listitem, notification

class SimpleSubtitleSelector(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, *args)
		self.subtitles_list = kwargs.get('subtitles_list', [])
		self.selected_subtitle = None
		
	def onInit(self):
		try:
			notification("DEBUG: SimpleSubtitleSelector onInit chamado", 2000)
			self.populate_subtitles()
			self.setFocusId(5001)
			notification("DEBUG: onInit completo", 2000)
		except Exception as e:
			notification("DEBUG: Erro onInit: %s" % str(e), 3000)
			
	def run(self):
		try:
			notification("DEBUG: run() chamado", 2000)
			self.doModal()
			notification("DEBUG: doModal completo", 2000)
			self.clearProperties()
			return self.selected_subtitle
		except Exception as e:
			notification("DEBUG: Erro run: %s" % str(e), 3000)
			return None
		
	def onClick(self, controlID):
		try:
			notification("DEBUG: onClick %d" % controlID, 2000)
			if controlID == 5001:
				self.select_current_subtitle()
		except Exception as e:
			notification("DEBUG: Erro onClick: %s" % str(e), 3000)
			
	def onAction(self, action):
		try:
			if action in self.selection_actions:
				self.select_current_subtitle()
			elif action in self.closing_actions:
				self.close()
		except Exception as e:
			notification("DEBUG: Erro onAction: %s" % str(e), 3000)
			
	def populate_subtitles(self):
		try:
			notification("DEBUG: Populando %d legendas" % len(self.subtitles_list), 2000)
			
			# Add "Disable subtitles" option
			listitem = make_listitem()
			listitem.setProperty('subtitle_name', 'Desligar Legendas')
			listitem.setProperty('subtitle_data', 'disable')
			self.get_control(5001).addItem(listitem)
			
			# Add subtitles
			for i, subtitle in enumerate(self.subtitles_list):
				listitem = make_listitem()
				lang = subtitle.get('SubLanguageID', 'Unknown').upper()
				release_name = subtitle.get('MovieReleaseName', 'Unknown Release')
				subtitle_name = "%s - %s" % (lang, release_name[:50])
				listitem.setProperty('subtitle_name', subtitle_name)
				listitem.setProperty('subtitle_data', str(i))
				self.get_control(5001).addItem(listitem)
				
			notification("DEBUG: Populate completo", 2000)
		except Exception as e:
			notification("DEBUG: Erro populate: %s" % str(e), 3000)
			
	def select_current_subtitle(self):
		try:
			control = self.get_control(5001)
			selected_item = control.getSelectedItem()
			subtitle_data = selected_item.getProperty('subtitle_data')
			
			if subtitle_data == 'disable':
				self.selected_subtitle = None
				notification("DEBUG: Desligar legendas selecionado", 2000)
			else:
				idx = int(subtitle_data)
				self.selected_subtitle = self.subtitles_list[idx]
				notification("DEBUG: Legenda %d selecionada" % idx, 2000)
				
			self.close()
		except Exception as e:
			notification("DEBUG: Erro select: %s" % str(e), 3000)
			self.close()
