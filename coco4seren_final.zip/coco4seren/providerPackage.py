# -*- coding: utf-8 -*-
import os
import json
import xbmc

# imports Kodi
try:
    import xbmcaddon
    import xbmcvfs
except Exception:
    xbmcaddon = None
    xbmcvfs = None

from resources.lib.coco_bridge import CocoAdapter

def _addon_path():
    # Tenta via API do Kodi
    try:
        if xbmcaddon and xbmcvfs:
            addon = xbmcaddon.Addon()
            return xbmcvfs.translatePath(addon.getAddonInfo('path'))
    except Exception as e:
        xbmc.log(f"[Coco4Seren] xbmcaddon/xbmcvfs falhou: {e}", xbmc.LOGDEBUG)
    # Fallback: diretório deste ficheiro
    try:
        return os.path.dirname(os.path.abspath(__file__))
    except Exception:
        return ""

def _load_providers_manifest():
    addon_path = _addon_path()
    manifest = os.path.join(addon_path, 'providers.json')
    try:
        with open(manifest, 'r', encoding='utf-8') as f:
            data = json.load(f) or {}
    except Exception as e:
        xbmc.log(f"[Coco4Seren] Falha ao ler providers.json '{manifest}': {e}", xbmc.LOGWARNING)
        return [], []  # nunca None
    provs = data.get('providers', [])
    torrents = [p.get('name') for p in provs if (p.get('type') or '').lower() == 'torrent' and p.get('name')]
    hosters  = [p.get('name') for p in provs if (p.get('type') or '').lower() == 'hoster'  and p.get('name')]
    return torrents, hosters

_TORRENTS, _HOSTERS = _load_providers_manifest()

# ===== API esperada pelo Seren =====
def getProviders():
    # Seren usa esta lista para scraping efetivo (adapter único)
    return [CocoAdapter()]

def getTorrents():
    # Seren usa isto para preencher o UI e toggle individual
    return _TORRENTS

def getHosters():
    # Nesta build do Coco: 0 hosters (normal)
    return _HOSTERS
