# -*- coding: utf-8 -*-
# __init__.py para resources/lib do Coco4Seren
# Não precisa de lógica — só garante que a pasta é reconhecida como package.
