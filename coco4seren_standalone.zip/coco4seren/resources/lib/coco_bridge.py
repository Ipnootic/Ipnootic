# -*- coding: utf-8 -*-
import xbmc
import importlib
import pkgutil
import traceback

def _norm_imdb(imdb_id):
    if not imdb_id:
        return None
    s = str(imdb_id).strip()
    if s.isdigit():
        return 'tt' + s
    if s.startswith('tt') and s[2:].isdigit():
        return s
    return s

def _as_int(val, default=None):
    try:
        return int(val)
    except Exception:
        return default

def _build_data_from_info(media_type, info):
    aliases = info.get('aliases') or []
    imdb = _norm_imdb(info.get('imdb_id') or info.get('imdb'))

    if media_type == 'movie':
        title = info.get('title') or info.get('name') or info.get('original_title') or ''
        year = info.get('year') or info.get('release_year') or info.get('first_air_year')
        return {
            'title': str(title),
            'aliases': aliases,
            'year': _as_int(year, year),
            'imdb': imdb
        }

    tvshowtitle = (info.get('tvshowtitle') or info.get('show_title') or
                   info.get('series_title') or info.get('title') or '')
    ep_title = info.get('episode_title') or info.get('title') or ''
    season = info.get('season')
    episode = info.get('episode')
    show_year = info.get('year') or info.get('show_year') or info.get('first_air_year')

    return {
        'tvshowtitle': str(tvshowtitle),
        'aliases': aliases,
        'title': str(ep_title),
        'year': _as_int(show_year, show_year),
        'season': _as_int(season, season),
        'episode': _as_int(episode, episode),
        'imdb': imdb
    }

def _iter_coco_modules(subfolder):
    """
    Itera módulos do Coco por subpasta (torrents/hosters).
    Hosters podem não existir no teu pacote -> tolerar.
    """
    base_pkg = f'cocoscrapers.sources_cocoscrapers.{subfolder}'
    try:
        pkg = importlib.import_module(base_pkg)
    except Exception as e:
        xbmc.log(f"[Coco4Seren] Falha a importar {base_pkg}: {e}", xbmc.LOGINFO)
        return  # sem hosters/torrents -> segue
    for _, mod_name, is_pkg in pkgutil.iter_modules(pkg.__path__, base_pkg + "."):
        if is_pkg:
            continue
        try:
            mod = importlib.import_module(mod_name)
            src_cls = getattr(mod, 'source', None) or getattr(mod, 'sources', None)
            if src_cls:
                yield mod_name.split(".")[-1], src_cls
        except Exception as e:
            xbmc.log(f"[Coco4Seren] Erro a carregar '{mod_name}': {e}", xbmc.LOGWARNING)

class CocoAdapter:
    name = "coco"

    def get_sources(self, media_type, info):
        data = _build_data_from_info(media_type, info or {})
        if not data:
            return []

        results = []
        hostDict = {}

        # Primeiro torrents (existem no teu Coco)
        for prov_name, src_cls in _iter_coco_modules("torrents"):
            try:
                try:
                    src = src_cls()
                except Exception as e:
                    xbmc.log(f"[Coco4Seren] Erro ao instanciar {prov_name}: {e}", xbmc.LOGWARNING)
                    continue
                try:
                    prov_results = src.sources(data, hostDict) or []
                except Exception as e:
                    xbmc.log(f"[Coco4Seren] Erro ao executar source de {prov_name}: {e}", xbmc.LOGWARNING)
                    continue
                if prov_results:
                    for r in prov_results:
                        if isinstance(r, dict) and 'provider' not in r:
                            r['provider'] = prov_name.upper()
                    results.extend(prov_results)
            except Exception:
                xbmc.log(f"[Coco4Seren] Torrent '{prov_name}' falhou:\n{traceback.format_exc()}",
                         xbmc.LOGWARNING)

        # Depois hosters (se existirem nesta build)
        for prov_name, src_cls in _iter_coco_modules("hosters"):
            try:
                try:
                    src = src_cls()
                except Exception as e:
                    xbmc.log(f"[Coco4Seren] Erro ao instanciar {prov_name}: {e}", xbmc.LOGWARNING)
                    continue
                try:
                    prov_results = src.sources(data, hostDict) or []
                except Exception as e:
                    xbmc.log(f"[Coco4Seren] Erro ao executar source de {prov_name}: {e}", xbmc.LOGWARNING)
                    continue
                if prov_results:
                    for r in prov_results:
                        if isinstance(r, dict) and 'provider' not in r:
                            r['provider'] = prov_name.upper()
                    results.extend(prov_results)
            except Exception:
                xbmc.log(f"[Coco4Seren] Hoster '{prov_name}' falhou:\n{traceback.format_exc()}",
                         xbmc.LOGWARNING)

        return results