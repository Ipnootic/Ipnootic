# -*- coding: utf-8 -*-
from resources.lib.coco_bridge import CocoAdapter

def getProviders():
    """
    Seren carrega esta função e espera uma lista de objetos
    com método get_sources(media_type, info_dict).
    """
    return [CocoAdapter()]
