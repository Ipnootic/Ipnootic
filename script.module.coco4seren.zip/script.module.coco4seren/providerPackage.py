# -*- coding: utf-8 -*-
import os
import json
import xbmc

# Garantir que 'cocoscrapers' está no sys.path
try:
    addon_dir = os.path.dirname(os.path.abspath(__file__))
    lib_path = os.path.join(addon_dir, 'resources', 'lib')
    if os.path.isdir(lib_path) and lib_path not in sys.path:
        import sys
        sys.path.insert(0, lib_path)
except Exception as e:
    xbmc.log(f"[Coco4Seren] Falha ao ajustar sys.path: {e}", xbmc.LOGWARNING)

# imports Kodi
try:
    import xbmcaddon
    import xbmcvfs
except Exception:
    xbmcaddon = None
    xbmcvfs = None

from resources.lib.coco_bridge import CocoAdapter

def _addon_path():
    try:
        if xbmcaddon and xbmcvfs:
            addon = xbmcaddon.Addon()
            return xbmcvfs.translatePath(addon.getAddonInfo('path'))
    except Exception as e:
        xbmc.log(f"[Coco4Seren] xbmcaddon/xbmcvfs falhou: {e}", xbmc.LOGDEBUG)
    try:
        return os.path.dirname(os.path.abspath(__file__))
    except Exception:
        return ""

def _load_providers_manifest():
    addon_path = _addon_path()
    manifest = os.path.join(addon_path, 'providers.json')
    try:
        with open(manifest, 'r', encoding='utf-8') as f:
            data = json.load(f) or {}
    except Exception as e:
        xbmc.log(f"[Coco4Seren] Falha ao ler providers.json '{manifest}': {e}", xbmc.LOGWARNING)
        return [], []
    provs = data.get('providers', [])
    torrents = [p.get('name') for p in provs if (p.get('type') or '').lower() == 'torrent' and p.get('name')]
    hosters  = [p.get('name') for p in provs if (p.get('type') or '').lower() == 'hoster'  and p.get('name')]
    return torrents, hosters

_TORRENTS, _HOSTERS = _load_providers_manifest()

def getProviders():
    return [CocoAdapter()]

def getTorrents():
    return _TORRENTS

def getHosters():
    return _HOSTERS
