# -*- coding: utf-8 -*-
import os
import json
import xbmc

# imports necessários ANTES de usar
try:
    import xbmcaddon
    import xbmcvfs
except Exception:
    xbmcaddon = None
    xbmcvfs = None

from resources.lib.coco_bridge import CocoAdapter


def _addon_path():
    """
    Devolve o path absoluto do addon (compatível com Android/Windows/Linux).
    """
    # 1) tentar via xbmcaddon + xbmcvfs
    try:
        if xbmcaddon and xbmcvfs:
            addon = xbmcaddon.Addon()
            return xbmcvfs.translatePath(addon.getAddonInfo('path'))
    except Exception as e:
        xbmc.log(f"[Coco4Seren] xbmcaddon/xbmcvfs falhou: {e}", xbmc.LOGDEBUG)

    # 2) fallback: diretório deste ficheiro
    try:
        return os.path.dirname(os.path.abspath(__file__))
    except Exception:
        return ""


def _load_providers_manifest():
    """
    Lê providers.json e devolve (torrents, hosters) como listas de nomes.
    """
    addon_path = _addon_path()
    manifest = os.path.join(addon_path, 'providers.json')

    try:
        with open(manifest, 'r', encoding='utf-8') as f:
            data = json.load(f) or {}
    except Exception as e:
        xbmc.log(f"[Coco4Seren] Falha ao ler providers.json em '{manifest}': {e}", xbmc.LOGWARNING)
        return [], []

    provs = data.get('providers', [])
    torrents = [p.get('name') for p in provs if (p.get('type') or "").lower() == 'torrent' and p.get('name')]
    hosters  = [p.get('name') for p in provs if (p.get('type') or "").lower() == 'hoster'  and p.get('name')]

    return torrents, hosters


_TORRENTS, _HOSTERS = _load_providers_manifest()


# ===== API esperada pelo Seren =====
def getProviders():
    """
    Seren chama isto para obter os objetos de scraping.
    Cada objeto deve ter .get_sources(media_type, info).
    """
    return [CocoAdapter()]


def getTorrents():
    """
    Lista para o UI do Seren (ativação individual).
    """
    return _TORRENTS


def getHosters():
    """
    Lista para o UI do Seren (ativação individual).
    """
    return _HOSTERS
