# -*- coding: utf-8 -*-
import xbmc
import importlib
import traceback

# O Coco tem esta estrutura:
#   lib/cocoscrapers/sources_cocoscrapers/torrents/*.py
# Cada ficheiro define class source com método:
#   sources(self, data: dict, hostDict: dict) -> list[dict]
#
# data (episódio) esperado pelo Coco (observado em EZTV, etc.):
#   {
#     'tvshowtitle': str,
#     'aliases': list[str],
#     'title': str,          # título do episódio
#     'year': int|str,       # do show
#     'season': int|str,
#     'episode': int|str,
#     'imdb': str            # preferível com/sem 'tt' (ambos vistos)
#   }
# data (filme):
#   {
#     'title': str,
#     'aliases': list[str],
#     'year': int|str,
#     'imdb': str
#   }

def _norm_imdb(imdb_id):
    if not imdb_id:
        return None
    s = str(imdb_id).strip()
    # Aceita com ou sem 'tt' (Coco lida com ambos em diferentes scrapers)
    # Mantemos como 'tt1234567' por segurança; se vier sem, adicionamos.
    if s.isdigit():
        return 'tt' + s
    if s.startswith('tt') and s[2:].isdigit():
        return s
    # Se vier algo estranho, devolvemos tal como está para não bloquear
    return s

def _as_int(val, default=None):
    try:
        return int(val)
    except Exception:
        return default

def _build_data_from_info(media_type, info):
    aliases = info.get('aliases') or []
    imdb = _norm_imdb(info.get('imdb_id') or info.get('imdb'))

    if media_type == 'movie':
        # Tenta vários campos para robustez
        title = info.get('title') or info.get('name') or info.get('original_title') or ''
        year = info.get('year') or info.get('release_year') or info.get('first_air_year')
        return {
            'title': str(title),
            'aliases': aliases,
            'year': _as_int(year, year),
            'imdb': imdb
        }

    # Episódio
    tvshowtitle = (info.get('tvshowtitle') or info.get('show_title') or
                   info.get('series_title') or info.get('title') or '')
    ep_title = info.get('episode_title') or info.get('title') or ''
    season = info.get('season')
    episode = info.get('episode')
    show_year = info.get('year') or info.get('show_year') or info.get('first_air_year')

    return {
        'tvshowtitle': str(tvshowtitle),
        'aliases': aliases,
        'title': str(ep_title),
        'year': _as_int(show_year, show_year),
        'season': _as_int(season, season),
        'episode': _as_int(episode, episode),
        'imdb': imdb
    }

def _iter_coco_sources():
    """
    Descobre dinamicamente todos os scrapers do Coco (torrents).
    Ignora hosters (Coco pack atual foca torrents).
    """
    try:
        pkg = importlib.import_module('cocoscrapers.sources_cocoscrapers.torrents')
    except Exception as e:
        xbmc.log(f"[Coco4Seren] Falha ao importar pacote de torrents: {e}", xbmc.LOGERROR)
        return

    # __all__ contém a lista de módulos (ex.: 'eztv', '1337x', ...)
    providers = getattr(pkg, '__all__', [])
    for name in providers:
        mod_name = f'cocoscrapers.sources_cocoscrapers.torrents.{name}'
        try:
            mod = importlib.import_module(mod_name)
            src_cls = getattr(mod, 'source', None)
            if src_cls is None:
                continue
            yield name, src_cls
        except Exception as e:
            xbmc.log(f"[Coco4Seren] Erro a carregar '{mod_name}': {e}", xbmc.LOGWARNING)

class CocoAdapter:
    name = "coco"

    def __init__(self):
        # Nada a instanciar já; cada provider cria o seu próprio 'source()'
        pass

    def get_sources(self, media_type, info):
        """
        Entry point chamado pelo Seren.
        Retorna lista de sources em formato Coco (dicts).
        """
        data = _build_data_from_info(media_type, info or {})
        if not data:
            return []

        results = []
        append = results.append

        # hostDict é parte da assinatura dos scrapers; muitos ignoram.
        hostDict = {}

        for prov_name, src_cls in _iter_coco_sources():
            try:
                src = src_cls()
                # Coco usa src.sources(data, hostDict)
                prov_results = src.sources(data, hostDict) or []
                if prov_results:
                    # Opcional: anotar provider para debug
                    for r in prov_results:
                        if isinstance(r, dict) and 'provider' not in r:
                            r['provider'] = prov_name.upper()
                    results.extend(prov_results)
            except Exception:
                xbmc.log(f"[Coco4Seren] Provider '{prov_name}' falhou:\n{traceback.format_exc()}", xbmc.LOGWARNING)

        return results
