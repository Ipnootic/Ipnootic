import json, urllib.request
from xbmcaddon import Addon
ADDON = Addon()
BASE = "https://api.trakt.tv"
def _headers():
    return {
        "Content-Type":"application/json",
        "trakt-api-version":"2",
        "trakt-api-key": ADDON.getSettingString('trakt_client_id'),
        "Authorization": "Bearer " + ADDON.getSettingString('trakt_access_token')
    }
def _post(path, data):
    req = urllib.request.Request(BASE + path, data=json.dumps(data).encode('utf-8'), headers=_headers(), method="POST")
    with urllib.request.urlopen(req, timeout=20) as r:
        return r.read().decode()

def scrobble_start_movie(title, year):
    try:
        return _post("/scrobble/start", {"movie":{"title":title,"year":int(year or 0)}, "progress": 0.5})
    except: return None

def scrobble_stop_movie(title, year):
    try:
        return _post("/scrobble/stop", {"movie":{"title":title,"year":int(year or 0)}, "progress": 100})
    except: return None

def scrobble_start_episode(show, season, number):
    try:
        return _post("/scrobble/start", {"episode":{"season":int(season or 1),"number":int(number or 1)}, "show":{"title":show}, "progress": 0.5})
    except: return None

def scrobble_stop_episode(show, season, number):
    try:
        return _post("/scrobble/stop", {"episode":{"season":int(season or 1),"number":int(number or 1)}, "show":{"title":show}, "progress": 100})
    except: return None

def mark_watched(title=None, year=None, show=None, season=None, number=None):
    data = {}
    if title and year:
        data["movies"]=[{"title":title,"year":int(year)}]
    elif show and season is not None and number is not None:
        data["episodes"]=[{"season":int(season),"number":int(number),"show":{"title":show}}]
    try:
        return _post("/sync/history", data)
    except: return None

def mark_unwatched(title=None, year=None, show=None, season=None, number=None):
    data = {}
    if title and year:
        data["movies"]=[{"title":title,"year":int(year)}]
    elif show and season is not None and number is not None:
        data["episodes"]=[{"season":int(season),"number":int(number),"show":{"title":show}}]
    try:
        return _post("/sync/history/remove", data)
    except: return None
