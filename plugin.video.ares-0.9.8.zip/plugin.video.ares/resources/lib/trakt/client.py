import json, time, urllib.request
from xbmcaddon import Addon
ADDON = Addon()
BASE = "https://api.trakt.tv"
OAUTH = BASE + "/oauth"

def _headers(authed=False):
    h = {"Content-Type":"application/json", "trakt-api-version":"2",
         "trakt-api-key": ADDON.getSettingString('trakt_client_id')}
    if authed and ADDON.getSettingString('trakt_access_token'):
        h["Authorization"] = "Bearer " + ADDON.getSettingString('trakt_access_token')
    return h

def _req(url, data=None, method=None, headers=None):
    data = json.dumps(data).encode("utf-8") if isinstance(data, dict) else data
    req = urllib.request.Request(url, data=data, headers=headers or _headers(), method=method or ("POST" if data else "GET"))
    with urllib.request.urlopen(req, timeout=20) as r:
        raw = r.read().decode("utf-8")
        try: return json.loads(raw)
        except: return raw

def device_code():
    cid = ADDON.getSettingString('trakt_client_id')
    if not cid: raise Exception("Trakt Client ID vazio")
    return _req(OAUTH + "/device/code", data={"client_id": cid})

def poll_for_token(device_code, interval=5, expires_in=600):
    start = time.time()
    while time.time() - start < expires_in:
        try:
            tok = _req(OAUTH + "/device/token",
                       data={"code": device_code,
                             "client_id": ADDON.getSettingString('trakt_client_id'),
                             "client_secret": ADDON.getSettingString('trakt_client_secret')})
            if tok and tok.get("access_token"):
                ADDON.setSettingString('trakt_access_token', tok["access_token"])
                ADDON.setSettingString('trakt_refresh_token', tok.get("refresh_token",""))
                return tok
        except: pass
        time.sleep(max(2,int(interval)))
    raise Exception("Timeout token Trakt")
