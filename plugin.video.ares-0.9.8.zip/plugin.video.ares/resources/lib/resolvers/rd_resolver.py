import json, time, urllib.request, urllib.parse
from xbmcaddon import Addon
import xbmcgui
ADDON = Addon()
OAUTH = "https://api.real-debrid.com/oauth/v2"
REST  = "https://api.real-debrid.com/rest/1.0"

def _hdr():
    tok = ADDON.getSettingString('rd_token')
    if not tok: raise Exception("Token RD vazio. Autoriza em Settings → Real-Debrid.")
    return {"Authorization":"Bearer "+tok, "Content-Type":"application/x-www-form-urlencoded"}

def _get(url):
    req = urllib.request.Request(url, headers=_hdr())
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read().decode())

def _post(url, data):
    if isinstance(data, dict): data = urllib.parse.urlencode(data).encode()
    req = urllib.request.Request(url, data=data, headers=_hdr(), method="POST")
    with urllib.request.urlopen(req, timeout=30) as r:
        raw = r.read().decode()
        try: return json.loads(raw)
        except: return raw

def resolve(source):
    # source: {'magnet' or 'url'}
    if source.get('magnet'):
        # add magnet
        add = _post(REST + "/torrents/addMagnet", {"magnet": source['magnet']})
        tid = add.get("id")
        if not tid: raise Exception("RD: falha addMagnet")
        # info polling
        info = {}
        for _ in range(30):
            info = _get(REST + "/torrents/info/" + tid)
            if info.get("files"): break
            time.sleep(2)
        files = info.get('files', [])
        # escolher ficheiro(s)
        vids = [f for f in files if f.get('path','').lower().endswith(('.mkv','.mp4','.avi','.mov','.m4v'))]
        if vids:
            labels = [f"{i+1}. {v.get('path').split('/')[-1]} ({int((v.get('bytes',0) or 0)/1024/1024)} MB)" for i,v in enumerate(vids)]
            idx = xbmcgui.Dialog().select('Escolhe ficheiro', labels)
            if idx >= 0:
                file_ids = str(vids[idx]['id'])
            else:
                file_ids = ','.join([str(v['id']) for v in vids])
        else:
            file_ids = 'all'
        _post(REST + "/torrents/selectFiles/" + tid, {"files": file_ids})
        # refresh info for links
        info = _get(REST + "/torrents/info/" + tid)
        for link in info.get("links", []):
            un = _post(REST + "/unrestrict/link", {"link": link})
            if isinstance(un, dict) and un.get("download"):
                return un["download"]
        raise Exception("RD: sem links válidos")
    elif source.get('url'):
        un = _post(REST + "/unrestrict/link", {"link": source['url']})
        if isinstance(un, dict) and un.get("download"):
            return un["download"]
        raise Exception("RD: unrestrict falhou")
    else:
        raise Exception("Fonte sem magnet/url")
