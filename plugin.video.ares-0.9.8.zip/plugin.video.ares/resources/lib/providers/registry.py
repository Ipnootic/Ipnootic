# -*- coding: utf-8 -*-
from typing import List, Dict, Any, Optional, Tuple
import xbmc

from .sample_ia import SampleIA  # mantém provider de demonstração

# --- Registo de providers disponíveis ---
_PROVIDERS: List[Any] = [SampleIA()]

# tenta adicionar A4K e Coco se existirem
try:
    from .a4k_adapter import A4KAdapter
    _PROVIDERS.append(A4KAdapter())
except Exception as e:
    xbmc.log(f"[Ares][prov] A4K indisponível: {e}", xbmc.LOGINFO)

try:
    from .coco_adapter import CocoAdapter
    _PROVIDERS.append(CocoAdapter())
except Exception as e:
    xbmc.log(f"[Ares][prov] Coco indisponível: {e}", xbmc.LOGINFO)


def _pick_providers(provider: Optional[str] = None) -> List[Any]:
    """
    Se 'provider' vier definido (ex.: 'coco'), filtra a lista.
    Caso contrário, usa todos os providers registados.
    """
    if not provider:
        return _PROVIDERS
    sel = [p for p in _PROVIDERS if (getattr(p, "name", "") or "").lower() == provider.lower()]
    if not sel:
        xbmc.log(f"[Ares][prov] provider '{provider}' não encontrado; a usar todos.", xbmc.LOGINFO)
        return _PROVIDERS
    return sel


def _score(x: Dict[str, Any]) -> Tuple[int, int, int]:
    """Qualidade (res) > seeders > tamanho."""
    q = (x.get("quality") or "").lower()
    qv = 2160 if ("2160" in q or "4k" in q) else 1080 if "1080" in q else 720 if "720" in q else 480

    sd = x.get("seeders") or 0
    try:
        sd = int(sd)
    except Exception:
        sd = 0

    size = x.get("size") or 0
    try:
        size = int(size)
    except Exception:
        size = 0

    return (qv, sd, size)


def _dedupe_keep_best(results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Dedupe por (url, provider) mantendo o item com melhor pontuação.
    """
    best: Dict[Tuple[str, str], Dict[str, Any]] = {}
    for x in (results or []):
        url = x.get("url")
        prov = (x.get("provider") or "").lower()
        if not url:
            continue
        key = (url, prov)
        if key not in best:
            best[key] = x
        else:
            if _score(x) > _score(best[key]):
                best[key] = x
    # ordernar final
    ordered = sorted(best.values(), key=_score, reverse=True)
    return ordered


def search_movie(title: str, year: int, tmdb_id: int = None, provider: Optional[str] = None) -> List[Dict[str, Any]]:
    results: List[Dict[str, Any]] = []
    for p in _pick_providers(provider):
        try:
            fn = getattr(p, "search_movie", None)
            if not callable(fn):
                continue
            r = fn(title, year, tmdb_id)
            if r:
                results.extend(r)
        except Exception as e:
            xbmc.log(f"[Ares][prov] {getattr(p, 'name', p)}.movie erro: {e}", xbmc.LOGERROR)

    results = _dedupe_keep_best(results)
    xbmc.log(f"[Ares][prov] total fontes movie={len(results)} provider={provider or 'all'}", xbmc.LOGINFO)
    return results


def search_episode(title: str, season: int, episode: int, year: int = None, tmdb_id: int = None,
                   provider: Optional[str] = None) -> List[Dict[str, Any]]:
    """
    Pesquisa fontes para episódio (S/E). Ignora providers que não suportem séries.
    """
    results: List[Dict[str, Any]] = []
    for p in _pick_providers(provider):
        fn = getattr(p, "search_episode", None)
        if not callable(fn):
            continue
        try:
            r = fn(title, season, episode, year, tmdb_id)
            if r:
                results.extend(r)
        except Exception as e:
            xbmc.log(f"[Ares][prov] {getattr(p, 'name', p)}.episode erro: {e}", xbmc.LOGERROR)

    results = _dedupe_keep_best(results)
    xbmc.log(f"[Ares][prov] total fontes episode={len(results)} provider={provider or 'all'}", xbmc.LOGINFO)
    return results
