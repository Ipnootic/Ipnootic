# -*- coding: utf-8 -*-
import importlib
from typing import List, Dict, Any, Optional
from .base import ProviderBase
import xbmc


class CocoAdapter(ProviderBase):
    """
    Adapter fino para o módulo CocoScrapers, aceitando várias variantes de import
    e assinaturas de função (há forks com nomes diferentes).
    Suporta filmes e episódios.
    """
    name = "coco"

    def __init__(self):
        # listas separadas para filmes e episódios
        self._funcs_movie = []
        self._funcs_episode = []

        # possíveis módulos e funções (cobrimos variações comuns)
        candidates_movie = [
            ("cocoscrapers", "scrape_movie"),
            ("cocoscrapers.api", "scrape_movie"),
            ("cocoScrapers", "scrape_movie"),
            ("CocoScrapers", "scrape_movie"),
            ("cocoscrapers", "get_movie_sources"),
            ("cocoscrapers.api", "get_movie_sources"),
        ]
        candidates_episode = [
            ("cocoscrapers", "scrape_episode"),
            ("cocoscrapers.api", "scrape_episode"),
            ("cocoScrapers", "scrape_episode"),
            ("CocoScrapers", "scrape_episode"),
            ("cocoscrapers", "get_episode_sources"),
            ("cocoscrapers.api", "get_episode_sources"),
        ]

        for modname, fname in candidates_movie:
            try:
                m = importlib.import_module(modname)
                f = getattr(m, fname, None)
                if callable(f):
                    self._funcs_movie.append(f)
            except Exception:
                continue

        for modname, fname in candidates_episode:
            try:
                m = importlib.import_module(modname)
                f = getattr(m, fname, None)
                if callable(f):
                    self._funcs_episode.append(f)
            except Exception:
                continue

        if not (self._funcs_movie or self._funcs_episode):
            xbmc.log(
                "[Ares][prov][coco] Não encontrei API pública do CocoScrapers. "
                "Confirma instalação de 'script.module.cocoscrapers' e nomes das funções.",
                xbmc.LOGWARNING
            )

    # -------- helpers internos --------

    def _call_any(self, f, *, title: str, year: Optional[int] = None,
                  tmdb_id: Optional[int] = None, imdb_id: Optional[str] = None,
                  season: Optional[int] = None, episode: Optional[int] = None):
        """
        Tenta múltiplas assinaturas conhecidas (há forks com parâmetros diferentes).
        """
        tries = [
            # Assinaturas mais explícitas (dict kwargs)
            ((), {"title": title, "year": year, "tmdb_id": tmdb_id, "imdb_id": imdb_id,
                  "season": season, "episode": episode}),
            ((), {"title": title, "year": year, "tmdb": tmdb_id, "imdb": imdb_id,
                  "season": season, "episode": episode}),
            # Tuplos comuns
            ((title, year, tmdb_id, imdb_id, season, episode), {}),
            ((title, year, tmdb_id, imdb_id), {}),   # filmes
            ((title, year), {}),                     # filmes (mínimo)
            # kwargs mínimos
            ((), {"title": title, "year": year}),
            # episódios (kwargs mínimos)
            ((), {"title": title, "season": season, "episode": episode, "year": year, "tmdb_id": tmdb_id}),
            ((), {"title": title, "season": season, "episode": episode}),
        ]
        for args, kwargs in tries:
            # remove None para não chocar com assinaturas rígidas
            kwargs = {k: v for k, v in kwargs.items() if v is not None}
            try:
                return f(*args, **kwargs)
            except TypeError:
                # tenta a próxima assinatura
                continue
            except Exception as e:
                xbmc.log(f"[Ares][prov][coco] erro ao chamar {getattr(f, '__name__', f)}: {e}", xbmc.LOGERROR)
                return []
        return []

    def _as_int(self, v, default=0) -> int:
        try:
            if v is None:
                return default
            if isinstance(v, (int, float)):
                return int(v)
            s = str(v).strip().lower().replace("mb", "").replace("gb", "")
            if "gb" in str(v).lower():
                # caso "1.5 GB" venha como string (tratado acima)
                pass
            if "." in s:
                # exemplo: "1.5" -> 1 (MB) — não vamos complicar aqui
                return int(float(s))
            return int(s)
        except Exception:
            return default

    def _normalize(self, items) -> List[Dict[str, Any]]:
        """
        Normaliza a saída dos diferentes forks para o formato interno do Ares.
        Campos principais: url, quality, size, provider
        Campos adicionais (best-effort): title, release, seeders, audio_lang, source
        """
        out: List[Dict[str, Any]] = []
        if not items:
            return out

        for i in items:
            try:
                url = i.get("url") or i.get("link") or i.get("magnet")
                if not url:
                    continue

                quality = i.get("quality") or i.get("res") or i.get("info") or ""
                size = i.get("size") or i.get("filesize") or i.get("size_mb") or 0
                # alguns forks reportam GB; tentamos converter por aproximação
                # se vier "1.5 GB" num campo texto, o _as_int acima lida de forma simples
                size = self._as_int(size, 0)

                out.append({
                    "url": url,
                    "quality": str(quality),
                    "size": size,
                    "provider": i.get("provider") or self.name,
                    "title": i.get("title") or i.get("name") or "",
                    "release": i.get("release_title") or i.get("release") or "",
                    "seeders": self._as_int(i.get("seeders"), 0),
                    "audio_lang": (i.get("audio_lang") or i.get("lang") or "").lower(),
                    "source": i.get("source") or "",
                })
            except Exception:
                continue

        return out

    # -------- API filmes/episódios --------

    def search_movie(self, title: str, year: int, tmdb_id: int = None) -> List[Dict[str, Any]]:
        if not self._funcs_movie:
            return []
        for f in self._funcs_movie:
            res = self._call_any(f, title=title, year=year, tmdb_id=tmdb_id, imdb_id=None)
            norm = self._normalize(res)
            if norm:
                xbmc.log(f"[Ares][prov][coco] {len(norm)} fontes(movie)", xbmc.LOGINFO)
                return norm
        return []

    def search_episode(self, title: str, season: int, episode: int, year: int = None,
                       tmdb_id: int = None) -> List[Dict[str, Any]]:
        if not self._funcs_episode:
            # tentar fallback: alguns forks usam mesma função com S/E embutidos
            if not self._funcs_movie:
                return []
            for f in self._funcs_movie:
                res = self._call_any(
                    f, title=title, year=year, tmdb_id=tmdb_id,
                    imdb_id=None, season=season, episode=episode
                )
                norm = self._normalize(res)
                if norm:
                    xbmc.log(f"[Ares][prov][coco] {len(norm)} fontes(episode via movie-fallback)", xbmc.LOGINFO)
                    return norm
            return []

        for f in self._funcs_episode:
            res = self._call_any(
                f, title=title, year=year, tmdb_id=tmdb_id,
                imdb_id=None, season=season, episode=episode
            )
            norm = self._normalize(res)
            if norm:
                xbmc.log(f"[Ares][prov][coco] {len(norm)} fontes(episode)", xbmc.LOGINFO)
                return norm

        return []
