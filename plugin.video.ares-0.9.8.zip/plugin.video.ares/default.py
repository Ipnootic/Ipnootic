import sys, urllib.parse, time, importlib, xbmc, xbmcaddon, xbmcgui, xbmcplugin
from resources.lib.scrapers import tmdb

# --- Providers pipeline (opcional) ---
try:
    from resources.lib.providers import pipeline as prov_pipeline
except Exception as _e:
    prov_pipeline = None
    try:
        xbmc.log(f"[Ares] Providers pipeline indisponível: {_e}", xbmc.LOGWARNING)
    except Exception:
        pass

# --- NEW: fallback direto para Coco ---
try:
    from resources.lib.providers.coco_adapter import CocoAdapter
except Exception:
    CocoAdapter = None

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

COCO_ADDON_ID = "script.module.cocoscrapers"

def build_url(query):
    return BASE_URL + "?" + urllib.parse.urlencode(query)

def _params():
    if len(sys.argv) > 2 and sys.argv[2]:
        return dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    return {}

# ---------- DEPENDÊNCIAS ----------
def _has_module(mod_name: str) -> bool:
    try:
        importlib.import_module(mod_name)
        return True
    except Exception:
        return False

def ensure_coco_installed() -> bool:
    """
    Verifica se o módulo cocoscrapers está disponível; se não estiver,
    pergunta ao utilizador e tenta instalar via InstallAddon(...).
    """
    if _has_module("cocoscrapers"):
        return True

    yes = xbmcgui.Dialog().yesno(
        "Ares",
        "O módulo CocoScrapers não está instalado.\nInstalar agora a partir dos repositórios configurados?",
        yeslabel="Instalar", nolabel="Cancelar"
    )
    if not yes:
        return False

    xbmc.executebuiltin(f"InstallAddon({COCO_ADDON_ID})")

    # aguarda um pouco e revalida
    for _ in range(25):  # ~5s max
        xbmc.sleep(200)
        if _has_module("cocoscrapers"):
            xbmcgui.Dialog().notification("Ares", "CocoScrapers instalado", xbmcgui.NOTIFICATION_INFO, 2000)
            return True

    xbmcgui.Dialog().notification("Ares", "Falha a instalar CocoScrapers", xbmcgui.NOTIFICATION_ERROR, 3000)
    return False

# ---------- MENUS PRINCIPAIS ----------
def main_menu():
    add_dir("🔎 Pesquisar", "pesquisar", True)
    add_dir("🎬 Descobrir Filmes", "descobrir_filmes", True)
    add_dir("📺 Descobrir Séries", "descobrir_series", True)
    # --- COCO ---
    add_dir("🎞️ Ver Filmes", "coco_filmes", True)
    add_dir("📺 Ver Séries", "coco_series", True)
    # ------------
    add_dir("⭐ Meus Filmes", "meus_filmes", True)
    add_dir("📌 Minhas Séries", "minhas_series", True)
    add_dir("⚙️ Definições", "definicoes", True)
    xbmcplugin.endOfDirectory(HANDLE)

# ---------- SUBMENUS ----------
def submenu_pesquisar():
    add_dir("Pesquisar Filmes", "search_movie", False)
    add_dir("Pesquisar Séries", "search_episode", False)
    if ADDON.getSettingBool("use_imdb") and ADDON.getSettingString("omdb_api"):
        add_dir("Pesquisar no IMDb", "search_imdb", False)
    add_dir("Pesquisa Global", "search_global", False)
    xbmcplugin.endOfDirectory(HANDLE)

def submenu_descobrir_filmes():
    if ADDON.getSettingBool("use_tmdb"):
        add_dir("TMDb - Populares", "discover_movies_tmdb_popular", True)
        add_dir("TMDb - Em Cartaz", "discover_movies_tmdb_nowplaying", True)
        add_dir("TMDb - Próximos", "discover_movies_tmdb_upcoming", True)
        add_dir("TMDb - Top Rated", "discover_movies_tmdb_toprated", True)
        add_dir("TMDb - Trending", "discover_movies_tmdb_trending", True)
        add_dir("TMDb - Por Género", "discover_movies_tmdb_genres", True)
        add_dir("TMDb - Por Ano", "discover_movies_tmdb_years", True)
    xbmcplugin.endOfDirectory(HANDLE)

def submenu_descobrir_series():
    if ADDON.getSettingBool("use_tmdb"):
        add_dir("TMDb - Populares", "discover_tv_tmdb_popular", True)
        add_dir("TMDb - Top Rated", "discover_tv_tmdb_toprated", True)
        add_dir("TMDb - Em Exibição", "discover_tv_tmdb_ontheair", True)
        add_dir("TMDb - Hoje na TV", "discover_tv_tmdb_airingtoday", True)
        add_dir("TMDb - Trending", "discover_tv_tmdb_trending", True)
        add_dir("TMDb - Por Género", "discover_tv_tmdb_genres", True)
        add_dir("TMDb - Por Ano", "discover_tv_tmdb_years", True)
    xbmcplugin.endOfDirectory(HANDLE)

# --- SUBMENUS COCO ---
def submenu_coco_filmes():
    if not ensure_coco_installed():
        xbmcplugin.endOfDirectory(HANDLE); return
    add_dir("Populares", "coco_movies_tmdb_popular", True)
    add_dir("Em Cartaz", "coco_movies_tmdb_nowplaying", True)
    add_dir("Próximos", "coco_movies_tmdb_upcoming", True)
    add_dir("Top Rated", "coco_movies_tmdb_toprated", True)
    add_dir("Trending", "coco_movies_tmdb_trending", True)
    add_dir("Por Género", "coco_movies_tmdb_genres", True)
    add_dir("Por Ano", "coco_movies_tmdb_years", True)
    xbmcplugin.endOfDirectory(HANDLE)

def submenu_coco_series():
    if not ensure_coco_installed():
        xbmcplugin.endOfDirectory(HANDLE); return
    add_dir("Populares", "coco_tv_tmdb_popular", True)
    add_dir("Top Rated", "coco_tv_tmdb_toprated", True)
    add_dir("Em Exibição", "coco_tv_tmdb_ontheair", True)
    add_dir("Hoje na TV", "coco_tv_tmdb_airingtoday", True)
    add_dir("Trending", "coco_tv_tmdb_trending", True)
    add_dir("Por Género", "coco_tv_tmdb_genres", True)
    add_dir("Por Ano", "coco_tv_tmdb_years", True)
    xbmcplugin.endOfDirectory(HANDLE)
# ---------------------

def submenu_meus_filmes():
    add_dir("Watchlist", "trakt_movies_watchlist", True)
    add_dir("Favoritos", "trakt_movies_favs", True)
    add_dir("Em Progresso", "trakt_movies_progress", True)
    xbmcplugin.endOfDirectory(HANDLE)

def submenu_minhas_series():
    add_dir("Watchlist", "trakt_shows_watchlist", True)
    add_dir("Favoritos", "trakt_shows_favs", True)
    add_dir("Em Progresso", "trakt_shows_progress", True)
    add_dir("Next Up", "trakt_shows_nextup", True)
    xbmcplugin.endOfDirectory(HANDLE)

def submenu_definicoes():
    add_dir("Autorização Trakt", "trakt_auth", False)
    add_dir("Autorização Real-Debrid", "rd_auth", False)
    add_dir("Testar OpenSubtitles", "os_test", False)
    add_dir("Configurar Scrapers/Providers", "scrapers", False)
    add_dir("Abrir Definições", "settings", False)
    xbmcplugin.endOfDirectory(HANDLE)

# ---------- FUNÇÕES AUX ----------
def add_dir(name, action, folder=True, extra={}):
    q = {"action": action}
    q.update(extra)
    url = build_url(q)
    li = xbmcgui.ListItem(label=name)
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=folder)

def add_pagination(action, current_page):
    next_page = current_page + 1
    add_dir(f"⏭ Próxima página ({next_page})", action, True, {"page": next_page})

def list_media(items, media_type="movie", provider=None, end=True):
    """
    end=True encerra o diretório aqui (comportamento antigo).
    Para adicionar paginação, usa end=False e fecha fora.
    """
    poster_base = "https://image.tmdb.org/t/p/w500"
    backdrop_base = "https://image.tmdb.org/t/p/w1280"

    xbmc.log(f"[ARES][list_media] {len(items)} resultados para {media_type} provider={provider}", xbmc.LOGINFO)

    for m in items:
        title = m.get("title") or m.get("name") or "Sem título"

        # --- FIX: usar 'year' se existir; fallback para release/first_air ---
        yfield = m.get("year")
        if isinstance(yfield, int) and yfield > 0:
            year = int(yfield)
            year_str = str(yfield)
        else:
            year_str = (m.get("release_date") or m.get("first_air_date") or "")[:4]
            year = int(year_str) if year_str.isdigit() else 0

        plot = m.get("overview", "")

        poster = m.get("poster") or (poster_base + m["poster_path"] if m.get("poster_path") else "")
        fanart = m.get("fanart") or (backdrop_base + m["backdrop_path"] if m.get("backdrop_path") else "")
        if not fanart:
            fanart = poster

        li = xbmcgui.ListItem(f"{title} ({year_str})" if year_str else title)
        li.setInfo("video", {"title": title, "year": year, "plot": plot, "mediatype": media_type})
        li.setArt({
            "poster": poster,
            "thumb": poster,
            "icon": poster,
            "fanart": fanart,
            "banner": fanart,
            "landscape": fanart
        })
        li.setProperty("fanart_image", fanart)
        li.setProperty('IsPlayable', 'true')

        url = build_url({
            "action": "play",
            "id": str(m.get("id") or ""),
            "media": media_type,
            "title": title,
            "year": str(year or ""),
            "provider": provider or ""
        })
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)

    xbmcplugin.setContent(HANDLE, 'movies' if media_type == 'movie' else 'tvshows')
    if end:
        xbmcplugin.endOfDirectory(HANDLE)

# ---------- NEW: Fallback direto para Coco ----------
def _collect_sources_coco_direct(media, title, year, tmdb_id, season=None, episode=None):
    if not CocoAdapter:
        xbmc.log("[Ares][play] CocoAdapter indisponível para fallback direto", xbmc.LOGWARNING)
        return []
    try:
        ad = CocoAdapter()
        if media == "movie":
            xbmc.log(f"[Ares][play] Fallback Coco direto (movie): {title} ({year}) tmdb={tmdb_id}", xbmc.LOGINFO)
            return ad.search_movie(title, year, tmdb_id=tmdb_id) or []
        else:
            xbmc.log(f"[Ares][play] Fallback Coco direto (episode): {title} S{season}E{episode} ({year}) tmdb={tmdb_id}", xbmc.LOGINFO)
            return ad.search_episode(title, season, episode, year=year, tmdb_id=tmdb_id) or []
    except Exception as e:
        xbmc.log(f"[Ares][play] Fallback Coco direto falhou: {e}", xbmc.LOGERROR)
        return []

# ---------- UI de seleção de fonte + playback ----------
def _select_from_list(title, entries):
    if not entries:
        return None
    labels = []
    for e in entries:
        q = e.get("quality", "") or ""
        sz = e.get("size")
        pv = e.get("provider", "") or ""
        tag = f"{q} • {sz}MB • {pv}" if sz else f"{q} • {pv}" if pv else (q or "source")
        labels.append(tag)
    idx = xbmcgui.Dialog().select(f"Fontes • {title}", labels)
    if idx < 0:
        return None
    return entries[idx]

def _play_url(stream_url):
    li = xbmcgui.ListItem(path=stream_url)
    li.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(HANDLE, True, li)

def handle_play(params):
    media = (params.get("media") or "movie").lower()
    title = params.get("title") or ""
    year = int(params.get("year") or 0)
    tmdb_id = int(params.get("id") or 0)
    provider = (params.get("provider") or "").strip() or None
    season = int(params.get("season") or 0)
    episode = int(params.get("episode") or 0)

    if provider == "coco" and not ensure_coco_installed():
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    # Vamos precisar saber se usamos o fallback direto para resolver/stream
    direct_coco = False
    sources = []

    # Caso não exista pipeline, ainda tentamos Coco direto se for o provider
    if prov_pipeline is None:
        if provider == "coco":
            # FIX: tentar mesmo assim via Coco
            # completar ano se vier vazio (para melhor match)
            if year <= 0 and tmdb_id and media in ("movie", "tv", "tvshow"):
                try:
                    if media == "movie":
                        detm = tmdb.get_movie_details(tmdb_id) or {}
                        y = (detm.get("release_date") or "")[:4]
                    else:
                        detm = tmdb.get_tv_details(tmdb_id) or {}
                        y = (detm.get("first_air_date") or "")[:4]
                    if str(y).isdigit():
                        year = int(y)
                except Exception:
                    pass
            sources = _collect_sources_coco_direct("movie" if media in ("movie",) else "episode",
                                                   title, year, tmdb_id, season=season, episode=episode)
            direct_coco = bool(sources)
            if not sources:
                xbmcgui.Dialog().notification("Ares", "Providers não instalados e Coco sem fontes", xbmcgui.NOTIFICATION_INFO, 3500)
                xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
                return
        else:
            xbmcgui.Dialog().notification("Ares", "Providers não instalados", xbmcgui.NOTIFICATION_INFO, 3000)
            xbmc.log("[Ares][play] Providers pipeline ausente", xbmc.LOGWARNING)
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return

    # Se há pipeline, usar normalmente; se vier 0 e o provider for coco, tentar fallback
    if prov_pipeline is not None and not sources:
        try:
            if media in ("movie",):
                # --- FIX: se o ano vier vazio e tivermos TMDb, tentar obter ---
                if year <= 0 and tmdb_id:
                    try:
                        detm = tmdb.get_movie_details(tmdb_id) or {}
                        y = (detm.get("release_date") or "")[:4]
                        if y.isdigit():
                            year = int(y)
                    except Exception:
                        pass
                sources = prov_pipeline.collect_sources_movie(title, year, tmdb_id=tmdb_id, provider=provider)

                # NEW: pipeline 0 → fallback Coco direto
                if (not sources) and provider == "coco":
                    xbmc.log("[Ares][play] pipeline=0 → fallback Coco direto (movie)", xbmc.LOGINFO)
                    sources = _collect_sources_coco_direct("movie", title, year, tmdb_id)
                    direct_coco = bool(sources)

            elif media in ("tv", "tvshow"):
                if not (season and episode):
                    det = tmdb.get_tv_details(tmdb_id) if tmdb_id else {}

                    # --- FIX: ano vazio em TV -> usar first_air_date da série ---
                    if year <= 0:
                        try:
                            y = (det.get("first_air_date") or "")[:4]
                            if y.isdigit():
                                year = int(y)
                        except Exception:
                            pass

                    seasons = [s for s in (det.get("seasons") or []) if (s.get("season_number") or 0) > 0]
                    if not seasons:
                        xbmcgui.Dialog().notification("Ares", "Sem temporadas disponíveis", xbmcgui.NOTIFICATION_INFO, 2500)
                        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem()); return
                    labels = [f'Temporada {s["season_number"]} ({s.get("episode_count",0)} ep)' for s in seasons]
                    si = xbmcgui.Dialog().select(f"{title} • Temporada", labels)
                    if si < 0:
                        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem()); return
                    season_no = int(seasons[si]["season_number"])

                    sea = tmdb.get_tv_season(tmdb_id, season_no)
                    eps = sea.get("episodes") or []
                    elabels = [f'E{e.get("episode_number")}: {e.get("name") or ""}' for e in eps]
                    ei = xbmcgui.Dialog().select(f"S{season_no:02d} • Episódio", elabels)
                    if ei < 0:
                        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem()); return
                    ep_no = int(eps[ei].get("episode_number") or 0)

                    xbmc.executebuiltin('RunPlugin({})'.format(build_url({
                        "action": "play",
                        "media": "tvshow",
                        "id": str(tmdb_id),
                        "title": title,
                        "year": str(year or ""),
                        "season": str(season_no),
                        "episode": str(ep_no),
                        "provider": provider or ""
                    })))
                    return

                sources = prov_pipeline.collect_sources_episode(title, season, episode, year=year, tmdb_id=tmdb_id, provider=provider)

                # NEW: pipeline 0 → fallback Coco direto
                if (not sources) and provider == "coco":
                    xbmc.log("[Ares][play] pipeline=0 → fallback Coco direto (episode)", xbmc.LOGINFO)
                    sources = _collect_sources_coco_direct("episode", title, year, tmdb_id, season=season, episode=episode)
                    direct_coco = bool(sources)

            else:
                sources = []
        except Exception as e:
            xbmc.log(f"[Ares][pipeline] erro a recolher fontes: {e}", xbmc.LOGERROR)
            sources = []

    if not sources:
        if provider == "coco":
            xbmcgui.Dialog().notification("Ares", "CocoScrapers sem fontes. Abre as definições do Coco e ativa providers.", xbmcgui.NOTIFICATION_INFO, 4500)
        else:
            xbmcgui.Dialog().notification("Ares", "Sem fontes disponíveis", xbmcgui.NOTIFICATION_INFO, 3000)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    chosen = _select_from_list(title, sources)
    if not chosen:
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    try:
        # Se usamos pipeline, resolver como antes; caso contrário, tocar URL direto
        if (not direct_coco) and prov_pipeline is not None:
            stream = prov_pipeline.resolve_source(chosen)
        else:
            stream = chosen.get("url") or chosen.get("stream") or chosen.get("link") or chosen.get("magnet")
        if not stream:
            raise RuntimeError("Sem URL/stream válido após resolução")
        _play_url(stream)
    except Exception as e:
        xbmc.log(f"[Ares][play] erro a resolver fonte: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Ares", "Falha ao resolver fonte", xbmcgui.NOTIFICATION_ERROR, 3000)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())

# ---------- HANDLERS TMDb ----------
def show_movies_by_genre():
    genres = tmdb.get_movie_genres()
    for g in genres:
        add_dir(g["name"], "discover_movies_tmdb_bygenre", True, {"genre_id": str(g["id"])})
    xbmcplugin.endOfDirectory(HANDLE)

def show_tv_by_genre():
    genres = tmdb.get_tv_genres()
    for g in genres:
        add_dir(g["name"], "discover_tv_tmdb_bygenre", True, {"genre_id": str(g["id"])})
    xbmcplugin.endOfDirectory(HANDLE)

def show_years(media):
    if str(media).lower().startswith('tv'):
        action_byyear = "discover_tv_tmdb_byyear"
    else:
        action_byyear = "discover_movies_tmdb_byyear"
    for year in range(2025, 1970, -1):
        add_dir(str(year), action_byyear, True, {"year": str(year)})
    xbmcplugin.endOfDirectory(HANDLE)

# ---------- HANDLERS COCO: listagens TMDb + paginação ----------
def coco_show_movies_by_genre():
    if not ensure_coco_installed():
        xbmcplugin.endOfDirectory(HANDLE); return
    genres = tmdb.get_movie_genres()
    for g in genres:
        add_dir(g["name"], "coco_movies_tmdb_bygenre", True, {"genre_id": str(g["id"])})
    xbmcplugin.endOfDirectory(HANDLE)

def coco_show_tv_by_genre():
    if not ensure_coco_installed():
        xbmcplugin.endOfDirectory(HANDLE); return
    genres = tmdb.get_tv_genres()
    for g in genres:
        add_dir(g["name"], "coco_tv_tmdb_bygenre", True, {"genre_id": str(g["id"])})
    xbmcplugin.endOfDirectory(HANDLE)

def coco_show_years(media):
    if not ensure_coco_installed():
        xbmcplugin.endOfDirectory(HANDLE); return
    if str(media).lower().startswith('tv'):
        action_byyear = "coco_tv_tmdb_byyear"
    else:
        action_byyear = "coco_movies_tmdb_byyear"
    for year in range(2025, 1970, -1):
        add_dir(str(year), action_byyear, True, {"year": str(year)})
    xbmcplugin.endOfDirectory(HANDLE)

# ---------- ROUTER ----------
def router(params):
    page = int(params.get("page", "1"))
    action = params.get("action")
    xbmc.log(f"[ARES][router] Action recebida: {action}", xbmc.LOGINFO)

    if not action:
        main_menu()

    # Submenus
    elif action == "pesquisar":
        submenu_pesquisar()
    elif action == "descobrir_filmes":
        submenu_descobrir_filmes()
    elif action == "descobrir_series":
        submenu_descobrir_series()
    elif action == "coco_filmes":
        submenu_coco_filmes()
    elif action == "coco_series":
        submenu_coco_series()
    elif action == "meus_filmes":
        submenu_meus_filmes()
    elif action == "minhas_series":
        submenu_minhas_series()
    elif action == "definicoes":
        submenu_definicoes()
    elif action == "settings":
        ADDON.openSettings()

    # TMDb Movies
    elif action == "discover_movies_tmdb_popular":
        list_media(tmdb.get_popular_movies(page=page), "movie")
        add_pagination("discover_movies_tmdb_popular", page)
    elif action == "discover_movies_tmdb_nowplaying":
        list_media(tmdb.get_now_playing_movies(page=page), "movie")
        add_pagination("discover_movies_tmdb_nowplaying", page)
    elif action == "discover_movies_tmdb_upcoming":
        list_media(tmdb.get_upcoming_movies(page=page), "movie")
        add_pagination("discover_movies_tmdb_upcoming", page)
    elif action == "discover_movies_tmdb_toprated":
        list_media(tmdb.get_top_rated_movies(page=page), "movie")
        add_pagination("discover_movies_tmdb_toprated", page)
    elif action == "discover_movies_tmdb_trending":
        list_media(tmdb.get_trending_movies(page=page), "movie")
        add_pagination("discover_movies_tmdb_trending", page)
    elif action == "discover_movies_tmdb_genres":
        show_movies_by_genre()
    elif action == "discover_movies_tmdb_bygenre":
        gid = params.get("genre_id")
        if gid and gid.isdigit():
            list_media(tmdb.get_movies_by_genre(int(gid), page=page), "movie")
            add_pagination("discover_movies_tmdb_bygenre", page)
    elif action == "discover_movies_tmdb_years":
        show_years("movies")
    elif action == "discover_movies_tmdb_byyear":
        yr = params.get("year")
        if yr and yr.isdigit():
            list_media(tmdb.get_movies_by_year(int(yr), page=page), "movie")
            add_pagination("discover_movies_tmdb_byyear", page)

    # TMDb TV
    elif action == "discover_tv_tmdb_popular":
        list_media(tmdb.get_popular_tv(page=page), "tvshow")
        add_pagination("discover_tv_tmdb_popular", page)
    elif action == "discover_tv_tmdb_toprated":
        list_media(tmdb.get_top_rated_tv(page=page), "tvshow")
        add_pagination("discover_tv_tmdb_toprated", page)
    elif action == "discover_tv_tmdb_ontheair":
        list_media(tmdb.get_on_the_air_tv(page=page), "tvshow")
        add_pagination("discover_tv_tmdb_ontheair", page)
    elif action == "discover_tv_tmdb_airingtoday":
        list_media(tmdb.get_airing_today_tv(page=page), "tvshow")
        add_pagination("discover_tv_tmdb_airingtoday", page)
    elif action == "discover_tv_tmdb_trending":
        list_media(tmdb.get_trending_tv(page=page), "tvshow")
        add_pagination("discover_tv_tmdb_trending", page)
    elif action == "discover_tv_tmdb_genres":
        show_tv_by_genre()
    elif action == "discover_tv_tmdb_bygenre":
        gid = params.get("genre_id")
        if gid and gid.isdigit():
            list_media(tmdb.get_tv_by_genre(int(gid), page=page), "tvshow")
            add_pagination("discover_tv_tmdb_bygenre", page)
    elif action == "discover_tv_tmdb_years":
        show_years("tv")
    elif action == "discover_tv_tmdb_byyear":
        yr = params.get("year")
        if yr and yr.isdigit():
            list_media(tmdb.get_tv_by_year(int(yr), page=page), "tvshow")
            add_pagination("discover_tv_tmdb_byyear", page)

    # COCO Movies (listagens TMDb, play com provider="coco", paginação ANTES de fechar)
    elif action == "coco_movies_tmdb_popular":
        if not ensure_coco_installed(): xbmcplugin.endOfDirectory(HANDLE); return
        list_media(tmdb.get_popular_movies(page=page), "movie", provider="coco", end=False)
        add_pagination("coco_movies_tmdb_popular", page)
        xbmcplugin.endOfDirectory(HANDLE)
    elif action == "coco_movies_tmdb_nowplaying":
        if not ensure_coco_installed(): xbmcplugin.endOfDirectory(HANDLE); return
        list_media(tmdb.get_now_playing_movies(page=page), "movie", provider="coco", end=False)
        add_pagination("coco_movies_tmdb_nowplaying", page)
        xbmcplugin.endOfDirectory(HANDLE)
    elif action == "coco_movies_tmdb_upcoming":
        if not ensure_coco_installed(): xbmcplugin.endOfDirectory(HANDLE); return
        list_media(tmdb.get_upcoming_movies(page=page), "movie", provider="coco", end=False)
        add_pagination("coco_movies_tmdb_upcoming", page)
        xbmcplugin.endOfDirectory(HANDLE)
    elif action == "coco_movies_tmdb_toprated":
        if not ensure_coco_installed(): xbmcplugin.endOfDirectory(HANDLE); return
        list_media(tmdb.get_top_rated_movies(page=page), "movie", provider="coco", end=False)
        add_pagination("coco_movies_tmdb_toprated", page)
        xbmcplugin.endOfDirectory(HANDLE)
    elif action == "coco_movies_tmdb_trending":
        if not ensure_coco_installed(): xbmcplugin.endOfDirectory(HANDLE); return
        list_media(tmdb.get_trending_movies(page=page), "movie", provider="coco", end=False)
        add_pagination("coco_movies_tmdb_trending", page)
        xbmcplugin.endOfDirectory(HANDLE)
    elif action == "coco_movies_tmdb_genres":
        coco_show_movies_by_genre()
    elif action == "coco_movies_tmdb_bygenre":
        if not ensure_coco_installed(): xbmcplugin.endOfDirectory(HANDLE); return
        gid = params.get("genre_id")
        if gid and gid.isdigit():
            list_media(tmdb.get_movies_by_genre(int(gid), page=page), "movie", provider="coco", end=False)
            add_pagination("coco_movies_tmdb_bygenre", page)
            xbmcplugin.endOfDirectory(HANDLE)
    elif action == "coco_movies_tmdb_years":
        coco_show_years("movies")
    elif action == "coco_movies_tmdb_byyear":
        if not ensure_coco_installed(): xbmcplugin.endOfDirectory(HANDLE); return
        yr = params.get("year")
        if yr and yr.isdigit():
            list_media(tmdb.get_movies_by_year(int(yr), page=page), "movie", provider="coco", end=False)
            add_pagination("coco_movies_tmdb_byyear", page)
            xbmcplugin.endOfDirectory(HANDLE)

    # COCO TV
    elif action == "coco_tv_tmdb_popular":
        if not ensure_coco_installed(): xbmcplugin.endOfDirectory(HANDLE); return
        list_media(tmdb.get_popular_tv(page=page), "tvshow", provider="coco", end=False)
        add_pagination("coco_tv_tmdb_popular", page)
        xbmcplugin.endOfDirectory(HANDLE)
    elif action == "coco_tv_tmdb_toprated":
        if not ensure_coco_installed(): xbmcplugin.endOfDirectory(HANDLE); return
        list_media(tmdb.get_top_rated_tv(page=page), "tvshow", provider="coco", end=False)
        add_pagination("coco_tv_tmdb_toprated", page)
        xbmcplugin.endOfDirectory(HANDLE)
    elif action == "coco_tv_tmdb_ontheair":
        if not ensure_coco_installed(): xbmcplugin.endOfDirectory(HANDLE); return
        list_media(tmdb.get_on_the_air_tv(page=page), "tvshow", provider="coco", end=False)
        add_pagination("coco_tv_tmdb_ontheair", page)
        xbmcplugin.endOfDirectory(HANDLE)
    elif action == "coco_tv_tmdb_airingtoday":
        if not ensure_coco_installed(): xbmcplugin.endOfDirectory(HANDLE); return
        list_media(tmdb.get_airing_today_tv(page=page), "tvshow", provider="coco", end=False)
        add_pagination("coco_tv_tmdb_airingtoday", page)
        xbmcplugin.endOfDirectory(HANDLE)
    elif action == "coco_tv_tmdb_trending":
        if not ensure_coco_installed(): xbmcplugin.endOfDirectory(HANDLE); return
        list_media(tmdb.get_trending_tv(page=page), "tvshow", provider="coco", end=False)
        add_pagination("coco_tv_tmdb_trending", page)
        xbmcplugin.endOfDirectory(HANDLE)
    elif action == "coco_tv_tmdb_genres":
        coco_show_tv_by_genre()
    elif action == "coco_tv_tmdb_bygenre":
        if not ensure_coco_installed(): xbmcplugin.endOfDirectory(HANDLE); return
        gid = params.get("genre_id")
        if gid and gid.isdigit():
            list_media(tmdb.get_tv_by_genre(int(gid), page=page), "tvshow", provider="coco", end=False)
            add_pagination("coco_tv_tmdb_bygenre", page)
            xbmcplugin.endOfDirectory(HANDLE)
    elif action == "coco_tv_tmdb_years":
        coco_show_years("tv")
    elif action == "coco_tv_tmdb_byyear":
        if not ensure_coco_installed(): xbmcplugin.endOfDirectory(HANDLE); return
        yr = params.get("year")
        if yr and yr.isdigit():
            list_media(tmdb.get_tv_by_year(int(yr), page=page), "tvshow", provider="coco", end=False)
            add_pagination("coco_tv_tmdb_byyear", page)
            xbmcplugin.endOfDirectory(HANDLE)

    # RD AUTH
    elif action == "rd_auth":
        try:
            from resources.lib import rd
            rd.device_authorize_ui()
        except Exception as e:
            xbmc.log(f"[Ares][RD] erro auth: {e}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Real-Debrid", "Falha no processo de autorização", xbmcgui.NOTIFICATION_ERROR, 3000)

    elif action == "rd_device":
        try:
            from resources.lib import rd
            rd.device_authorize_ui()
        except Exception as e:
            xbmc.log(f"[Ares][RD] erro auth(device): {e}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Real-Debrid", "Falha no processo de autorização", xbmcgui.NOTIFICATION_ERROR, 3000)

    # PLAY
    elif action == "play":
        handle_play(params)

    else:
        xbmcplugin.endOfDirectory(HANDLE)

if __name__ == "__main__":
    router(_params())
