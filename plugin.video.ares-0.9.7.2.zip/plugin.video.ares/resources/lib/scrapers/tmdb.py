# -*- coding: utf-8 -*-
import json
import urllib.request
import urllib.parse
import xbmc

# --- Legacy fallback (v3) ---
API_KEY = "fd8c3db445635a0faa55e8b7db037141"

# --- Token de Leitura (v4, Bearer) ---
BEARER_TOKEN = (
    "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJmZDhjM2RiNDQ1NjM1YTBmYWE1NWU4YjdkYjAzNzE0MSIsIm5iZiI6MTc1NzUyOTU4Mi42OTQwMDAyLCJzdWIiOiI2OGMxYzVlZTQ5MzVlNWQxZTMxYmRhYzUiLCJzY29wZXMiOlsiYXBpX3JlYWQiXSwidmVyc2lvbiI6MX0.H15c0dEI7JKCtUIQpwr2HWa5Cicwp0cS1AiahgVPBiE"
)

BASE_URL = "https://api.themoviedb.org/3"
IMG_BASE = "https://image.tmdb.org/t/p"

def _lang():
    """Tenta varias keys; fallback 'pt-PT'."""
    try:
        import xbmcaddon
        ADDON = xbmcaddon.Addon()
        return (
            ADDON.getSettingString("ui_lang")
            or ADDON.getSettingString("language")
            or "pt-PT"
        )
    except Exception:
        return "pt-PT"

def _region():
    try:
        import xbmcaddon
        ADDON = xbmcaddon.Addon()
        return ADDON.getSettingString("region") or "PT"
    except Exception:
        return "PT"

def _headers():
    h = {"accept": "application/json"}
    if BEARER_TOKEN:
        h["Authorization"] = f"Bearer {BEARER_TOKEN}"
    return h

def _q(params=None):
    params = dict(params or {})
    params.setdefault("language", _lang())
    # Se não houver bearer, usa v3 api_key como fallback
    if not BEARER_TOKEN and API_KEY:
        params["api_key"] = API_KEY
    return urllib.parse.urlencode(params)

def _req(path, params=None):
    url = f"{BASE_URL}{path}"
    if params:
        url += f"?{_q(params)}"
    else:
        # garantir lingua/api
        url += f"?{_q({})}"
    try:
        req = urllib.request.Request(url, headers=_headers())
        with urllib.request.urlopen(req, timeout=15) as r:
            data = r.read().decode("utf-8")
            xbmc.log(f"[TMDb] GET {path} -> OK", xbmc.LOGINFO)
            return json.loads(data)
    except Exception as e:
        xbmc.log(f"[TMDb] Erro em {path}: {e}", xbmc.LOGERROR)
        # devolve estrutura mínima para não rebentar routers
        return {"results": [], "page": 1, "total_pages": 1}

def _map_item(media, x):
    title = x.get("title") if media == "movie" else x.get("name")
    year_raw = (x.get("release_date") or x.get("first_air_date") or "")[:4]
    year = int(year_raw) if year_raw.isdigit() else 0
    poster = f"{IMG_BASE}/w500{x['poster_path']}" if x.get("poster_path") else ""
    fanart = f"{IMG_BASE}/w1280{x['backdrop_path']}" if x.get("backdrop_path") else ""
    return {
        "id": x.get("id"),
        "title": title or "",
        "original_title": x.get("original_title") or x.get("original_name") or "",
        "year": year,
        "overview": x.get("overview") or "",
        "poster": poster,
        "fanart": fanart,
    }

# ---------- Interface unificada (recomendada no router) ----------
def get_list(media: str, list_name: str, page: int = 1):
    """
    media: 'movie' | 'tv'
    list_name (movie): popular | now_playing | upcoming | top_rated | trending_day | trending_week
    list_name (tv):    popular | on_the_air | airing_today | top_rated | trending_day | trending_week
    """
    media = media if media in ("movie", "tv") else "movie"
    page = max(int(page or 1), 1)

    if media == "movie":
        endpoints = {
            "popular":       "/movie/popular",
            "now_playing":   "/movie/now_playing",
            "upcoming":      "/movie/upcoming",
            "top_rated":     "/movie/top_rated",
            "trending_day":  "/trending/movie/day",
            "trending_week": "/trending/movie/week",
        }
    else:
        endpoints = {
            "popular":       "/tv/popular",
            "on_the_air":    "/tv/on_the_air",
            "airing_today":  "/tv/airing_today",
            "top_rated":     "/tv/top_rated",
            "trending_day":  "/trending/tv/day",
            "trending_week": "/trending/tv/week",
        }

    path = endpoints.get(list_name, list(endpoints.values())[0])

    # trending aceita page; os restantes também
    params = {"page": page} if path else {"page": page}
    data = _req(path, params=params)
    results = [_map_item(media, r) for r in data.get("results", [])]
    total_pages = int(data.get("total_pages") or 1)
    return results, max(1, total_pages)

# ---------- Wrappers compatíveis (se o teu default.py já os usa) ----------
def get_popular_movies(page=1):      return get_list("movie", "popular", page)[0]
def get_now_playing_movies(page=1):  return get_list("movie", "now_playing", page)[0]
def get_upcoming_movies(page=1):     return get_list("movie", "upcoming", page)[0]
def get_top_rated_movies(page=1):    return get_list("movie", "top_rated", page)[0]
def get_trending_movies(time_window="week", page=1):
    key = "trending_day" if str(time_window).lower().startswith("d") else "trending_week"
    return get_list("movie", key, page)[0]

def get_popular_tv(page=1):          return get_list("tv", "popular", page)[0]
def get_top_rated_tv(page=1):        return get_list("tv", "top_rated", page)[0]
def get_on_the_air_tv(page=1):       return get_list("tv", "on_the_air", page)[0]
def get_airing_today_tv(page=1):     return get_list("tv", "airing_today", page)[0]
def get_trending_tv(time_window="week", page=1):
    key = "trending_day" if str(time_window).lower().startswith("d") else "trending_week"
    return get_list("tv", key, page)[0]

# ---------- Géneros (inalterado) ----------
def get_movie_genres():
    return _req("/genre/movie/list").get("genres", [])

def get_tv_genres():
    return _req("/genre/tv/list").get("genres", [])
