import requests
import xbmcaddon

# --- API KEY fixa (não editável nas definições) ---
API_KEY = "fd8c3db445635a0faa55e8b7db037141"
BASE_URL = "https://api.themoviedb.org/3"

ADDON = xbmcaddon.Addon()

def _lang():
    """Vai buscar a língua definida no addon (default: pt-PT)."""
    return ADDON.getSettingString("ui_lang") or "pt-PT"

def _call(endpoint, params=None):
    """Chama a API TMDb com API_KEY e retorna JSON."""
    if params is None:
        params = {}
    params["api_key"] = API_KEY
    params["language"] = _lang()
    try:
        r = requests.get(f"{BASE_URL}{endpoint}", params=params, timeout=10)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        xbmcaddon.Addon().log(f"[TMDb] Erro em {endpoint}: {e}")
        return {}

# ---------- FILMES ----------
def get_popular_movies(page=1):
    data = _call("/movie/popular", {"page": page})
    return data.get("results", [])

def get_movies_by_genre(genre_id, page=1):
    data = _call("/discover/movie", {"with_genres": genre_id, "page": page})
    return data.get("results", [])

def get_movies_by_year(year, page=1):
    data = _call("/discover/movie", {"primary_release_year": year, "page": page})
    return data.get("results", [])

def get_trending_movies(time_window="week"):
    data = _call(f"/trending/movie/{time_window}")
    return data.get("results", [])

# ---------- SÉRIES ----------
def get_popular_tv(page=1):
    data = _call("/tv/popular", {"page": page})
    return data.get("results", [])

def get_tv_by_genre(genre_id, page=1):
    data = _call("/discover/tv", {"with_genres": genre_id, "page": page})
    return data.get("results", [])

def get_tv_by_year(year, page=1):
    data = _call("/discover/tv", {"first_air_date_year": year, "page": page})
    return data.get("results", [])

def get_trending_tv(time_window="week"):
    data = _call(f"/trending/tv/{time_window}")
    return data.get("results", [])

# ---------- GENRES ----------
def get_movie_genres():
    data = _call("/genre/movie/list")
    return data.get("genres", [])

def get_tv_genres():
    data = _call("/genre/tv/list")
    return data.get("genres", [])
