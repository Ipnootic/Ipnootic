import json
import urllib.request
import urllib.parse
import xbmc

# --- API KEY fixa (não editável nas definições) ---
API_KEY = "fd8c3db445635a0faa55e8b7db037141"
BASE_URL = "https://api.themoviedb.org/3"

def _lang():
    """Define a língua (padrão pt-PT)."""
    try:
        import xbmcaddon
        ADDON = xbmcaddon.Addon()
        return ADDON.getSettingString("ui_lang") or "pt-PT"
    except Exception:
        return "pt-PT"

def _call(endpoint, params=None):
    """Chama a API TMDb com API_KEY e retorna JSON."""
    if params is None:
        params = {}
    params["api_key"] = API_KEY
    params["language"] = _lang()
    url = f"{BASE_URL}{endpoint}?{urllib.parse.urlencode(params)}"
    try:
        with urllib.request.urlopen(url, timeout=10) as r:
            data = r.read().decode("utf-8")
            return json.loads(data)
    except Exception as e:
        xbmc.log(f"[TMDb] Erro em {endpoint}: {e}", xbmc.LOGERROR)
        return {}

# ---------- FILMES ----------
def get_popular_movies(page=1):
    data = _call("/movie/popular", {"page": page})
    return data.get("results", [])

def get_movies_by_genre(genre_id, page=1):
    data = _call("/discover/movie", {"with_genres": genre_id, "page": page})
    return data.get("results", [])

def get_movies_by_year(year, page=1):
    data = _call("/discover/movie", {"primary_release_year": year, "page": page})
    return data.get("results", [])

def get_trending_movies(time_window="week"):
    data = _call(f"/trending/movie/{time_window}")
    return data.get("results", [])

# ---------- SÉRIES ----------
def get_popular_tv(page=1):
    data = _call("/tv/popular", {"page": page})
    return data.get("results", [])

def get_tv_by_genre(genre_id, page=1):
    data = _call("/discover/tv", {"with_genres": genre_id, "page": page})
    return data.get("results", [])

def get_tv_by_year(year, page=1):
    data = _call("/discover/tv", {"first_air_date_year": year, "page": page})
    return data.get("results", [])

def get_trending_tv(time_window="week"):
    data = _call(f"/trending/tv/{time_window}")
    return data.get("results", [])

# ---------- GENRES ----------
def get_movie_genres():
    data = _call("/genre/movie/list")
    return data.get("genres", [])

def get_tv_genres():
    data = _call("/genre/tv/list")
    return data.get("genres", [])
