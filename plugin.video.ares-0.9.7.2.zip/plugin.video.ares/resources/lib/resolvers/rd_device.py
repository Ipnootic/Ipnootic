import json, time, urllib.request, urllib.parse
from xbmcaddon import Addon
ADDON = Addon()
OAUTH = "https://api.real-debrid.com/oauth/v2"
REST  = "https://api.real-debrid.com/rest/1.0"

def _post(url, data):
    if isinstance(data, dict): data = urllib.parse.urlencode(data).encode()
    req = urllib.request.Request(url, data=data, headers={"Content-Type":"application/x-www-form-urlencoded"}, method="POST")
    with urllib.request.urlopen(req, timeout=20) as r:
        raw = r.read().decode(); 
        try: return json.loads(raw)
        except: return raw

def device_code():
    cid = ADDON.getSettingString('rd_client_id')
    if not cid: raise Exception("RD Client ID vazio")
    return _post(OAUTH + "/device/code", {"client_id": cid, "new_credentials": "yes"})

def poll_for_token(dev_code, interval=5):
    cid = ADDON.getSettingString('rd_client_id')
    start = time.time()
    while time.time()-start < 600:
        try:
            creds = _post(OAUTH + "/device/credentials", {"client_id": cid, "code": dev_code})
            if isinstance(creds, dict) and creds.get("client_id") and creds.get("client_secret"):
                tok = _post(OAUTH + "/token", {"client_id": creds["client_id"], "client_secret": creds["client_secret"],
                                               "code": "fixed", "grant_type": "http://oauth.net/grant_type/device/1.0"})
                if isinstance(tok, dict) and tok.get("access_token"):
                    ADDON.setSettingString('rd_token', tok["access_token"])
                    return tok
        except: pass
        time.sleep(max(2,int(interval)))
    raise Exception("Timeout RD device flow")

def user(token=None):
    t = token or ADDON.getSettingString('rd_token')
    if not t: raise Exception("Token RD vazio")
    req = urllib.request.Request(REST + "/user", headers={"Authorization":"Bearer "+t})
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read().decode())
