import json, urllib.request, urllib.parse
from xbmcaddon import Addon
ADDON = Addon()
BASE = "https://api.trakt.tv"

def _headers():
    return {
        "Content-Type":"application/json",
        "trakt-api-version":"2",
        "trakt-api-key": ADDON.getSettingString('trakt_client_id'),
        "Authorization": "Bearer " + ADDON.getSettingString('trakt_access_token')
    }

def _get(path, params=None):
    url = BASE + path
    if params:
        url += "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers=_headers())
    with urllib.request.urlopen(req, timeout=20) as r:
        raw = r.read().decode('utf-8')
        try: return json.loads(raw)
        except: return []

def next_up(limit=20):
    """Usa watched shows + progress/watched para obter next_episode por show."""
    shows = _get("/sync/watched/shows")
    out = []
    for it in shows:
        ids = ((it.get('show') or {}).get('ids') or {})
        sid = ids.get('trakt')
        title = ((it.get('show') or {}).get('title') or '')
        if not sid or not title: continue
        prog = _get(f"/shows/{sid}/progress/watched", params={"hidden":"false","specials":"false"})
        ne = prog.get('next_episode') if isinstance(prog, dict) else None
        if ne and ne.get('season') is not None and ne.get('number') is not None:
            out.append({"title": title, "season": ne['season'], "episode": ne['number']})
        if len(out) >= limit: break
    return out
