
import os, json, xbmcvfs
from xbmcaddon import Addon
ADDON = Addon()
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
os.makedirs(PROFILE, exist_ok=True)
HIST = os.path.join(PROFILE, "history.json")
FAV_FILE = os.path.join(PROFILE, "favorites.json")

def add_episode_play(title, season, episode):
    data = {}
    if os.path.exists(HIST):
        try: data = json.load(open(HIST,'r',encoding='utf-8'))
        except: data = {}
    arr = data.get(title, [])
    if [season, episode] not in arr: arr.append([season, episode])
    data[title] = arr
    json.dump(data, open(HIST,'w',encoding='utf-8'))

def nextup_list(limit=20):
    out = []
    if os.path.exists(HIST):
        try:
            data = json.load(open(HIST,'r',encoding='utf-8'))
            for k,v in list(data.items())[:limit]:
                if v:
                    s,e = v[-1]
                    out.append({"title": k, "season": s, "episode": e+1})
        except: pass
    return out[:limit]

def fav_add(kind, title):
    d = {}
    if os.path.exists(FAV_FILE):
        try: d = json.load(open(FAV_FILE,'r',encoding='utf-8'))
        except: d = {}
    lst = d.get(kind, [])
    if title not in lst: lst.append(title)
    d[kind] = lst
    json.dump(d, open(FAV_FILE,'w',encoding='utf-8'))

def fav_list(kind):
    if not os.path.exists(FAV_FILE): return []
    try:
        d = json.load(open(FAV_FILE,'r',encoding='utf-8'))
        return d.get(kind, [])
    except: return []

def fav_remove(kind, title):
    if not os.path.exists(FAV_FILE): return
    try:
        d = json.load(open(FAV_FILE,'r',encoding='utf-8'))
    except: 
        return
    lst = d.get(kind, [])
    if title in lst:
        lst.remove(title)
        d[kind] = lst
        json.dump(d, open(FAV_FILE,'w',encoding='utf-8'))

def mark_unwatched(title, season, episode):
    if not os.path.exists(HIST): return
    try:
        data = json.load(open(HIST,'r',encoding='utf-8'))
    except:
        return
    arr = data.get(title, [])
    if [season, episode] in arr:
        arr.remove([season, episode])
        data[title] = arr
        json.dump(data, open(HIST,'w',encoding='utf-8'))

def is_watched(title, season, episode):
    if not os.path.exists(HIST): return False
    try:
        data = json.load(open(HIST,'r',encoding='utf-8'))
    except:
        return False
    arr = data.get(title, [])
    return [season, episode] in arr
