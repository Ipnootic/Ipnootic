import os, json, urllib.request, urllib.parse, tempfile
from ..utils.settings import get_str
API = "https://api.opensubtitles.com/api/v1"

def _req(path, params=None, headers=None):
    url = API + path
    if params: url += "?" + urllib.parse.urlencode(params)
    hdrs = {"Api-Key": get_str('os_api_key','')}
    if headers: hdrs.update(headers)
    req = urllib.request.Request(url, headers=hdrs)
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read().decode())

def _download(file_id):
    req = urllib.request.Request(API + "/download", data=json.dumps({"file_id": file_id}).encode("utf-8"),
                                 headers={"Api-Key": get_str('os_api_key',''), "Content-Type":"application/json"}, method="POST")
    with urllib.request.urlopen(req, timeout=20) as r:
        meta = json.loads(r.read().decode())
    link = meta.get("link")
    if not link: return None
    data = urllib.request.urlopen(link, timeout=20).read()
    fd, path = tempfile.mkstemp(suffix=".srt"); os.write(fd, data); os.close(fd)
    return path

def auto_subtitle_for(src):
    api_key = get_str('os_api_key',''); 
    if not api_key: return None
    langs = [s.strip() for s in get_str('os_langs','pt,pt-BR').split(',') if s.strip()]
    params = {"query": src.get('title',''), "languages": ",".join(langs)}
    if src.get('year'): params["year"] = src["year"]
    data = _req("/subtitles", params=params)
    items = data.get('data') or []
    if not items: return None
    a = items[0].get('attributes',{}); files = a.get('files') or []
    if not files: return None
    return _download(files[0].get('file_id'))
