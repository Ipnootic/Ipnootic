import sys, urllib.parse, xbmc, xbmcaddon, xbmcgui, xbmcplugin
from resources.lib.scrapers import tmdb

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

def build_url(query):
    return BASE_URL + "?" + urllib.parse.urlencode(query)

def _params():
    if len(sys.argv) > 2 and sys.argv[2]:
        return dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    return {}

# ---------- MENUS PRINCIPAIS ----------
def main_menu():
    add_dir("🔎 Pesquisar", "pesquisar", True)
    add_dir("🎬 Descobrir Filmes", "descobrir_filmes", True)
    add_dir("📺 Descobrir Séries", "descobrir_series", True)
    add_dir("⭐ Meus Filmes", "meus_filmes", True)
    add_dir("📌 Minhas Séries", "minhas_series", True)
    add_dir("⚙️ Definições", "definicoes", True)
    xbmcplugin.endOfDirectory(HANDLE)

# ---------- SUBMENUS ----------
def submenu_pesquisar():
    add_dir("Pesquisar Filmes", "search_movie", False)
    add_dir("Pesquisar Séries", "search_episode", False)
    if ADDON.getSettingBool("use_imdb") and ADDON.getSettingString("omdb_api"):
        add_dir("Pesquisar no IMDb", "search_imdb", False)
    add_dir("Pesquisa Global", "search_global", False)
    xbmcplugin.endOfDirectory(HANDLE)

def submenu_descobrir_filmes():
    if ADDON.getSettingBool("use_tmdb"):
        add_dir("TMDb - Populares", "discover_movies_tmdb_popular", False)
        add_dir("TMDb - Em Cartaz", "discover_movies_tmdb_nowplaying", False)
        add_dir("TMDb - Próximos", "discover_movies_tmdb_upcoming", False)
        add_dir("TMDb - Top Rated", "discover_movies_tmdb_toprated", False)
        add_dir("TMDb - Trending", "discover_movies_tmdb_trending", False)
        add_dir("TMDb - Por Género", "discover_movies_tmdb_genres", True)
        add_dir("TMDb - Por Ano", "discover_movies_tmdb_years", True)
    xbmcplugin.endOfDirectory(HANDLE)

def submenu_descobrir_series():
    if ADDON.getSettingBool("use_tmdb"):
        add_dir("TMDb - Populares", "discover_tv_tmdb_popular", False)
        add_dir("TMDb - Top Rated", "discover_tv_tmdb_toprated", False)
        add_dir("TMDb - Em Exibição", "discover_tv_tmdb_ontheair", False)
        add_dir("TMDb - Hoje na TV", "discover_tv_tmdb_airingtoday", False)
        add_dir("TMDb - Trending", "discover_tv_tmdb_trending", False)
        add_dir("TMDb - Por Género", "discover_tv_tmdb_genres", True)
        add_dir("TMDb - Por Ano", "discover_tv_tmdb_years", True)
    xbmcplugin.endOfDirectory(HANDLE)

def submenu_meus_filmes():
    add_dir("Watchlist", "trakt_movies_watchlist", False)
    add_dir("Favoritos", "trakt_movies_favs", False)
    add_dir("Em Progresso", "trakt_movies_progress", False)
    xbmcplugin.endOfDirectory(HANDLE)

def submenu_minhas_series():
    add_dir("Watchlist", "trakt_shows_watchlist", False)
    add_dir("Favoritos", "trakt_shows_favs", False)
    add_dir("Em Progresso", "trakt_shows_progress", False)
    add_dir("Next Up", "trakt_shows_nextup", False)
    xbmcplugin.endOfDirectory(HANDLE)

def submenu_definicoes():
    add_dir("Autorização Trakt", "trakt_auth", False)
    add_dir("Autorização Real-Debrid", "rd_auth", False)
    add_dir("Testar OpenSubtitles", "os_test", False)
    add_dir("Configurar Scrapers/Providers", "scrapers", False)
    add_dir("Abrir Definições", "settings", False)
    xbmcplugin.endOfDirectory(HANDLE)

# ---------- FUNÇÕES AUX ----------
def add_dir(name, action, folder=True, extra={}):
    q = {"action": action}
    q.update(extra)
    url = build_url(q)
    li = xbmcgui.ListItem(label=name)
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=folder)

def list_media(items, media_type="movie"):
    base_img = "https://image.tmdb.org/t/p/w500"
    for m in items:
        title = m.get("title") or m.get("name") or "Sem título"
        year = (m.get("release_date") or m.get("first_air_date") or "")[:4]
        plot = m.get("overview", "")
        poster = base_img + m["poster_path"] if m.get("poster_path") else ""
        fanart = base_img + m["backdrop_path"] if m.get("backdrop_path") else ""
        li = xbmcgui.ListItem(f"{title} ({year})")
        li.setInfo("video", {"title": title, "year": year, "plot": plot, "mediatype": media_type})
        li.setArt({"poster": poster, "fanart": fanart, "thumb": poster})
        url = build_url({"action": "play", "id": m.get("id"), "media": media_type})
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE)

# ---------- HANDLERS TMDb ----------
def show_movies_by_genre():
    for g in tmdb.get_movie_genres():
        add_dir(g["name"], "discover_movies_tmdb_bygenre", False, {"genre_id": g["id"]})
    xbmcplugin.endOfDirectory(HANDLE)

def show_tv_by_genre():
    for g in tmdb.get_tv_genres():
        add_dir(g["name"], "discover_tv_tmdb_bygenre", False, {"genre_id": g["id"]})
    xbmcplugin.endOfDirectory(HANDLE)

def show_years(media):
    for year in range(2025, 1970, -1):
        add_dir(str(year), f"discover_{media}_tmdb_byyear", False, {"year": year})
    xbmcplugin.endOfDirectory(HANDLE)

# ---------- ROUTER ----------
def router(params):
    action = params.get("action")
    if not action:
        main_menu()

    # Submenus
    elif action == "pesquisar":
        submenu_pesquisar()
    elif action == "descobrir_filmes":
        submenu_descobrir_filmes()
    elif action == "descobrir_series":
        submenu_descobrir_series()
    elif action == "meus_filmes":
        submenu_meus_filmes()
    elif action == "minhas_series":
        submenu_minhas_series()
    elif action == "definicoes":
        submenu_definicoes()
    elif action == "settings":
        ADDON.openSettings()

    # TMDb Movies
    elif action == "discover_movies_tmdb_popular":
        list_media(tmdb.get_popular_movies(), "movie")
    elif action == "discover_movies_tmdb_nowplaying":
        list_media(tmdb._call("/movie/now_playing").get("results", []), "movie")
    elif action == "discover_movies_tmdb_upcoming":
        list_media(tmdb._call("/movie/upcoming").get("results", []), "movie")
    elif action == "discover_movies_tmdb_toprated":
        list_media(tmdb._call("/movie/top_rated").get("results", []), "movie")
    elif action == "discover_movies_tmdb_trending":
        list_media(tmdb.get_trending_movies(), "movie")
    elif action == "discover_movies_tmdb_genres":
        show_movies_by_genre()
    elif action == "discover_movies_tmdb_bygenre":
        list_media(tmdb.get_movies_by_genre(params.get("genre_id")), "movie")
    elif action == "discover_movies_tmdb_years":
        show_years("movies")
    elif action == "discover_movies_tmdb_byyear":
        list_media(tmdb.get_movies_by_year(params.get("year")), "movie")

    # TMDb TV
    elif action == "discover_tv_tmdb_popular":
        list_media(tmdb.get_popular_tv(), "tvshow")
    elif action == "discover_tv_tmdb_toprated":
        list_media(tmdb._call("/tv/top_rated").get("results", []), "tvshow")
    elif action == "discover_tv_tmdb_ontheair":
        list_media(tmdb._call("/tv/on_the_air").get("results", []), "tvshow")
    elif action == "discover_tv_tmdb_airingtoday":
        list_media(tmdb._call("/tv/airing_today").get("results", []), "tvshow")
    elif action == "discover_tv_tmdb_trending":
        list_media(tmdb.get_trending_tv(), "tvshow")
    elif action == "discover_tv_tmdb_genres":
        show_tv_by_genre()
    elif action == "discover_tv_tmdb_bygenre":
        list_media(tmdb.get_tv_by_genre(params.get("genre_id")), "tvshow")
    elif action == "discover_tv_tmdb_years":
        show_years("tv")
    elif action == "discover_tv_tmdb_byyear":
        list_media(tmdb.get_tv_by_year(params.get("year")), "tvshow")

    else:
        xbmcplugin.endOfDirectory(HANDLE)

if __name__ == "__main__":
    router(_params())
