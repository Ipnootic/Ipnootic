# -*- coding: utf-8 -*-
import importlib
from typing import List, Dict, Any
from .base import ProviderBase
import xbmc

class CocoAdapter(ProviderBase):
    name = "coco"

    def __init__(self):
        self._funcs = []
        candidates = [
            ("cocoscrapers", "scrape_movie"),
            ("cocoscrapers.api", "scrape_movie"),
            ("cocoScrapers", "scrape_movie"),
            ("cocoscrapers", "get_movie_sources"),
        ]
        for modname, fname in candidates:
            try:
                m = importlib.import_module(modname)
                f = getattr(m, fname, None)
                if callable(f):
                    self._funcs.append(f)
            except Exception:
                continue
        if not self._funcs:
            xbmc.log("[Ares][prov][coco] não encontrei API pública. Ajustar nomes no adapter se necessário.", xbmc.LOGWARNING)

    def _call_any(self, f, title, year, tmdb_id=None, imdb_id=None):
        tries = [
            ((), {"title": title, "year": year, "tmdb_id": tmdb_id, "imdb_id": imdb_id}),
            ((title, year, tmdb_id, imdb_id), {}),
            ((title, year), {}),
            ((), {"title": title, "year": year}),
        ]
        for args, kwargs in tries:
            try:
                return f(*args, **kwargs)
            except TypeError:
                continue
            except Exception as e:
                xbmc.log(f"[Ares][prov][coco] erro ao chamar {f}: {e}", xbmc.LOGERROR)
                return []
        return []

    def _normalize(self, lst) -> List[Dict[str, Any]]:
        out = []
        if not lst:
            return out
        for x in lst:
            try:
                url = x.get("url") or x.get("link")
                if not url:
                    continue
                q = x.get("quality") or x.get("res") or ""
                size = x.get("size") or x.get("filesize") or 0
                prov = x.get("provider") or "coco"
                out.append({"url": url, "quality": str(q), "size": int(size) if str(size).isdigit() else size, "provider": prov})
            except Exception:
                continue
        return out

    def search_movie(self, title: str, year: int, tmdb_id: int = None) -> List[Dict[str, Any]]:
        if not self._funcs:
            return []
        for f in self._funcs:
            res = self._call_any(f, title, year, tmdb_id=tmdb_id, imdb_id=None)
            norm = self._normalize(res)
            if norm:
                xbmc.log(f"[Ares][prov][coco] {len(norm)} fontes", xbmc.LOGINFO)
                return norm
        return []
