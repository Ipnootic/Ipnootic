import json, urllib.request
from xbmcaddon import Addon
ADDON = Addon()
BASE = "https://api.trakt.tv"

def _headers():
    return {
        "Content-Type":"application/json",
        "trakt-api-version":"2",
        "trakt-api-key": ADDON.getSettingString('trakt_client_id'),
        "Authorization": "Bearer " + ADDON.getSettingString('trakt_access_token')
    }

def _get(path):
    req = urllib.request.Request(BASE + path, headers=_headers())
    with urllib.request.urlopen(req, timeout=20) as r:
        raw = r.read().decode('utf-8')
        try: return json.loads(raw)
        except: return []

def recent_next_up(limit=20):
    """Heurística: lê /sync/history?type=episodes&limit=N e sugere episódio seguinte no mesmo show/temporada."""
    try:
        data = _get("/sync/history?type=episodes&limit=%d" % (limit*2))
    except Exception:
        return []
    out = []
    seen = set()
    for it in data:
        show = (((it.get('show') or {}).get('title')) or '') if isinstance(it, dict) else ''
        ep = (it.get('episode') or {}) if isinstance(it, dict) else {}
        s = ep.get('season'); e = ep.get('number')
        if not show or s is None or e is None: continue
        key = (show, s)
        if key in seen: continue
        seen.add(key)
        out.append({"title": show, "season": s, "episode": e+1})
        if len(out) >= limit: break
    return out
