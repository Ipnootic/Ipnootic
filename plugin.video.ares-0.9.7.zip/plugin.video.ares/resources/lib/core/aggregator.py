from ..adapters import a4k, coco

def search_movie(title, year=None):
    res = []
    try: res += a4k.search_movie(title, year)
    except Exception: pass
    try: res += coco.search_movie(title, year)
    except Exception: pass
    return res

def search_episode(title, season, episode):
    res = []
    try: res += a4k.search_episode(title, season, episode)
    except Exception: pass
    try: res += coco.search_episode(title, season, episode)
    except Exception: pass
    return res
