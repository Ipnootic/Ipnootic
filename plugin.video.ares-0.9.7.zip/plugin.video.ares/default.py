import sys, urllib.parse, xbmc, xbmcaddon, xbmcgui, xbmcplugin

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

def build_url(query):
    return BASE_URL + "?" + urllib.parse.urlencode(query)

def _params():
    if len(sys.argv) > 2 and sys.argv[2]:
        return dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    return {}

def _open_settings():
    ADDON.openSettings()
    xbmcplugin.endOfDirectory(HANDLE)

def _trakt_auth():
    try:
        from resources.lib.trakt import client as trakt
        dc = trakt.device_code()
        code = dc.get('user_code') or '----'
        xbmcgui.Dialog().ok("Trakt",
            f"Código: [B]{code}[/B]\nVai a https://trakt.tv/activate e introduz o código.")
        trakt.poll_for_token(dc.get('device_code'), interval=dc.get('interval',5), expires_in=dc.get('expires_in',600))
        xbmcgui.Dialog().notification("Trakt", "Autorizado com sucesso", xbmcgui.NOTIFICATION_INFO, 3000)
    except Exception as e:
        xbmcgui.Dialog().ok("Trakt", f"Falha: {e}")
    xbmcplugin.endOfDirectory(HANDLE)

def _rd_device():
    try:
        try:
            from resources.lib.resolvers import rd_device as rdd
        except Exception:
            from resources.lib import rd as rdd
        dc = rdd.device_code()
        code = (dc.get('user_code') if isinstance(dc, dict) else None) or '----'
        xbmcgui.Dialog().ok("Real-Debrid",
            f"Código: [B]{code}[/B]\nAcede a https://real-debrid.com/device e introduz o código.")
        rdd.poll_for_token(dc.get('device_code'), interval=dc.get('interval',5))
        u = rdd.user()
        xbmcgui.Dialog().notification("Real-Debrid", f"Autorizado: {u.get('username')}", xbmcgui.NOTIFICATION_INFO, 3000)
    except Exception as e:
        xbmcgui.Dialog().ok("Real-Debrid", f"Falha: {e}")
    xbmcplugin.endOfDirectory(HANDLE)

def _os_test():
    try:
        from resources.lib.subs import opensubs
        p = opensubs.auto_subtitle_for({"title":"Inception","year":"2010"})
        xbmcgui.Dialog().ok("OpenSubtitles", f"{'OK → ' + p if p else 'Falha a obter legenda'}")
    except Exception as e:
        xbmcgui.Dialog().ok("OpenSubtitles", f"Erro: {e}")
    xbmcplugin.endOfDirectory(HANDLE)

def _list_nextup():
    items = []
    try:
        from resources.lib.trakt import progress as trakt_prog
        items = trakt_prog.next_up() or []
    except Exception:
        try:
            from resources.lib.utils import store
            items = store.nextup_list()
        except Exception:
            items = []
    for it in items:
        t = it.get('title') or 'Série'
        s = int(it.get('season') or 1)
        e = int(it.get('episode') or 1)
        li = xbmcgui.ListItem(f"{t} S{s:02d}E{e:02d}")
        xbmcplugin.addDirectoryItem(HANDLE, build_url({"action":"search_episode","title":t,"season":s,"episode":e}), li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE)

def _list_favs():
    try:
        from resources.lib.utils import store
        movies = store.fav_list('movie')
        shows  = store.fav_list('show')
    except Exception:
        movies, shows = [], []
    for t in movies:
        xbmcplugin.addDirectoryItem(HANDLE, build_url({"action":"search_movie","title":t}), xbmcgui.ListItem(f"Filme: {t}"), isFolder=False)
    for t in shows:
        xbmcplugin.addDirectoryItem(HANDLE, build_url({"action":"search_episode","title":t,"season":1,"episode":1}), xbmcgui.ListItem(f"Série: {t}"), isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE)

def _filters_key():
    try:
        ms = (ADDON.getSettingString('prefer_codecs') or '') + '|' + str(ADDON.getSettingBool('exclude_cam_ts'))
        ms += '|' + (ADDON.getSettingString('filters_min_seeders') or '') + '|' + (ADDON.getSettingString('filters_min_size_gb') or '') + '|' + (ADDON.getSettingString('filters_max_size_gb') or '')
        return ms
    except Exception:
        return ""

def _rank_and_list(kind, title, season=None, episode=None, audio=None):
    try:
        from resources.lib.core import aggregator, ranker
        from resources.lib.resolvers import rd_resolver
        from resources.lib.utils import cache
        key = cache.key_for_query(kind, title, season, episode, _filters_key()+ '|' + (audio or ''))
        ranked = cache.get(key)
        if ranked is None:
            if kind == 'movie':
                res = aggregator.search_movie(title)
            else:
                res = aggregator.search_episode(title, int(season or 1), int(episode or 1))
            if audio:
                res = ranker.filter_by_audio(res, audio)
            ranked = ranker.filter_and_score(res)
            cache.set(key, ranked)
        if not ranked:
            xbmcgui.Dialog().ok("Ares", "Sem fontes encontradas (verifica scrapers instalados).")
            xbmcplugin.endOfDirectory(HANDLE); return
        try:
            src = ranked[0]
            stream = rd_resolver.resolve(src)
            li = xbmcgui.ListItem(path=stream)
            xbmcplugin.setResolvedUrl(HANDLE, True, li)
        except Exception as e:
            xbmcgui.Dialog().ok("Ares", f"Falha resolver: {e}")
            xbmcplugin.endOfDirectory(HANDLE)
    except Exception as e:
        xbmcgui.Dialog().ok("Ares", f"Erro: {e}")
        xbmcplugin.endOfDirectory(HANDLE)

def router(params):
    action = params.get('action')
    if not action:
        preset = ADDON.getSettingString("menu_preset") or "Minimal"
        xbmcplugin.addDirectoryItem(HANDLE, build_url({"action":"settings"}), xbmcgui.ListItem("⚙️ Settings"), False)
        xbmcplugin.addDirectoryItem(HANDLE, build_url({"action":"trakt_auth"}), xbmcgui.ListItem("Trakt: Autorizar (Device)"), False)
        xbmcplugin.addDirectoryItem(HANDLE, build_url({"action":"rd_device"}), xbmcgui.ListItem("RD: Autorizar (Device)"), False)
        xbmcplugin.addDirectoryItem(HANDLE, build_url({"action":"os_test"}), xbmcgui.ListItem("Testar OpenSubtitles"), False)
        xbmcplugin.addDirectoryItem(HANDLE, build_url({"action":"nextup"}), xbmcgui.ListItem("▶ Next Up"), True)
        xbmcplugin.addDirectoryItem(HANDLE, build_url({"action":"favs"}), xbmcgui.ListItem("★ Favoritos"), True)
        if preset == "1":
            xbmcplugin.addDirectoryItem(HANDLE, build_url({"action":"search_movie_ptpt"}), xbmcgui.ListItem("Filmes (Áudio PT-PT)"), False)
            xbmcplugin.addDirectoryItem(HANDLE, build_url({"action":"search_tv_ptpt"}), xbmcgui.ListItem("Séries (Áudio PT-PT)"), False)
            xbmcplugin.addDirectoryItem(HANDLE, build_url({"action":"search_movie_ptbr"}), xbmcgui.ListItem("Filmes (Áudio PT-BR)"), False)
            xbmcplugin.addDirectoryItem(HANDLE, build_url({"action":"search_tv_ptbr"}), xbmcgui.ListItem("Séries (Áudio PT-BR)"), False)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    if action == "settings":
        _open_settings()
    elif action == "trakt_auth":
        _trakt_auth()
    elif action == "rd_device":
        _rd_device()
    elif action == "os_test":
        _os_test()
    elif action == "nextup":
        _list_nextup()
    elif action == "favs":
        _list_favs()
    elif action == "search_movie":
        title = params.get("title")
        if not title:
            kb = xbmc.Keyboard("", "Título do filme"); kb.doModal()
            if not kb.isConfirmed(): xbmcplugin.endOfDirectory(HANDLE); return
            title = kb.getText()
        _rank_and_list("movie", title)
    elif action == "search_episode":
        t = params.get("title")
        if not t:
            kb = xbmc.Keyboard("", "Título da série"); kb.doModal()
            if not kb.isConfirmed(): xbmcplugin.endOfDirectory(HANDLE); return
            t = kb.getText()
        s = params.get("season") or "1"
        e = params.get("episode") or "1"
        _rank_and_list("episode", t, s, e)
    elif action == "search_movie_ptpt":
        kb = xbmc.Keyboard("", "Título do filme (PT-PT)"); kb.doModal()
        if not kb.isConfirmed(): xbmcplugin.endOfDirectory(HANDLE); return
        title = kb.getText()
        _rank_and_list("movie", title, audio="pt-pt")
    elif action == "search_movie_ptbr":
        kb = xbmc.Keyboard("", "Título do filme (PT-BR)"); kb.doModal()
        if not kb.isConfirmed(): xbmcplugin.endOfDirectory(HANDLE); return
        title = kb.getText()
        _rank_and_list("movie", title, audio="pt-br")
    elif action == "search_tv_ptpt":
        kb = xbmc.Keyboard("", "Título da série (PT-PT)"); kb.doModal()
        if not kb.isConfirmed(): xbmcplugin.endOfDirectory(HANDLE); return
        t = kb.getText()
        kb2 = xbmc.Keyboard("", "Temporada (número)"); kb2.doModal(); s = kb2.getText() if kb2.isConfirmed() else "1"
        kb3 = xbmc.Keyboard("", "Episódio (número)"); kb3.doModal(); e = kb3.getText() if kb3.isConfirmed() else "1"
        _rank_and_list("episode", t, s, e, audio="pt-pt")
    elif action == "search_tv_ptbr":
        kb = xbmc.Keyboard("", "Título da série (PT-BR)"); kb.doModal()
        if not kb.isConfirmed(): xbmcplugin.endOfDirectory(HANDLE); return
        t = kb.getText()
        kb2 = xbmc.Keyboard("", "Temporada (número)"); kb2.doModal(); s = kb2.getText() if kb2.isConfirmed() else "1"
        kb3 = xbmc.Keyboard("", "Episódio (número)"); kb3.doModal(); e = kb3.getText() if kb3.isConfirmed() else "1"
        _rank_and_list("episode", t, s, e, audio="pt-br")
    else:
        xbmcplugin.endOfDirectory(HANDLE)

if __name__ == "__main__":
    router(_params())
